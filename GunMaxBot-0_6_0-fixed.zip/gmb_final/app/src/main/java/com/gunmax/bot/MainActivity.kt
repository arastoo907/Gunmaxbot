package com.gunmax.bot

import android.os.Bundle
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.nio.charset.StandardCharsets
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF07110F)
private val Panel = Color(0xFF101D19)
private val Panel2 = Color(0xFF172923)
private val Mint = Color(0xFF39D6A0)
private val Muted = Color(0xFF9AB0A8)
private val White = Color(0xFFEAF5F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GunMaxApp() }
    }
}

@Composable
fun GunMaxApp() {
    var command by remember { mutableStateOf("") }
    var commandResult by remember { mutableStateOf("هنوز دستوری ثبت نشده است.") }
    var selected by remember { mutableStateOf("داشبورد") }
    var serverHost by remember { mutableStateOf("play.gunmax.org") }
    var serverPort by remember { mutableStateOf("25565") }
    var pingState by remember { mutableStateOf("هنوز بررسی نشده") }
    var checking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bots = listOf("بات شماره ۱", "بات شماره ۲", "بات شماره ۳")
    var selectedVersion by remember { mutableStateOf(McVersion.ALL.first { it.protocol == 763 }) }
    var versionMenu by remember { mutableStateOf(false) }
    var botName by remember { mutableStateOf("GunMax_1") }
    var session by remember { mutableStateOf<McBotSession?>(null) }
    var connecting by remember { mutableStateOf(false) }
    var botState by remember { mutableStateOf(0) } // 0 آفلاین، 1 در حال ورود، 2 داخل بازی
    val logs = remember { mutableStateListOf<String>() }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    fun addLog(m: String) {
        logs.add(0, "[${timeFmt.format(Date())}] $m")
        while (logs.size > 200) logs.removeAt(logs.size - 1)
    }

    // یک تابع مشترک برای وصل/قطع، هم از کارت «ورود بات» و هم از دکمه «کنترل مرکزی» صدا زده می‌شود
    fun toggleBot() {
        val cur = session
        if (cur != null && cur.connected) {
            cur.disconnect()
            addLog("دستور قطع اتصال صادر شد.")
            return
        }
        val port = serverPort.toIntOrNull()
        if (serverHost.isBlank() || port == null || port !in 1..65535 || botName.length < 3) {
            addLog("✗ آدرس، پورت یا نام بات نامعتبر است (نام بات حداقل ۳ کاراکتر).")
            return
        }
        connecting = true
        val s = McBotSession(serverHost.trim(), port, selectedVersion, botName) { m ->
            scope.launch { addLog(m) }
        }
        session = s
        addLog("در حال اتصال به ${serverHost.trim()}:$port با نام «$botName» (${selectedVersion.label})...")
        scope.launch(Dispatchers.IO) {
            try {
                s.connect()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    addLog("✗ اتصال برقرار نشد: ${e.javaClass.simpleName} — ${e.message ?: "بدون پیام خطا"}")
                }
            }
            withContext(Dispatchers.Main) { connecting = false }
        }
    }

    LaunchedEffect(session) {
        while (true) {
            val cur = session
            botState = when {
                cur == null || !cur.connected -> 0
                cur.spawned -> 2
                else -> 1
            }
            delay(500)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Mint,
        onBackground = White, onSurface = White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Mint) {
                        listOf("داشبورد" to Icons.Default.Dashboard,
                            "بات‌ها" to Icons.Default.SmartToy,
                            "کنسول" to Icons.Default.Terminal,
                            "تنظیمات" to Icons.Default.Settings).forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = selected == label,
                                onClick = { selected = label },
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Mint, selectedTextColor = Mint,
                                    indicatorColor = Panel2, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()) {
                            Column {
                                Text("گانمکس بات", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
                                Text("مدیریت هوشمند بات‌های Minecraft", color = Muted, fontSize = 12.sp)
                            }
                            Surface(shape = RoundedCornerShape(16.dp), color = Mint.copy(alpha = .16f)) {
                                Icon(Icons.Default.Diamond, null, tint = Mint, modifier = Modifier.padding(14.dp).size(28.dp))
                            }
                        }
                    }
                    when (selected) {
                        "داشبورد" -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StatCard("بات‌های فعال", if (botState == 2) "۱ / ۱" else "۰ / ۱", Icons.Default.SmartToy, Modifier.weight(1f))
                                    StatCard("وظایف امروز", "۰", Icons.Default.TaskAlt, Modifier.weight(1f))
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Hub, null, tint = Mint)
                                            Spacer(Modifier.width(8.dp))
                                            Text("کنترل مرکزی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                            Spacer(Modifier.weight(1f))
                                            Surface(color = if (botState != 0) Mint.copy(alpha=.18f) else Panel2, shape = RoundedCornerShape(30.dp)) {
                                                Text(
                                                    when (botState) { 2 -> "آنلاین"; 1 -> "در حال ورود"; else -> "متوقف" },
                                                    color = if (botState != 0) Mint else Muted,
                                                    modifier = Modifier.padding(horizontal=12.dp, vertical=6.dp), fontSize=12.sp
                                                )
                                            }
                                        }
                                        // این دکمه حالا واقعاً بات را با تنظیمات فعلی (آدرس/پورت/نام/نسخه در تب «تنظیمات») وصل یا قطع می‌کند
                                        Button(
                                            onClick = { toggleBot() },
                                            enabled = !connecting,
                                            modifier = Modifier.fillMaxWidth().height(52.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (botState != 0) Color(0xFFB83D62) else Mint),
                                            shape = RoundedCornerShape(15.dp)
                                        ) {
                                            Icon(if (botState != 0) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                if (connecting) "در حال اتصال..." else if (botState != 0) "قطع اتصال بات" else "اتصال بات",
                                                color = Color(0xFF06110D), fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text("آدرس، پورت، نام و نسخه را از تب «تنظیمات» عوض کن.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Text("آخرین رویدادها", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (logs.isEmpty()) {
                                            LogLine("سیستم", "آماده. از تب بات‌ها شروع کن.", Mint)
                                        } else {
                                            logs.take(5).forEach { LogLine("بات", it, Mint) }
                                            TextButton(onClick = { selected = "کنسول" }) { Text("مشاهده کنسول کامل ›", color = Mint) }
                                        }
                                    }
                                }
                            }
                        }
                        "بات‌ها" -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("وضعیت واقعی سرور Minecraft", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("آدرس فعلی: $serverHost:$serverPort (قابل تغییر در تنظیمات)", color = Muted, fontSize = 11.sp)
                                        Button(onClick = {
                                            val port = serverPort.toIntOrNull()
                                            if (serverHost.isBlank() || port == null || port !in 1..65535) {
                                                pingState = "آدرس یا پورت نامعتبر است"
                                            } else {
                                                checking = true
                                                pingState = "در حال دریافت وضعیت Minecraft..."
                                                scope.launch {
                                                    val result = withContext(Dispatchers.IO) {
                                                        try {
                                                            MinecraftStatusClient.query(serverHost.trim(), port)
                                                        } catch (e: Exception) {
                                                            "اتصال برقرار نشد: ${e.javaClass.simpleName} — ${e.message ?: "بدون جزئیات"}"
                                                        }
                                                    }
                                                    pingState = result
                                                    checking = false
                                                }
                                            }
                                        }, enabled = !checking, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Text(if (checking) "در حال بررسی..." else "بررسی اتصال", color = Bg)
                                        }
                                        Text(pingState, color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("ورود بات به سرور", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("نام: $botName • نسخه: ${selectedVersion.label} (قابل تغییر در تنظیمات)", color = Muted, fontSize = 11.sp)
                                        Button(
                                            onClick = { toggleBot() },
                                            enabled = !connecting,
                                            modifier = Modifier.fillMaxWidth().height(50.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (botState != 0) Color(0xFFB83D62) else Mint)
                                        ) {
                                            Text(if (botState != 0) "قطع اتصال بات" else "ورود بات به سرور", color = Bg, fontWeight = FontWeight.Bold)
                                        }
                                        Text(
                                            when (botState) { 2 -> "بات داخل بازی است ✓"; 1 -> "در حال ورود..."; else -> "آفلاین" },
                                            color = Muted, fontSize = 12.sp
                                        )
                                        Text("فقط سرورهای آفلاین‌مود (کرک) پشتیبانی می‌شود. از بات فقط روی سرور خودت یا سروری که اجازه داده استفاده کن.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("دستور هوشمند", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("دستورت را فارسی بنویس؛ بات روی سرور اجرا می‌کند (حرکت مستقیم، انتظار، چت و دستور سرور).", color = Muted, fontSize = 12.sp)
                                        Surface(color = Bg, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                            BasicTextField(
                                                value = command, onValueChange = { command = it },
                                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                                textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
                                                decorationBox = { inner ->
                                                    if (command.isEmpty()) Text("مثلاً: برو به فروشگاه و موجودی را بررسی کن...", color = Muted)
                                                    inner()
                                                }
                                            )
                                        }
                                        Button(onClick = {
                                            val cur = session
                                            if (cur == null || botState != 2) {
                                                commandResult = "اول بات را وارد سرور کن."
                                            } else {
                                                commandResult = "در حال اجرا..."
                                                val text = command
                                                scope.launch(Dispatchers.IO) {
                                                    val r = executeCommands(cur, text)
                                                    withContext(Dispatchers.Main) { commandResult = r }
                                                }
                                            }
                                        }, enabled = command.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Icon(Icons.Default.AutoAwesome, null, tint = Bg)
                                            Spacer(Modifier.width(8.dp))
                                            Text("اجرای دستور", color = Bg, fontWeight = FontWeight.Bold)
                                        }
                                        Surface(color = Panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text(commandResult, color = White, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                                        }
                                        Text("نمونه: برو به مختصات 250 40 120 و منتظر بمان 5 ثانیه سپس بگو سلام | /home | قطع شو", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Text("اکانت‌های بات", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                            items(3) { index ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                                            Icon(Icons.Default.SmartToy, null, tint = Mint, modifier = Modifier.padding(11.dp))
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(bots[index], fontWeight = FontWeight.SemiBold)
                                            Text(if (index == 0) "${botName} • ${selectedVersion.label}" else "هنوز پیکربندی نشده", color = Muted, fontSize = 11.sp)
                                        }
                                        Surface(color = Color(0xFF39453F), shape = RoundedCornerShape(30.dp)) {
                                            Text(if (index == 0 && botState == 2) "آنلاین" else if (index == 0 && botState == 1) "در حال ورود" else "آفلاین", color = if (index == 0 && botState == 2) Mint else Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal=10.dp, vertical=6.dp))
                                        }
                                    }
                                }
                            }
                        }
                        "کنسول" -> {
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("کنسول کامل", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { logs.clear() }) { Text("پاک کردن", color = Muted) }
                                }
                            }
                            item {
                                Text(
                                    "همه‌ی رویدادها، خطاها و دلیل قطع اتصال اینجا با زمان دقیق ثبت می‌شود.",
                                    color = Muted, fontSize = 12.sp
                                )
                            }
                            if (logs.isEmpty()) {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                                        Text("هنوز رویدادی ثبت نشده.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
                                    }
                                }
                            } else {
                                items(logs.size) { i ->
                                    Surface(color = Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Text(
                                            logs[i], color = if (logs[i].contains("✗") || logs[i].contains("بیرون انداخته") || logs[i].contains("قطع شد")) Color(0xFFE8738B) else White,
                                            fontSize = 12.sp, modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                        "تنظیمات" -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("تنظیمات اتصال", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(value = serverHost, onValueChange = { serverHost = it }, label = { Text("آدرس سرور") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = serverPort, onValueChange = { serverPort = it.filter(Char::isDigit).take(5) }, label = { Text("پورت") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(
                                            value = botName,
                                            onValueChange = { botName = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(16) },
                                            label = { Text("نام بات (انگلیسی)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                                        )
                                        Box(Modifier.fillMaxWidth()) {
                                            OutlinedButton(onClick = { versionMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text("نسخه‌ی ورود: ${selectedVersion.label}", color = White)
                                            }
                                            DropdownMenu(expanded = versionMenu, onDismissRequest = { versionMenu = false }) {
                                                McVersion.ALL.forEach { v ->
                                                    DropdownMenuItem(
                                                        text = { Text(v.label) },
                                                        onClick = { selectedVersion = v; versionMenu = false }
                                                    )
                                                }
                                            }
                                        }
                                        Text("این تنظیمات برای دکمه‌های اتصال در تب‌های داشبورد و بات‌ها استفاده می‌شود.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Mint)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun LogLine(tag: String, message: String, color: Color) {
    Row(verticalAlignment = Alignment.Top) {
        Text(tag, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(58.dp))
        Text(message, color = Muted, fontSize = 12.sp)
    }
}


/** Performs the Minecraft Java Server List Ping (status) exchange. */
private object MinecraftStatusClient {
    fun query(host: String, port: Int): String {
        val started = System.nanoTime()
        Socket().use { socket ->
            socket.tcpNoDelay = true
            socket.soTimeout = 7000
            socket.connect(InetSocketAddress(host, port), 5000)
            val output = DataOutputStream(socket.getOutputStream())
            val input = DataInputStream(socket.getInputStream())

            val hostBytes = host.toByteArray(StandardCharsets.UTF_8)
            val handshake = java.io.ByteArrayOutputStream().also { bytes ->
                val packet = DataOutputStream(bytes)
                writeVarInt(packet, 0) // handshake packet id
                writeVarInt(packet, -1) // status-only protocol version
                writeVarInt(packet, hostBytes.size)
                packet.write(hostBytes)
                packet.writeShort(port)
                writeVarInt(packet, 1) // next state: status
            }.toByteArray()
            writeVarInt(output, handshake.size)
            output.write(handshake)

            writeVarInt(output, 1) // status request packet length
            writeVarInt(output, 0) // status request packet id
            output.flush()

            val packetLength = readVarInt(input)
            require(packetLength in 1..1_048_576) { "پاسخ سرور نامعتبر است" }
            val packetId = readVarInt(input)
            require(packetId == 0) { "پاسخ وضعیت شناخته نشد" }
            val jsonLength = readVarInt(input)
            require(jsonLength in 1..1_000_000) { "داده وضعیت نامعتبر است" }
            val jsonBytes = ByteArray(jsonLength)
            input.readFully(jsonBytes)
            val elapsedMs = (System.nanoTime() - started) / 1_000_000

            val root = JSONObject(String(jsonBytes, StandardCharsets.UTF_8))
            val version = root.optJSONObject("version")?.optString("name", "نامشخص") ?: "نامشخص"
            val players = root.optJSONObject("players")
            val online = players?.optInt("online", -1) ?: -1
            val max = players?.optInt("max", -1) ?: -1
            val playerText = if (online >= 0 && max >= 0) "$online / $max" else "نامشخص"
            return "سرور پاسخ داد ✓\nنسخه: $version\nبازیکنان: $playerText\nزمان پاسخ: ${elapsedMs}ms"
        }
    }

    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while ((v and -128) != 0) {
            out.writeByte((v and 127) or 128)
            v = v ushr 7
        }
        out.writeByte(v)
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0
        var position = 0
        while (true) {
            val current = input.readUnsignedByte()
            result = result or ((current and 127) shl position)
            if ((current and 128) == 0) return result
            position += 7
            require(position < 35) { "VarInt نامعتبر است" }
        }
    }
}


private fun normalizeDigits(s: String): String = buildString {
    for (c in s) append(when (c) {
        in '۰'..'۹' -> '0' + (c - '۰')
        in '٠'..'٩' -> '0' + (c - '٠')
        '،' -> ','
        '−' -> '-'
        else -> c
    })
}

/** دستورهای فارسی/انگلیسی را مرحله‌به‌مرحله روی بات اجرا می‌کند. */
private suspend fun executeCommands(bot: McBotSession, raw: String): String {
    val text = normalizeDigits(raw.trim())
    val steps = text.split(Regex("\\s*(?:\\n|;|؛|سپس|بعد از آن|\\s+و\\s+(?=منتظر|صبر|بگو|برو|قطع))\\s*"))
        .filter { it.isNotBlank() }
    if (steps.isEmpty()) return "دستور خالی است."
    val report = StringBuilder()
    for (step in steps) {
        if (!bot.connected) { report.appendLine("اتصال قطع است."); break }
        val lower = step.lowercase()
        val nums = Regex("-?\\d+(?:\\.\\d+)?").findAll(step).mapNotNull { it.value.toDoubleOrNull() }.toList()
        when {
            lower.startsWith("/") -> { bot.sendChat(step); report.appendLine("✓ دستور سرور: $step") }
            lower.startsWith("بگو") || lower.startsWith("say") || lower.startsWith("chat") -> {
                val msg = step.substringAfter(' ', "").trim()
                if (msg.isEmpty()) report.appendLine("✗ متن پیام مشخص نیست.")
                else { bot.sendChat(msg); report.appendLine("✓ پیام: $msg") }
            }
            (lower.contains("برو") || lower.contains("goto") || lower.contains("مختصات")) && nums.size >= 3 -> {
                bot.walkTo(nums[0], nums[1], nums[2])
                report.appendLine("✓ حرکت: ${nums[0]}, ${nums[1]}, ${nums[2]} (الان %.1f, %.1f, %.1f)".format(bot.x, bot.y, bot.z))
            }
            lower.contains("منتظر") || lower.contains("صبر") || lower.contains("wait") -> {
                val sec = (nums.firstOrNull() ?: 5.0).coerceIn(0.0, 600.0)
                delay((sec * 1000).toLong())
                report.appendLine("✓ ${sec.toInt()} ثانیه صبر کردم.")
            }
            lower.contains("قطع") || lower.contains("disconnect") || lower.contains("خروج") -> {
                bot.disconnect(); report.appendLine("✓ قطع شد."); break
            }
            lower.contains("وضعیت") || lower.contains("کجا") || lower.contains("status") ->
                report.appendLine("موقعیت: %.1f, %.1f, %.1f".format(bot.x, bot.y, bot.z))
            else -> report.appendLine("✗ نفهمیدم: $step")
        }
    }
    return report.toString().trim()
}
