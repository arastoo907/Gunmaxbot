package com.gunmax.bot

import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.zip.Deflater
import java.util.zip.Inflater
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/** شناسه پکت‌ها برای هر نسخه. */
data class McVersion(
    val label: String,
    val protocol: Int,
    val sKeepAlive: Int,
    val sDisconnect: Int,
    val sPosLook: Int,
    val cTeleportConfirm: Int,
    val cChat: Int,
    val cChatCommand: Int,
    val cKeepAlive: Int,
    val cPosition: Int,
    val experimental: Boolean = false
) {
    val keepAliveIsVarInt get() = protocol < 340
    val hasConfigState get() = protocol >= 764
    val signedChatFormat get() = protocol >= 762
    val maxChat get() = if (protocol < 107) 100 else 256

    companion object {
        val ALL = listOf(
            McVersion("1.8.9", 47, 0x00, 0x40, 0x08, -1, 0x01, -1, 0x00, 0x04),
            McVersion("1.12.2", 340, 0x1F, 0x1A, 0x2F, 0x00, 0x02, -1, 0x0B, 0x0D),
            McVersion("1.16.5", 754, 0x1F, 0x19, 0x34, 0x00, 0x03, -1, 0x10, 0x12),
            McVersion("1.18.2", 758, 0x21, 0x1A, 0x38, 0x00, 0x03, -1, 0x0F, 0x11),
            McVersion("1.19.4", 762, 0x23, 0x17, 0x3C, 0x00, 0x05, 0x04, 0x12, 0x14),
            McVersion("1.20.1", 763, 0x23, 0x17, 0x3C, 0x00, 0x05, 0x04, 0x12, 0x14),
            McVersion("1.20.4 (آزمایشی)", 765, 0x24, 0x1B, 0x3E, 0x00, 0x05, 0x04, 0x15, 0x17, true)
        )
    }
}

private enum class State { LOGIN, CONFIG, PLAY }

/**
 * یک اتصال بات به سرور Minecraft Java در حالت آفلاین (crack).
 * فقط برای سرورهای خودت یا سرورهایی که صراحتاً اجازه‌ی بات می‌دهند.
 */
class McBotSession(
    private val host: String,
    private val port: Int,
    private val version: McVersion,
    private val username: String,
    private val authPassword: String = "",
    private val log: (String) -> Unit
) {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: DataOutputStream? = null
    private val writeLock = Any()

    @Volatile private var state = State.LOGIN
    @Volatile private var compression = -1
    @Volatile var connected = false
        private set
    @Volatile var spawned = false
        private set
    @Volatile var x = 0.0
        private set
    @Volatile var y = 0.0
        private set
    @Volatile var z = 0.0
        private set
    @Volatile private var rubberBands = 0

    /** اتصال و ورود. روی thread پس‌زمینه صدا بزنید. */
    fun connect() {
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 8000)
        s.soTimeout = 60000
        socket = s
        input = s.getInputStream()
        output = DataOutputStream(s.getOutputStream())

        // Handshake
        sendRaw(0x00) {
            writeVarInt(it, version.protocol)
            writeString(it, host)
            it.writeShort(port)
            writeVarInt(it, 2)
        }
        // Login Start
        val uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$username".toByteArray(StandardCharsets.UTF_8))
        sendRaw(0x00) {
            writeString(it, username)
            if (version.protocol >= 764) {
                writeUuid(it, uuid)
            } else if (version.protocol >= 762) {
                it.writeBoolean(true)
                writeUuid(it, uuid)
            }
        }
        connected = true
        log("درخواست ورود با نام «$username» روی نسخه ${version.label} ارسال شد...")
        Thread({ readLoop() }, "mc-reader").apply { isDaemon = true }.start()
    }

    fun disconnect() {
        connected = false
        try { socket?.close() } catch (_: Exception) {}
    }

    fun sendChat(text: String) {
        if (!spawned) { log("هنوز وارد بازی نشده‌ام."); return }
        val msg = text.take(version.maxChat)
        if (msg.startsWith("/") && version.cChatCommand >= 0) {
            sendRaw(version.cChatCommand) {
                writeString(it, msg.removePrefix("/"))
                it.writeLong(System.currentTimeMillis())
                it.writeLong(0L)
                writeVarInt(it, 0)       // argument signatures
                writeVarInt(it, 0)       // message count
                it.write(ByteArray(3))   // acknowledged bitset (20 bits)
            }
        } else if (version.signedChatFormat) {
            sendRaw(version.cChat) {
                writeString(it, msg)
                it.writeLong(System.currentTimeMillis())
                it.writeLong(0L)
                it.writeBoolean(false)   // no signature
                writeVarInt(it, 0)
                it.write(ByteArray(3))
            }
        } else {
            sendRaw(version.cChat) { writeString(it, msg) }
        }
        log("پیام فرستاده شد: $msg")
    }

    /**
     * ثبت‌نام/لاگین خودکار برای سرورهای کرک با پلاگین AuthMe و مشابه.
     * اول /login می‌زند (اگر اکانت قبلاً ساخته شده)، بعد /register (اگر هنوز ثبت‌نام نشده).
     * پیام اضافه‌ی سرور («قبلاً ثبت‌نام کرده‌اید» و مشابه) بی‌ضرر است.
     */
    private fun autoAuth() {
        try {
            Thread.sleep(1500)
            if (!connected) return
            sendChat("/login $authPassword")
            Thread.sleep(1500)
            if (!connected) return
            sendChat("/register $authPassword $authPassword")
        } catch (_: InterruptedException) {}
    }

    /** حرکت خط مستقیم با سرعت پیاده‌روی (بدون مسیریابی و بدون برخورد). */
    suspend fun walkTo(tx: Double, ty: Double, tz: Double) {
        if (!spawned) { log("هنوز وارد بازی نشده‌ام."); return }
        log("حرکت به سمت %.1f, %.1f, %.1f".format(tx, ty, tz))
        rubberBands = 0
        val deadline = System.currentTimeMillis() + 180_000
        while (connected && System.currentTimeMillis() < deadline) {
            val dx = tx - x
            val dy = ty - y
            val dz = tz - z
            val dist = sqrt(dx * dx + dy * dy + dz * dz)
            if (dist < 0.25) break
            if (rubberBands > 8) {
                log("سرور مدام موقعیت را برگرداند (مانع یا محدودیت). حرکت متوقف شد.")
                return
            }
            val step = min(0.2, dist)
            x += dx / dist * step
            y += dy / dist * step
            z += dz / dist * step
            sendPosition()
            delay(50)
        }
        log("رسیدم: %.1f, %.1f, %.1f".format(x, y, z))
    }

    private fun sendPosition() {
        sendRaw(version.cPosition) {
            it.writeDouble(x)
            it.writeDouble(y)
            it.writeDouble(z)
            it.writeBoolean(true)
        }
    }

    // ---------------- خواندن ----------------

    private fun readLoop() {
        try {
            val din = DataInputStream(input)
            while (connected) {
                val length = readVarInt(din)
                if (length <= 0 || length > 4_000_000) throw IllegalStateException("طول پکت نامعتبر")
                val raw = ByteArray(length)
                din.readFully(raw)
                var body = raw
                if (compression >= 0) {
                    val bin = DataInputStream(ByteArrayInputStream(raw))
                    val dataLen = readVarInt(bin)
                    val rest = ByteArray(bin.available())
                    bin.readFully(rest)
                    body = if (dataLen == 0) rest else {
                        val inf = Inflater()
                        inf.setInput(rest)
                        val out = ByteArray(dataLen)
                        var off = 0
                        while (off < dataLen && !inf.finished()) {
                            val n = inf.inflate(out, off, dataLen - off)
                            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                            off += n
                        }
                        inf.end()
                        out
                    }
                }
                val p = DataInputStream(ByteArrayInputStream(body))
                handle(readVarInt(p), p)
            }
        } catch (e: Exception) {
            if (connected) log("اتصال قطع شد (${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"})")
        } finally {
            connected = false
            spawned = false
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    private fun handle(id: Int, p: DataInputStream) {
        when (state) {
            State.LOGIN -> when (id) {
                0x00 -> { log("سرور رد کرد: ${chatText(readString(p))}"); disconnect() }
                0x01 -> {
                    log("این سرور آنلاین‌مود (اکانت اصلی) است. این نسخه فقط سرورهای آفلاین را پشتیبانی می‌کند.")
                    disconnect()
                }
                0x03 -> compression = readVarInt(p)
                0x02 -> {
                    if (version.hasConfigState) {
                        sendRaw(0x03) { }
                        state = State.CONFIG
                    } else {
                        state = State.PLAY
                    }
                    log("ورود موفق ✓")
                }
            }
            State.CONFIG -> when (id) {
                0x01 -> { log("سرور در مرحله پیکربندی قطع کرد."); disconnect() }
                0x02 -> { sendRaw(0x02) { }; state = State.PLAY }
                0x03 -> { val v = p.readLong(); sendRaw(0x03) { it.writeLong(v) } }
                0x04 -> { val v = p.readInt(); sendRaw(0x04) { it.writeInt(v) } }
            }
            State.PLAY -> when (id) {
                version.sKeepAlive -> {
                    if (version.keepAliveIsVarInt) {
                        val v = readVarInt(p)
                        sendRaw(version.cKeepAlive) { writeVarInt(it, v) }
                    } else {
                        val v = p.readLong()
                        sendRaw(version.cKeepAlive) { it.writeLong(v) }
                    }
                }
                version.sDisconnect -> {
                    val reason = if (version.protocol >= 765) "" else try { chatText(readString(p)) } catch (_: Exception) { "" }
                    log("از سرور بیرون انداخته شدم. دلیل: ${if (reason.isNotBlank()) reason else "(سرور دلیلی ارسال نکرد)"}")
                    disconnect()
                }
                version.sPosLook -> {
                    val nx = p.readDouble(); val ny = p.readDouble(); val nz = p.readDouble()
                    p.readFloat(); p.readFloat()
                    val flags = p.readUnsignedByte()
                    x = if (flags and 1 != 0) x + nx else nx
                    y = if (flags and 2 != 0) y + ny else ny
                    z = if (flags and 4 != 0) z + nz else nz
                    if (version.cTeleportConfirm >= 0) {
                        val tid = readVarInt(p)
                        sendRaw(version.cTeleportConfirm) { writeVarInt(it, tid) }
                    }
                    sendPosition()
                    if (!spawned) {
                        spawned = true
                        log("وارد دنیا شدم. موقعیت: %.1f, %.1f, %.1f".format(x, y, z))
                        if (authPassword.isNotEmpty()) Thread({ autoAuth() }, "mc-auth").apply { isDaemon = true }.start()
                    } else {
                        rubberBands++
                    }
                }
            }
        }
    }

    // ---------------- نوشتن ----------------

    private fun sendRaw(id: Int, build: (DataOutputStream) -> Unit) {
        val buf = ByteArrayOutputStream()
        val d = DataOutputStream(buf)
        writeVarInt(d, id)
        build(d)
        val payload = buf.toByteArray()
        synchronized(writeLock) {
            val out = output ?: return
            try {
                val frame = ByteArrayOutputStream()
                val f = DataOutputStream(frame)
                if (compression < 0) {
                    writeVarInt(f, payload.size)
                    f.write(payload)
                } else if (payload.size < compression) {
                    writeVarInt(f, payload.size + 1)
                    writeVarInt(f, 0)
                    f.write(payload)
                } else {
                    val def = Deflater()
                    def.setInput(payload)
                    def.finish()
                    val tmp = ByteArray(payload.size + 64)
                    val n = def.deflate(tmp)
                    def.end()
                    val lenBuf = ByteArrayOutputStream()
                    writeVarInt(DataOutputStream(lenBuf), payload.size)
                    writeVarInt(f, lenBuf.size() + n)
                    f.write(lenBuf.toByteArray())
                    f.write(tmp, 0, n)
                }
                out.write(frame.toByteArray())
                out.flush()
            } catch (e: Exception) {
                if (connected) { connected = false; log("ارسال ناموفق: ${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"}") }
            }
        }
    }

    private fun chatText(json: String): String = try {
        val o = JSONObject(json)
        val sb = StringBuilder(o.optString("text", ""))
        o.optJSONArray("extra")?.let { for (i in 0 until it.length()) sb.append(it.optJSONObject(i)?.optString("text", "") ?: "") }
        if (sb.isNotEmpty()) sb.toString() else o.optString("translate", json)
    } catch (_: Exception) { json }

    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while ((v and -128) != 0) {
            out.writeByte((v and 127) or 128)
            v = v ushr 7
        }
        out.writeByte(v)
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0
        var pos = 0
        while (true) {
            val cur = input.readUnsignedByte()
            result = result or ((cur and 127) shl pos)
            if ((cur and 128) == 0) return result
            pos += 7
            if (pos >= 35) throw IllegalStateException("VarInt نامعتبر")
        }
    }

    private fun writeString(out: DataOutputStream, s: String) {
        val b = s.toByteArray(StandardCharsets.UTF_8)
        writeVarInt(out, b.size)
        out.write(b)
    }

    private fun readString(input: DataInputStream): String {
        val len = readVarInt(input)
        if (len < 0 || len > 262144) throw IllegalStateException("رشته نامعتبر")
        val b = ByteArray(len)
        input.readFully(b)
        return String(b, StandardCharsets.UTF_8)
    }

    private fun writeUuid(out: DataOutputStream, u: UUID) {
        out.writeLong(u.mostSignificantBits)
        out.writeLong(u.leastSignificantBits)
    }
}
