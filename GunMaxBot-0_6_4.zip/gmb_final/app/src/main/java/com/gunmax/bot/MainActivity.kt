package com.gunmax.bot

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.nio.charset.StandardCharsets
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF07110F)
private val Panel = Color(0xFF101D19)
private val Panel2 = Color(0xFF172923)
private val Mint = Color(0xFF39D6A0)
private val Muted = Color(0xFF9AB0A8)
private val White = Color(0xFFEAF5F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GunMaxApp() }
    }
}

@Composable
fun GunMaxApp() {
    val ctx = LocalContext.current
    val store = remember { AppStore(ctx) }
    var command by remember { mutableStateOf("") }
    var commandResult by remember { mutableStateOf("هنوز دستوری ثبت نشده است.") }
    var selected by remember { mutableStateOf("داشبورد") }
    var serverHost by remember { mutableStateOf(store.str("host", "play.gunmax.org")) }
    var serverPort by remember { mutableStateOf(store.str("port", "25565")) }
    var pingState by remember { mutableStateOf("هنوز بررسی نشده") }
    var checking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bots = listOf("بات شماره ۱", "بات شماره ۲", "بات شماره ۳")
    var idsRev by remember { mutableStateOf(0) }
    var versionLabel by remember { mutableStateOf(store.str("version", "1.20.1")) }
    val selectedVersion = remember(versionLabel, idsRev) { McVersion.resolve(versionLabel, store) }
    var versionMenu by remember { mutableStateOf(false) }
    var botName by remember { mutableStateOf(store.str("botName", "GunMax_1")) }
    var botPassword by remember { mutableStateOf(store.str("botPass", "")) }
    var authMode by remember { mutableStateOf(runCatching { AuthMode.valueOf(store.str("authMode", "LOGIN")) }.getOrDefault(AuthMode.LOGIN)) }
    var loginTpl by remember { mutableStateOf(store.str("loginTpl", "/login {pass}")) }
    var registerTpl by remember { mutableStateOf(store.str("registerTpl", "/register {pass} {pass}")) }
    var loader by remember { mutableStateOf(store.str("loader", "vanilla")) }
    var loaderMenu by remember { mutableStateOf(false) }
    var mods by remember { mutableStateOf(store.mods()) }
    var activeMod by remember { mutableStateOf(store.str("activeMod", "")) }
    var idsDialog by remember { mutableStateOf(false) }
    var autoReconnect by remember { mutableStateOf(store.str("autoRe", "0") == "1") }
    var reconnectDelay by remember { mutableStateOf(store.str("reDelay", "10")) }
    var reconnectMax by remember { mutableStateOf(store.str("reMax", "0")) }   // 0 = بی‌نهایت
    var pendingReconnect by remember { mutableStateOf(false) }
    var reconnectIn by remember { mutableStateOf(0) }
    var retries by remember { mutableStateOf(0) }
    var lastMode by remember { mutableStateOf(AuthMode.LOGIN) }
    var session by remember { mutableStateOf<McBotSession?>(null) }
    var connecting by remember { mutableStateOf(false) }
    var botState by remember { mutableStateOf(0) } // 0 آفلاین، 1 در حال ورود، 2 داخل بازی
    val logs = remember { mutableStateListOf<String>() }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    fun addLog(m: String) {
        logs.add(0, "[${timeFmt.format(Date())}] $m")
        while (logs.size > 200) logs.removeAt(logs.size - 1)
    }

    LaunchedEffect(serverHost, serverPort, botName, botPassword, authMode, loginTpl, registerTpl, versionLabel, loader, activeMod, autoReconnect, reconnectDelay, reconnectMax) {
        store.put("autoRe", if (autoReconnect) "1" else "0"); store.put("reDelay", reconnectDelay); store.put("reMax", reconnectMax)
        store.put("host", serverHost); store.put("port", serverPort); store.put("botName", botName)
        store.put("botPass", botPassword); store.put("authMode", authMode.name)
        store.put("loginTpl", loginTpl); store.put("registerTpl", registerTpl)
        store.put("version", versionLabel); store.put("loader", loader); store.put("activeMod", activeMod)
    }

    // انتخاب فایل مود (.jar) از حافظه‌ی گوشی
    val pickMod = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val mcNow = versionLabel
            scope.launch(Dispatchers.IO) {
                try {
                    var name = "mod_${System.currentTimeMillis()}.jar"
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
                    }
                    val dest = File(store.modsDir(), name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    ctx.contentResolver.openInputStream(uri)!!.use { inp -> dest.outputStream().use { inp.copyTo(it) } }
                    val info = ModTools.inspect(dest, mcNow)
                    withContext(Dispatchers.Main) {
                        if (info == null) {
                            dest.delete()
                            addLog("✗ این فایل یک مود معتبر Fabric / Quilt / Forge نیست.")
                        } else {
                            val list = mods.filter { it.file != info.file } + info
                            mods = list; store.saveMods(list)
                            activeMod = info.file; loader = info.loader
                            addLog("✓ مود «${info.name}» ${info.version} (${ModTools.loaderTitle(info.loader)}) برای $mcNow بارگذاری و فعال شد.")
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { addLog("✗ خواندن مود ناموفق: ${e.message ?: e.javaClass.simpleName}") }
                }
            }
        }
    }

    // یک تابع مشترک برای وصل/قطع، هم از کارت «ورود بات» و هم از دکمه «کنترل مرکزی» صدا زده می‌شود
    fun toggleBot(mode: AuthMode = authMode) {
        val cur = session
        pendingReconnect = false
        if (cur != null && cur.connected) {
            cur.stop()
            addLog("دستور قطع اتصال صادر شد.")
            return
        }
        val port = serverPort.toIntOrNull()
        if (serverHost.isBlank() || port == null || port !in 1..65535 || botName.length < 3) {
            addLog("✗ آدرس، پورت یا نام بات نامعتبر است (نام بات حداقل ۳ کاراکتر).")
            return
        }
        val tpl = if (mode == AuthMode.LOGIN) loginTpl else registerTpl
        if (mode != AuthMode.NONE && tpl.isBlank()) {
            addLog("✗ دستور ${if (mode == AuthMode.LOGIN) "لاگین" else "ریجستر"} در تنظیمات خالی است.")
            return
        }
        if (mode != AuthMode.NONE && tpl.contains("{pass}") && botPassword.isBlank()) {
            addLog("✗ دستور شامل {pass} است ولی رمز خالی است. یا رمز را بگذار یا دستور کامل را بنویس (مثلاً /login 1234).")
            return
        }
        authMode = mode
        lastMode = mode
        connecting = true
        val brand = ModTools.brandFor(loader)
        val s = McBotSession(serverHost.trim(), port, selectedVersion, botName, botPassword,
            mode, loginTpl, registerTpl, brand) { m ->
            scope.launch { addLog(m) }
        }
        session = s
        val modeText = when (mode) { AuthMode.LOGIN -> "حالت لاگین"; AuthMode.REGISTER -> "حالت ریجستر"; else -> "بدون لاگین/ریجستر" }
        addLog("در حال اتصال به ${serverHost.trim()}:$port با نام «$botName» (${selectedVersion.label}، ${ModTools.loaderTitle(loader)}، $modeText)...")
        mods.firstOrNull { it.file == activeMod }?.let {
            addLog("مود فعال: ${it.name} ${it.version} (${ModTools.loaderTitle(it.loader)})")
        }
        scope.launch(Dispatchers.IO) {
            try {
                s.connect()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    addLog("✗ اتصال برقرار نشد: ${e.javaClass.simpleName} — ${e.message ?: "بدون پیام خطا"}")
                    if (autoReconnect && !s.manualStop) pendingReconnect = true
                }
            }
            withContext(Dispatchers.Main) { connecting = false }
        }
    }

    LaunchedEffect(session) {
        var prev = 0
        while (true) {
            val cur = session
            val ns = when {
                cur == null || !cur.connected -> 0
                cur.spawned -> 2
                else -> 1
            }
            if (ns == 2) retries = 0
            if (prev != 0 && ns == 0 && cur != null && !cur.manualStop && autoReconnect) pendingReconnect = true
            botState = ns
            prev = ns
            delay(500)
        }
    }

    // اتو ری‌کانکت: بعد از قطع‌شدن (نه قطع دستی) به اندازه‌ی تایمی که خودت گذاشتی صبر می‌کند و دوباره وصل می‌شود
    LaunchedEffect(pendingReconnect) {
        if (!pendingReconnect) { reconnectIn = 0; return@LaunchedEffect }
        val max = reconnectMax.toIntOrNull() ?: 0
        if (max > 0 && retries >= max) {
            addLog("⏹ اتو ری‌کانکت بعد از $max تلاش متوقف شد.")
            pendingReconnect = false
            return@LaunchedEffect
        }
        val wait = (reconnectDelay.toIntOrNull() ?: 10).coerceIn(1, 3600)
        addLog("🔁 اتصال دوباره تا $wait ثانیه‌ی دیگر...")
        for (i in wait downTo 1) { reconnectIn = i; delay(1000) }
        reconnectIn = 0
        retries++
        pendingReconnect = false
        toggleBot(lastMode)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Mint,
        onBackground = White, onSurface = White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (idsDialog) {
                IdsDialog(selectedVersion, store, onDismiss = { idsDialog = false }, onSaved = { idsRev++; idsDialog = false })
            }
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Mint) {
                        listOf("داشبورد" to Icons.Default.Dashboard,
                            "بات‌ها" to Icons.Default.SmartToy,
                            "کنسول" to Icons.Default.Terminal,
                            "تنظیمات" to Icons.Default.Settings).forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = selected == label,
                                onClick = { selected = label },
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Mint, selectedTextColor = Mint,
                                    indicatorColor = Panel2, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()) {
                            Column {
                                Text("گانمکس بات", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
                                Text("مدیریت هوشمند بات‌های Minecraft", color = Muted, fontSize = 12.sp)
                            }
                            Surface(shape = RoundedCornerShape(16.dp), color = Mint.copy(alpha = .16f)) {
                                Icon(Icons.Default.Diamond, null, tint = Mint, modifier = Modifier.padding(14.dp).size(28.dp))
                            }
                        }
                    }
                    when (selected) {
                        "داشبورد" -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StatCard("بات‌های فعال", if (botState == 2) "۱ / ۱" else "۰ / ۱", Icons.Default.SmartToy, Modifier.weight(1f))
                                    StatCard("وظایف امروز", "۰", Icons.Default.TaskAlt, Modifier.weight(1f))
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Hub, null, tint = Mint)
                                            Spacer(Modifier.width(8.dp))
                                            Text("کنترل مرکزی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                            Spacer(Modifier.weight(1f))
                                            Surface(color = if (botState != 0) Mint.copy(alpha=.18f) else Panel2, shape = RoundedCornerShape(30.dp)) {
                                                Text(
                                                    when (botState) { 2 -> "آنلاین"; 1 -> "در حال ورود"; else -> "متوقف" },
                                                    color = if (botState != 0) Mint else Muted,
                                                    modifier = Modifier.padding(horizontal=12.dp, vertical=6.dp), fontSize=12.sp
                                                )
                                            }
                                        }
                                        // این دکمه حالا واقعاً بات را با تنظیمات فعلی (آدرس/پورت/نام/نسخه در تب «تنظیمات») وصل یا قطع می‌کند
                                        Button(
                                            onClick = { toggleBot() },
                                            enabled = !connecting,
                                            modifier = Modifier.fillMaxWidth().height(52.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (botState != 0) Color(0xFFB83D62) else Mint),
                                            shape = RoundedCornerShape(15.dp)
                                        ) {
                                            Icon(if (botState != 0) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                if (connecting) "در حال اتصال..." else if (botState != 0) "قطع اتصال بات" else "اتصال بات",
                                                color = Color(0xFF06110D), fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text("آدرس، پورت، نام و نسخه را از تب «تنظیمات» عوض کن.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Text("آخرین رویدادها", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (logs.isEmpty()) {
                                            LogLine("سیستم", "آماده. از تب بات‌ها شروع کن.", Mint)
                                        } else {
                                            logs.take(5).forEach { LogLine("بات", it, Mint) }
                                            TextButton(onClick = { selected = "کنسول" }) { Text("مشاهده کنسول کامل ›", color = Mint) }
                                        }
                                    }
                                }
                            }
                        }
                        "بات‌ها" -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("وضعیت واقعی سرور Minecraft", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("آدرس فعلی: $serverHost:$serverPort (قابل تغییر در تنظیمات)", color = Muted, fontSize = 11.sp)
                                        Button(onClick = {
                                            val port = serverPort.toIntOrNull()
                                            if (serverHost.isBlank() || port == null || port !in 1..65535) {
                                                pingState = "آدرس یا پورت نامعتبر است"
                                            } else {
                                                checking = true
                                                pingState = "در حال دریافت وضعیت Minecraft..."
                                                scope.launch {
                                                    val result = withContext(Dispatchers.IO) {
                                                        try {
                                                            MinecraftStatusClient.query(serverHost.trim(), port)
                                                        } catch (e: Exception) {
                                                            "اتصال برقرار نشد: ${e.javaClass.simpleName} — ${e.message ?: "بدون جزئیات"}"
                                                        }
                                                    }
                                                    pingState = result
                                                    checking = false
                                                }
                                            }
                                        }, enabled = !checking, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Text(if (checking) "در حال بررسی..." else "بررسی اتصال", color = Bg)
                                        }
                                        Text(pingState, color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("ورود بات به سرور", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("نام: $botName • نسخه: ${selectedVersion.label} • لودر: ${ModTools.loaderTitle(loader)} (قابل تغییر در تنظیمات)", color = Muted, fontSize = 11.sp)
                                        if (botState != 0) {
                                            Button(
                                                onClick = { toggleBot() },
                                                enabled = !connecting,
                                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB83D62))
                                            ) {
                                                Text("قطع اتصال بات", color = Bg, fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            // دو دکمه‌ی جدا: لاگین همیشه فقط /login می‌زند، ریجستر همیشه فقط /register
                                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                                Button(
                                                    onClick = { toggleBot(AuthMode.LOGIN) },
                                                    enabled = !connecting,
                                                    modifier = Modifier.weight(1f).height(50.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = Mint)
                                                ) { Text("ورود (لاگین)", color = Bg, fontWeight = FontWeight.Bold) }
                                                Button(
                                                    onClick = { toggleBot(AuthMode.REGISTER) },
                                                    enabled = !connecting,
                                                    modifier = Modifier.weight(1f).height(50.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5BA8F5))
                                                ) { Text("ثبت‌نام (ریجستر)", color = Bg, fontWeight = FontWeight.Bold) }
                                            }
                                            TextButton(onClick = { toggleBot(AuthMode.NONE) }, enabled = !connecting, modifier = Modifier.fillMaxWidth()) {
                                                Text("ورود بدون لاگین/ریجستر", color = Muted, fontSize = 12.sp)
                                            }
                                        }
                                        Text(
                                            when {
                                                botState == 2 -> "بات داخل بازی است ✓"
                                                botState == 1 -> "در حال ورود..."
                                                pendingReconnect -> "آفلاین • ری‌کانکت تا $reconnectIn ثانیه"
                                                else -> "آفلاین"
                                            },
                                            color = Muted, fontSize = 12.sp
                                        )
                                        Text("فقط سرورهای آفلاین‌مود (کرک) پشتیبانی می‌شود. از بات فقط روی سرور خودت یا سروری که اجازه داده استفاده کن.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("دستور هوشمند", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("دستورت را فارسی بنویس؛ بات روی سرور اجرا می‌کند (حرکت مستقیم، انتظار، چت و دستور سرور).", color = Muted, fontSize = 12.sp)
                                        Surface(color = Bg, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                            BasicTextField(
                                                value = command, onValueChange = { command = it },
                                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                                textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
                                                decorationBox = { inner ->
                                                    if (command.isEmpty()) Text("مثلاً: برو به فروشگاه و موجودی را بررسی کن...", color = Muted)
                                                    inner()
                                                }
                                            )
                                        }
                                        Button(onClick = {
                                            val cur = session
                                            if (cur == null || botState != 2) {
                                                commandResult = "اول بات را وارد سرور کن."
                                            } else {
                                                commandResult = "در حال اجرا..."
                                                val text = command
                                                scope.launch(Dispatchers.IO) {
                                                    val r = executeCommands(cur, text)
                                                    withContext(Dispatchers.Main) { commandResult = r }
                                                }
                                            }
                                        }, enabled = command.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Icon(Icons.Default.AutoAwesome, null, tint = Bg)
                                            Spacer(Modifier.width(8.dp))
                                            Text("اجرای دستور", color = Bg, fontWeight = FontWeight.Bold)
                                        }
                                        Surface(color = Panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text(commandResult, color = White, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                                        }
                                        Text("نمونه: برو به مختصات 250 40 120 و منتظر بمان 5 ثانیه سپس بگو سلام | /home | قطع شو", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Text("اکانت‌های بات", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                            items(3) { index ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                                            Icon(Icons.Default.SmartToy, null, tint = Mint, modifier = Modifier.padding(11.dp))
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(bots[index], fontWeight = FontWeight.SemiBold)
                                            Text(if (index == 0) "${botName} • ${selectedVersion.label}" else "هنوز پیکربندی نشده", color = Muted, fontSize = 11.sp)
                                        }
                                        Surface(color = Color(0xFF39453F), shape = RoundedCornerShape(30.dp)) {
                                            Text(if (index == 0 && botState == 2) "آنلاین" else if (index == 0 && botState == 1) "در حال ورود" else "آفلاین", color = if (index == 0 && botState == 2) Mint else Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal=10.dp, vertical=6.dp))
                                        }
                                    }
                                }
                            }
                        }
                        "کنسول" -> {
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("کنسول کامل", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { logs.clear() }) { Text("پاک کردن", color = Muted) }
                                }
                            }
                            item {
                                Text(
                                    "همه‌ی رویدادها، خطاها و دلیل قطع اتصال اینجا با زمان دقیق ثبت می‌شود.",
                                    color = Muted, fontSize = 12.sp
                                )
                            }
                            if (logs.isEmpty()) {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                                        Text("هنوز رویدادی ثبت نشده.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
                                    }
                                }
                            } else {
                                items(logs.size) { i ->
                                    Surface(color = Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Text(
                                            logs[i], color = if (logs[i].contains("✗") || logs[i].contains("بیرون انداخته") || logs[i].contains("قطع شد")) Color(0xFFE8738B) else White,
                                            fontSize = 12.sp, modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                        "تنظیمات" -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("تنظیمات اتصال", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(value = serverHost, onValueChange = { serverHost = it }, label = { Text("آدرس سرور") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = serverPort, onValueChange = { serverPort = it.filter(Char::isDigit).take(5) }, label = { Text("پورت") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(
                                            value = botName,
                                            onValueChange = { botName = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(16) },
                                            label = { Text("نام بات (انگلیسی)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = botPassword,
                                            onValueChange = { botPassword = it.filter { c -> !c.isWhitespace() }.take(32) },
                                            label = { Text("رمز بات (فقط اگه تو دستور {pass} نوشتی)") }, singleLine = true,
                                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Text("حالت پیش‌فرض دکمه‌ی «اتصال بات» در داشبورد:", color = Muted, fontSize = 12.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                            listOf(AuthMode.LOGIN to "فقط لاگین", AuthMode.REGISTER to "فقط ریجستر", AuthMode.NONE to "هیچ‌کدام").forEach { (m, t) ->
                                                Button(
                                                    onClick = { authMode = m },
                                                    modifier = Modifier.weight(1f),
                                                    contentPadding = PaddingValues(horizontal = 4.dp),
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = if (authMode == m) Mint else Panel2,
                                                        contentColor = if (authMode == m) Bg else White
                                                    )
                                                ) { Text(t, fontSize = 12.sp) }
                                            }
                                        }
                                        OutlinedTextField(value = loginTpl, onValueChange = { loginTpl = it }, label = { Text("دستور لاگین کامل (مثلاً /login 1234)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = registerTpl, onValueChange = { registerTpl = it }, label = { Text("دستور ریجستر کامل (مثلاً /register 1234 1234)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Text("اتو ری‌کانکت (وصل‌شدن دوباره بعد از قطع)", modifier = Modifier.weight(1f), fontSize = 13.sp)
                                            Switch(checked = autoReconnect, onCheckedChange = { autoReconnect = it; if (!it) pendingReconnect = false })
                                        }
                                        if (autoReconnect) {
                                            OutlinedTextField(value = reconnectDelay, onValueChange = { reconnectDelay = it.filter(Char::isDigit).take(4) },
                                                label = { Text("تایم ری‌کانکت (ثانیه)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(value = reconnectMax, onValueChange = { reconnectMax = it.filter(Char::isDigit).take(3) },
                                                label = { Text("حداکثر تلاش پشت‌سرهم (۰ = بی‌نهایت)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        }
                                        Box(Modifier.fillMaxWidth()) {
                                            OutlinedButton(onClick = { versionMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text("نسخه‌ی ورود: ${selectedVersion.label}", color = White)
                                            }
                                            DropdownMenu(expanded = versionMenu, onDismissRequest = { versionMenu = false }) {
                                                McVersion.ALL.forEach { v ->
                                                    DropdownMenuItem(
                                                        text = { Text(v.label) },
                                                        onClick = { versionLabel = v.label; versionMenu = false }
                                                    )
                                                }
                                            }
                                        }
                                        Box(Modifier.fillMaxWidth()) {
                                            OutlinedButton(onClick = { loaderMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text("لودر: ${ModTools.loaderTitle(loader)}", color = White)
                                            }
                                            DropdownMenu(expanded = loaderMenu, onDismissRequest = { loaderMenu = false }) {
                                                ModTools.LOADERS.forEach { l ->
                                                    DropdownMenuItem(text = { Text(ModTools.loaderTitle(l)) }, onClick = { loader = l; loaderMenu = false })
                                                }
                                            }
                                        }
                                        if (selectedVersion.experimental) {
                                            Text("⚠️ این نسخه آزمایشی است و شناسه‌ی پکت‌هایش روی همه‌ی سرورها تست نشده. اگر نپرید/تایم‌اوت شد، از دکمه‌ی زیر شناسه‌ها را اصلاح کن.", color = Color(0xFFE8B96B), fontSize = 11.sp)
                                        }
                                        OutlinedButton(onClick = { idsDialog = true }, modifier = Modifier.fillMaxWidth()) {
                                            Text("ویرایش شناسه‌ی پکت‌های ${selectedVersion.label}", color = White, fontSize = 12.sp)
                                        }
                                        Text("این تنظیمات برای دکمه‌های اتصال در تب‌های داشبورد و بات‌ها استفاده می‌شود.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("مود و لودر (Fabric / Forge ...)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("فایل .jar مود را بارگذاری کن؛ بات با همان نسخه و لودر وارد سرور می‌شود (نام کلاینت مثلاً fabric اعلام می‌شود و جواب پرس‌وجوهای Fabric API داده می‌شود). بات یک کلاینت واقعی نیست و کد مود را اجرا نمی‌کند؛ هندشیک کامل مودهای Forge پشتیبانی نمی‌شود.", color = Muted, fontSize = 11.sp)
                                        Button(onClick = { pickMod.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Icon(Icons.Default.Add, null, tint = Bg)
                                            Spacer(Modifier.width(8.dp))
                                            Text("بارگذاری فایل مود (.jar) برای ${selectedVersion.label}", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        if (mods.isEmpty()) {
                                            Text("هنوز مودی بارگذاری نشده.", color = Muted, fontSize = 12.sp)
                                        }
                                        mods.forEach { m ->
                                            val active = m.file == activeMod
                                            Surface(color = if (active) Mint.copy(alpha = .14f) else Panel2, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Column(Modifier.weight(1f)) {
                                                        Text(m.name + " " + m.version, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                        Text("${ModTools.loaderTitle(m.loader)} • ${m.mc}${if (active) " • فعال" else ""}", color = Muted, fontSize = 11.sp)
                                                    }
                                                    if (!active) {
                                                        TextButton(onClick = { activeMod = m.file; versionLabel = m.mc; loader = m.loader }) { Text("استفاده", color = Mint) }
                                                    }
                                                    TextButton(onClick = {
                                                        File(store.modsDir(), m.file).delete()
                                                        val list = mods.filter { it.file != m.file }
                                                        mods = list; store.saveMods(list)
                                                        if (activeMod == m.file) activeMod = ""
                                                    }) { Text("حذف", color = Color(0xFFE8738B)) }
                                                }
                                            }
                                        }
                                        if (activeMod.isNotEmpty()) {
                                            TextButton(onClick = { activeMod = "" }, modifier = Modifier.fillMaxWidth()) { Text("غیرفعال کردن مود", color = Muted) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IdsDialog(v: McVersion, store: AppStore, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val base = McVersion.ALL.first { it.label == v.label }
    val fields = listOf(
        "sKeepAlive" to "Keep-Alive از سرور",
        "sDisconnect" to "Disconnect (بیرون‌انداختن) از سرور",
        "sPosLook" to "موقعیت بات از سرور",
        "sSystemChat" to "پیام چت سیستم از سرور",
        "cKeepAlive" to "Keep-Alive به سرور",
        "cPosition" to "موقعیت به سرور",
        "cChat" to "چت به سرور",
        "cChatCommand" to "دستور (/) به سرور"
    )
    fun valueOf(m: McVersion, k: String) = when (k) {
        "sKeepAlive" -> m.sKeepAlive; "sDisconnect" -> m.sDisconnect; "sPosLook" -> m.sPosLook
        "sSystemChat" -> m.sSystemChat; "cKeepAlive" -> m.cKeepAlive; "cPosition" -> m.cPosition
        "cChat" -> m.cChat; else -> m.cChatCommand
    }
    val texts = remember { mutableStateMapOf<String, String>().apply { fields.forEach { (k, _) -> put(k, "%02X".format(maxOf(valueOf(v, k), 0))) } } }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("شناسه‌ی پکت‌ها (هگز)", fontSize = 16.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("عددها هگز هستند (مثلاً 2B). مقدار درست را از minecraft.wiki بخش Java Edition protocol یا از هشدار کنسول بردار.", color = Muted, fontSize = 11.sp)
                fields.forEach { (k, title) ->
                    if (valueOf(base, k) >= 0) {
                        OutlinedTextField(
                            value = texts[k] ?: "", onValueChange = { t -> texts[k] = t.filter { it.isLetterOrDigit() }.take(3).uppercase() },
                            label = { Text(title, fontSize = 12.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val o = mutableMapOf<String, Int>()
                fields.forEach { (k, _) ->
                    val n = texts[k]?.toIntOrNull(16)
                    if (n != null && valueOf(base, k) >= 0 && n != valueOf(base, k)) o[k] = n
                }
                store.saveIdOverrides(base.label, o)
                onSaved()
            }) { Text("ذخیره", color = Mint) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { store.saveIdOverrides(base.label, emptyMap()); onSaved() }) { Text("بازنشانی", color = Muted) }
                TextButton(onClick = onDismiss) { Text("بستن", color = Muted) }
            }
        }
    )
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Mint)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun LogLine(tag: String, message: String, color: Color) {
    Row(verticalAlignment = Alignment.Top) {
        Text(tag, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(58.dp))
        Text(message, color = Muted, fontSize = 12.sp)
    }
}


/** Performs the Minecraft Java Server List Ping (status) exchange. */
private object MinecraftStatusClient {
    fun query(host: String, port: Int): String {
        val started = System.nanoTime()
        Socket().use { socket ->
            socket.tcpNoDelay = true
            socket.soTimeout = 7000
            socket.connect(InetSocketAddress(host, port), 5000)
            val output = DataOutputStream(socket.getOutputStream())
            val input = DataInputStream(socket.getInputStream())

            val hostBytes = host.toByteArray(StandardCharsets.UTF_8)
            val handshake = java.io.ByteArrayOutputStream().also { bytes ->
                val packet = DataOutputStream(bytes)
                writeVarInt(packet, 0) // handshake packet id
                writeVarInt(packet, -1) // status-only protocol version
                writeVarInt(packet, hostBytes.size)
                packet.write(hostBytes)
                packet.writeShort(port)
                writeVarInt(packet, 1) // next state: status
            }.toByteArray()
            writeVarInt(output, handshake.size)
            output.write(handshake)

            writeVarInt(output, 1) // status request packet length
            writeVarInt(output, 0) // status request packet id
            output.flush()

            val packetLength = readVarInt(input)
            require(packetLength in 1..1_048_576) { "پاسخ سرور نامعتبر است" }
            val packetId = readVarInt(input)
            require(packetId == 0) { "پاسخ وضعیت شناخته نشد" }
            val jsonLength = readVarInt(input)
            require(jsonLength in 1..1_000_000) { "داده وضعیت نامعتبر است" }
            val jsonBytes = ByteArray(jsonLength)
            input.readFully(jsonBytes)
            val elapsedMs = (System.nanoTime() - started) / 1_000_000

            val root = JSONObject(String(jsonBytes, StandardCharsets.UTF_8))
            val version = root.optJSONObject("version")?.optString("name", "نامشخص") ?: "نامشخص"
            val players = root.optJSONObject("players")
            val online = players?.optInt("online", -1) ?: -1
            val max = players?.optInt("max", -1) ?: -1
            val playerText = if (online >= 0 && max >= 0) "$online / $max" else "نامشخص"
            return "سرور پاسخ داد ✓\nنسخه: $version\nبازیکنان: $playerText\nزمان پاسخ: ${elapsedMs}ms"
        }
    }

    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while ((v and -128) != 0) {
            out.writeByte((v and 127) or 128)
            v = v ushr 7
        }
        out.writeByte(v)
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0
        var position = 0
        while (true) {
            val current = input.readUnsignedByte()
            result = result or ((current and 127) shl position)
            if ((current and 128) == 0) return result
            position += 7
            require(position < 35) { "VarInt نامعتبر است" }
        }
    }
}


private fun normalizeDigits(s: String): String = buildString {
    for (c in s) append(when (c) {
        in '۰'..'۹' -> '0' + (c - '۰')
        in '٠'..'٩' -> '0' + (c - '٠')
        '،' -> ','
        '−' -> '-'
        else -> c
    })
}

/** دستورهای فارسی/انگلیسی را مرحله‌به‌مرحله روی بات اجرا می‌کند. */
private suspend fun executeCommands(bot: McBotSession, raw: String): String {
    val text = normalizeDigits(raw.trim())
    val steps = text.split(Regex("\\s*(?:\\n|;|؛|سپس|بعد از آن|\\s+و\\s+(?=منتظر|صبر|بگو|برو|قطع))\\s*"))
        .filter { it.isNotBlank() }
    if (steps.isEmpty()) return "دستور خالی است."
    val report = StringBuilder()
    for (step in steps) {
        if (!bot.connected) { report.appendLine("اتصال قطع است."); break }
        val lower = step.lowercase()
        val nums = Regex("-?\\d+(?:\\.\\d+)?").findAll(step).mapNotNull { it.value.toDoubleOrNull() }.toList()
        when {
            lower.startsWith("/") -> { bot.sendChat(step); report.appendLine("✓ دستور سرور: $step") }
            lower.startsWith("بگو") || lower.startsWith("say") || lower.startsWith("chat") -> {
                val msg = step.substringAfter(' ', "").trim()
                if (msg.isEmpty()) report.appendLine("✗ متن پیام مشخص نیست.")
                else { bot.sendChat(msg); report.appendLine("✓ پیام: $msg") }
            }
            (lower.contains("برو") || lower.contains("goto") || lower.contains("مختصات")) && nums.size >= 3 -> {
                bot.walkTo(nums[0], nums[1], nums[2])
                report.appendLine("✓ حرکت: ${nums[0]}, ${nums[1]}, ${nums[2]} (الان %.1f, %.1f, %.1f)".format(bot.x, bot.y, bot.z))
            }
            lower.contains("منتظر") || lower.contains("صبر") || lower.contains("wait") -> {
                val sec = (nums.firstOrNull() ?: 5.0).coerceIn(0.0, 600.0)
                delay((sec * 1000).toLong())
                report.appendLine("✓ ${sec.toInt()} ثانیه صبر کردم.")
            }
            lower.contains("قطع") || lower.contains("disconnect") || lower.contains("خروج") -> {
                bot.stop(); report.appendLine("✓ قطع شد."); break
            }
            lower.contains("وضعیت") || lower.contains("کجا") || lower.contains("status") ->
                report.appendLine("موقعیت: %.1f, %.1f, %.1f".format(bot.x, bot.y, bot.z))
            else -> report.appendLine("✗ نفهمیدم: $step")
        }
    }
    return report.toString().trim()
}
