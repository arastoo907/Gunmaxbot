package com.gunmax.bot

import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.zip.Deflater
import java.util.zip.Inflater
import kotlin.math.min
import kotlin.math.sqrt

enum class AuthMode { NONE, LOGIN, REGISTER }

/** شناسه پکت‌ها برای هر نسخه. مقدار -1 یعنی «ناشناخته / استفاده نمی‌شود». */
data class McVersion(
    val label: String,
    val protocol: Int,
    val sKeepAlive: Int,
    val sDisconnect: Int,
    val sPosLook: Int,
    val sSystemChat: Int,
    val cTeleportConfirm: Int,
    val cChat: Int,
    val cChatCommand: Int,
    val cKeepAlive: Int,
    val cPosition: Int,
    val experimental: Boolean = false
) {
    val keepAliveIsVarInt get() = protocol < 340
    val hasConfigState get() = protocol >= 764
    val signedChatFormat get() = protocol >= 762
    val chatCommandUnsigned get() = protocol >= 766   // از 1.20.5 دستور بدون امضا پکت جدا دارد
    val posNewFormat get() = protocol >= 768          // 1.21.2+: teleportId اول، سرعت و flags از نوع Int
    val nbtText get() = protocol >= 765               // 1.20.3+: متن‌ها NBT هستند نه JSON
    val maxChat get() = if (protocol < 107) 100 else 256

    // شناسه‌ی پکت‌های مرحله‌ی Configuration (هر دو جهت عدد یکسان دارند)
    val cfgDisconnect get() = if (protocol >= 766) 0x02 else 0x01
    val cfgFinish get() = if (protocol >= 766) 0x03 else 0x02
    val cfgKeepAlive get() = if (protocol >= 766) 0x04 else 0x03
    val cfgPing get() = if (protocol >= 766) 0x05 else 0x04
    val cfgPluginMessageOut get() = if (protocol >= 766) 0x02 else 0x01

    companion object {
        val ALL = listOf(
            McVersion("1.8.9", 47, 0x00, 0x40, 0x08, 0x02, -1, 0x01, -1, 0x00, 0x04),
            McVersion("1.12.2", 340, 0x1F, 0x1A, 0x2F, 0x0F, 0x00, 0x02, -1, 0x0B, 0x0D),
            McVersion("1.16.5", 754, 0x1F, 0x19, 0x34, 0x0E, 0x00, 0x03, -1, 0x10, 0x12),
            McVersion("1.18.2", 758, 0x21, 0x1A, 0x38, 0x0F, 0x00, 0x03, -1, 0x0F, 0x11),
            McVersion("1.19.4", 762, 0x23, 0x17, 0x3C, 0x64, 0x00, 0x05, 0x04, 0x12, 0x14),
            McVersion("1.20.1", 763, 0x23, 0x17, 0x3C, 0x64, 0x00, 0x05, 0x04, 0x12, 0x14),
            McVersion("1.20.4 (آزمایشی)", 765, 0x24, 0x1B, 0x3E, 0x69, 0x00, 0x05, 0x04, 0x15, 0x17, true),
            // شناسه‌های 1.21.11 از روی تغییرات پروتکل محاسبه شده و روی سرور واقعی تست نشده؛
            // اگر درست کار نکرد از «ویرایش شناسه‌ها» در تنظیمات اصلاحشان کن.
            McVersion("1.21.11 (آزمایشی)", 774, 0x2B, 0x20, 0x46, 0x77, 0x00, 0x08, 0x06, 0x1B, 0x1D, true)
        )

        /** نسخه را با شناسه‌هایی که کاربر دستی تغییر داده ترکیب می‌کند. */
        fun resolve(label: String, store: AppStore?): McVersion {
            val base = ALL.firstOrNull { it.label == label } ?: ALL.first { it.protocol == 763 }
            val o = store?.idOverrides(base.label) ?: return base
            return base.copy(
                sKeepAlive = o["sKeepAlive"] ?: base.sKeepAlive,
                sDisconnect = o["sDisconnect"] ?: base.sDisconnect,
                sPosLook = o["sPosLook"] ?: base.sPosLook,
                sSystemChat = o["sSystemChat"] ?: base.sSystemChat,
                cChat = o["cChat"] ?: base.cChat,
                cChatCommand = o["cChatCommand"] ?: base.cChatCommand,
                cKeepAlive = o["cKeepAlive"] ?: base.cKeepAlive,
                cPosition = o["cPosition"] ?: base.cPosition
            )
        }
    }
}

private enum class State { LOGIN, CONFIG, PLAY }

/**
 * یک اتصال بات به سرور Minecraft Java در حالت آفلاین (crack).
 * فقط برای سرورهای خودت یا سرورهایی که صراحتاً اجازه‌ی بات می‌دهند.
 *
 * authMode: NONE = هیچ دستوری نمی‌زند، LOGIN = فقط /login، REGISTER = فقط /register.
 * brand: اسم کلاینت که به سرور اعلام می‌شود (vanilla / fabric / forge ...).
 */
class McBotSession(
    private val host: String,
    private val port: Int,
    private val version: McVersion,
    private val username: String,
    private val authPassword: String = "",
    private val authMode: AuthMode = AuthMode.NONE,
    private val loginTemplate: String = "/login {pass}",
    private val registerTemplate: String = "/register {pass} {pass}",
    private val brand: String = "vanilla",
    private val log: (String) -> Unit
) {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: DataOutputStream? = null
    private val writeLock = Any()

    @Volatile private var state = State.LOGIN
    @Volatile private var compression = -1
    @Volatile var connected = false
        private set
    @Volatile var spawned = false
        private set
    @Volatile var x = 0.0
        private set
    @Volatile var y = 0.0
        private set
    @Volatile var z = 0.0
        private set
    @Volatile private var rubberBands = 0
    @Volatile private var walking = false
    @Volatile private var keepAliveSeen = false
    @Volatile private var keepAliveHinted = false

    /** اتصال و ورود. روی thread پس‌زمینه صدا بزنید. */
    fun connect() {
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 8000)
        s.soTimeout = 60000
        socket = s
        input = s.getInputStream()
        output = DataOutputStream(s.getOutputStream())

        // Handshake
        sendRaw(0x00) {
            writeVarInt(it, version.protocol)
            writeString(it, host)
            it.writeShort(port)
            writeVarInt(it, 2)
        }
        // Login Start
        val uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$username".toByteArray(StandardCharsets.UTF_8))
        sendRaw(0x00) {
            writeString(it, username)
            if (version.protocol >= 764) {
                writeUuid(it, uuid)
            } else if (version.protocol >= 762) {
                it.writeBoolean(true)
                writeUuid(it, uuid)
            }
        }
        connected = true
        log("درخواست ورود با نام «$username» روی نسخه ${version.label} ارسال شد...")
        Thread({ readLoop() }, "mc-reader").apply { isDaemon = true }.start()
    }

    /** قطع‌کردنِ دستیِ کاربر؛ اتو ری‌کانکت بعد از این دوباره وصل نمی‌شود. */
    @Volatile var manualStop = false
        private set

    fun stop() {
        manualStop = true
        disconnect()
    }

    fun disconnect() {
        connected = false
        try { socket?.close() } catch (_: Exception) {}
    }

    fun sendChat(text: String) {
        if (!spawned) { log("هنوز وارد بازی نشده‌ام."); return }
        val msg = text.take(version.maxChat)
        if (msg.startsWith("/") && version.cChatCommand >= 0) {
            if (version.chatCommandUnsigned) {
                // 1.20.5+: دستور بدون آرگومان امضاشونده فقط خود رشته است
                sendRaw(version.cChatCommand) { writeString(it, msg.removePrefix("/")) }
            } else {
                sendRaw(version.cChatCommand) {
                    writeString(it, msg.removePrefix("/"))
                    it.writeLong(System.currentTimeMillis())
                    it.writeLong(0L)
                    writeVarInt(it, 0)       // argument signatures
                    writeVarInt(it, 0)       // message count
                    it.write(ByteArray(3))   // acknowledged bitset (20 bits)
                }
            }
        } else if (version.signedChatFormat) {
            sendRaw(version.cChat) {
                writeString(it, msg)
                it.writeLong(System.currentTimeMillis())
                it.writeLong(0L)
                it.writeBoolean(false)   // no signature
                writeVarInt(it, 0)
                it.write(ByteArray(3))
            }
        } else {
            sendRaw(version.cChat) { writeString(it, msg) }
        }
        val shown = if (authPassword.isNotEmpty()) msg.replace(authPassword, "••••") else msg
        log("پیام فرستاده شد: $shown")
    }

    /**
     * ثبت‌نام / ورود خودکار برای سرورهای کرک (AuthMe و مشابه).
     * LOGIN فقط /login می‌زند و REGISTER فقط /register؛ هیچ‌وقت هر دو با هم نیستند.
     */
    private fun autoAuth() {
        if (authMode == AuthMode.NONE) return
        try {
            Thread.sleep(2000)
            if (!connected) return
            when (authMode) {
                AuthMode.LOGIN -> {
                    val cmd = loginTemplate.replace("{pass}", authPassword)
                    log("🔐 ارسال دستور لاگین...")
                    sendChat(cmd)
                    Thread.sleep(6000)
                    if (!connected) return
                    sendChat(cmd) // یک بار تکرار؛ اگر قبلاً لاگین شده باشد سرور فقط می‌گوید «قبلاً وارد شده‌اید»
                }
                AuthMode.REGISTER -> {
                    val cmd = registerTemplate.replace("{pass}", authPassword)
                    log("📝 ارسال دستور ریجستر...")
                    sendChat(cmd)
                    // بعضی سرورها تکرار رمز نمی‌خواهند ( /register رمز ) → نسخه‌ی تک‌رمزی هم یک بار امتحان می‌شود
                    if (registerTemplate.contains("{pass} {pass}")) {
                        Thread.sleep(3000)
                        if (!connected) return
                        sendChat(registerTemplate.replace("{pass} {pass}", "{pass}").replace("{pass}", authPassword))
                    }
                }
                else -> {}
            }
        } catch (_: InterruptedException) {}
    }

    /** حرکت خط مستقیم با سرعت پیاده‌روی (بدون مسیریابی و بدون برخورد). */
    suspend fun walkTo(tx: Double, ty: Double, tz: Double) {
        if (!spawned) { log("هنوز وارد بازی نشده‌ام."); return }
        log("حرکت به سمت %.1f, %.1f, %.1f".format(tx, ty, tz))
        rubberBands = 0
        walking = true
        try {
            val deadline = System.currentTimeMillis() + 180_000
            while (connected && System.currentTimeMillis() < deadline) {
                val dx = tx - x
                val dy = ty - y
                val dz = tz - z
                val dist = sqrt(dx * dx + dy * dy + dz * dz)
                if (dist < 0.25) break
                if (rubberBands > 8) {
                    log("سرور مدام موقعیت را برگرداند (مانع یا محدودیت). حرکت متوقف شد.")
                    return
                }
                val step = min(0.2, dist)
                x += dx / dist * step
                y += dy / dist * step
                z += dz / dist * step
                sendPosition()
                delay(50)
            }
        } finally {
            walking = false
        }
        log("رسیدم: %.1f, %.1f, %.1f".format(x, y, z))
    }

    private fun sendPosition() {
        sendRaw(version.cPosition) {
            it.writeDouble(x)
            it.writeDouble(y)
            it.writeDouble(z)
            it.writeBoolean(true)
        }
    }

    /** مثل کلاینت واقعی هر ثانیه موقعیت می‌فرستد تا سرور بات را «بی‌حرکت/مرده» حساب نکند. */
    private fun heartbeat() {
        try {
            while (connected) {
                Thread.sleep(1000)
                if (spawned && !walking) sendPosition()
            }
        } catch (_: InterruptedException) {}
    }

    /** اعلام نام کلاینت (brand) به سرور؛ سرورهای Fabric/Forge و پلاگین‌های ضدچیت این را می‌خوانند. */
    private fun sendBrand() {
        if (!version.hasConfigState) return
        sendRaw(version.cfgPluginMessageOut) {
            writeString(it, "minecraft:brand")
            writeString(it, brand)
        }
        log("نام کلاینت اعلام شد: $brand")
    }

    // ---------------- خواندن ----------------

    private fun readLoop() {
        try {
            val din = DataInputStream(input)
            while (connected) {
                val length = readVarInt(din)
                if (length <= 0 || length > 4_000_000) throw IllegalStateException("طول پکت نامعتبر")
                val raw = ByteArray(length)
                din.readFully(raw)
                var body = raw
                if (compression >= 0) {
                    val bin = DataInputStream(ByteArrayInputStream(raw))
                    val dataLen = readVarInt(bin)
                    val rest = ByteArray(bin.available())
                    bin.readFully(rest)
                    body = if (dataLen == 0) rest else {
                        val inf = Inflater()
                        inf.setInput(rest)
                        val out = ByteArray(dataLen)
                        var off = 0
                        while (off < dataLen && !inf.finished()) {
                            val n = inf.inflate(out, off, dataLen - off)
                            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                            off += n
                        }
                        inf.end()
                        out
                    }
                }
                val p = DataInputStream(ByteArrayInputStream(body))
                val id = readVarInt(p)
                try {
                    handle(id, p, p.available())
                } catch (e: java.io.EOFException) {
                    // پکتی که فرمتش را نمی‌شناسیم؛ نادیده می‌گیریم تا اتصال نپرد
                }
            }
        } catch (e: Exception) {
            if (connected) log("اتصال قطع شد (${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"})")
        } finally {
            connected = false
            spawned = false
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    private fun handle(id: Int, p: DataInputStream, size: Int) {
        val v = version
        when (state) {
            State.LOGIN -> when (id) {
                0x00 -> { log("سرور رد کرد: ${chatText(readString(p))}"); disconnect() }
                0x01 -> {
                    log("این سرور آنلاین‌مود (اکانت اصلی) است. این نسخه فقط سرورهای آفلاین را پشتیبانی می‌کند.")
                    disconnect()
                }
                0x03 -> compression = readVarInt(p)
                0x04 -> {
                    // Login Plugin Request (مثلاً Fabric API): مثل کلاینت بدون مود جواب «نمی‌شناسم» می‌دهیم
                    val mid = readVarInt(p)
                    val channel = try { readString(p) } catch (_: Exception) { "?" }
                    sendRaw(0x02) { writeVarInt(it, mid); it.writeBoolean(false) }
                    log("پرس‌وجوی لاگینِ سرور ($channel) بدون پشتیبانی پاسخ داده شد.")
                }
                0x05 -> if (v.protocol >= 766) {
                    val ck = readString(p)
                    sendRaw(0x04) { writeString(it, ck); it.writeBoolean(false) }
                }
                0x02 -> {
                    if (v.hasConfigState) {
                        sendRaw(0x03) { }
                        state = State.CONFIG
                        sendBrand()
                    } else {
                        state = State.PLAY
                    }
                    log("ورود موفق ✓")
                }
            }
            State.CONFIG -> when {
                id == v.cfgDisconnect -> {
                    val reason = try { readComponent(p) } catch (_: Exception) { "" }
                    log("سرور در مرحله پیکربندی قطع کرد. ${if (reason.isNotBlank()) "دلیل: $reason" else ""}")
                    disconnect()
                }
                id == v.cfgFinish -> { sendRaw(v.cfgFinish) { }; state = State.PLAY }
                id == v.cfgKeepAlive -> { val k = p.readLong(); sendRaw(v.cfgKeepAlive) { it.writeLong(k) } }
                id == v.cfgPing -> { val k = p.readInt(); sendRaw(v.cfgPing) { it.writeInt(k) } }
                v.protocol >= 766 && id == 0x00 -> {
                    val ck = readString(p)
                    sendRaw(0x01) { writeString(it, ck); it.writeBoolean(false) }
                }
                v.protocol >= 766 && id == 0x0E -> {
                    // Select Known Packs: به سرور می‌گوییم هیچ پکی نداریم تا رجیستری کامل را بفرستد
                    sendRaw(0x07) { writeVarInt(it, 0) }
                }
                v.protocol >= 766 && id == 0x09 -> {
                    // Resource Pack Push: پاسخ «قبول، دانلود، بارگذاری شد»
                    val hi = p.readLong(); val lo = p.readLong()
                    for (r in intArrayOf(3, 4, 0)) {
                        sendRaw(0x06) { it.writeLong(hi); it.writeLong(lo); writeVarInt(it, r) }
                    }
                    log("درخواست ریسورس‌پک سرور پذیرفته شد.")
                }
                v.protocol >= 773 && id == 0x13 -> {
                    sendRaw(0x09) { } // Accept Code of Conduct
                    log("قوانین سرور (Code of Conduct) پذیرفته شد.")
                }
            }
            State.PLAY -> when {
                id == v.sKeepAlive -> {
                    keepAliveSeen = true
                    if (v.keepAliveIsVarInt) {
                        val k = readVarInt(p)
                        sendRaw(v.cKeepAlive) { writeVarInt(it, k) }
                    } else {
                        val k = p.readLong()
                        sendRaw(v.cKeepAlive) { it.writeLong(k) }
                    }
                }
                id == v.sDisconnect -> {
                    val reason = try { readComponent(p) } catch (_: Exception) { "" }
                    log("از سرور بیرون انداخته شدم. دلیل: ${if (reason.isNotBlank()) reason else "(سرور دلیلی ارسال نکرد)"}")
                    disconnect()
                }
                id == v.sPosLook -> onPosLook(p)
                v.sSystemChat >= 0 && id == v.sSystemChat -> onChat(p)
                else -> {
                    if (!keepAliveSeen && !keepAliveHinted && size == 8 && v.protocol >= 764) {
                        keepAliveHinted = true
                        log("ℹ️ پکتی ۸ بایتی با شناسه 0x%02X دیدم (Keep-Alive تنظیم‌شده: 0x%02X). اگر بات بعد از ~۲۰ ثانیه Timed out شد، این عدد را در «ویرایش شناسه‌ها» بگذار.".format(id, v.sKeepAlive))
                    }
                }
            }
        }
    }

    private fun onPosLook(p: DataInputStream) {
        val v = version
        if (v.posNewFormat) {
            val tid = readVarInt(p)
            val nx = p.readDouble(); val ny = p.readDouble(); val nz = p.readDouble()
            p.readDouble(); p.readDouble(); p.readDouble()   // delta movement
            p.readFloat(); p.readFloat()
            val flags = p.readInt()
            x = if (flags and 1 != 0) x + nx else nx
            y = if (flags and 2 != 0) y + ny else ny
            z = if (flags and 4 != 0) z + nz else nz
            sendRaw(v.cTeleportConfirm) { writeVarInt(it, tid) }
        } else {
            val nx = p.readDouble(); val ny = p.readDouble(); val nz = p.readDouble()
            p.readFloat(); p.readFloat()
            val flags = p.readUnsignedByte()
            x = if (flags and 1 != 0) x + nx else nx
            y = if (flags and 2 != 0) y + ny else ny
            z = if (flags and 4 != 0) z + nz else nz
            if (v.cTeleportConfirm >= 0) {
                val tid = readVarInt(p)
                sendRaw(v.cTeleportConfirm) { writeVarInt(it, tid) }
            }
        }
        sendPosition()
        if (!spawned) {
            spawned = true
            log("وارد دنیا شدم. موقعیت: %.1f, %.1f, %.1f".format(x, y, z))
            Thread({ heartbeat() }, "mc-beat").apply { isDaemon = true }.start()
            if (authMode != AuthMode.NONE) {
                Thread({ autoAuth() }, "mc-auth").apply { isDaemon = true }.start()
            }
        } else {
            rubberBands++
        }
    }

    /** پیام‌های سرور (مثل جواب AuthMe) را در کنسول نشان می‌دهد تا بدانی چرا لاگین نشده. */
    private fun onChat(p: DataInputStream) {
        val v = version
        val text: String
        if (v.protocol >= 762) {
            text = readComponent(p)
            val overlay = try { p.readBoolean() } catch (_: Exception) { false }
            if (overlay) return
        } else {
            text = chatText(readString(p))
            val pos = try { p.readByte().toInt() } catch (_: Exception) { 0 }
            if (pos == 2) return
        }
        if (text.isNotBlank()) log("💬 سرور: $text")
    }

    // ---------------- نوشتن ----------------

    private fun sendRaw(id: Int, build: (DataOutputStream) -> Unit) {
        val buf = ByteArrayOutputStream()
        val d = DataOutputStream(buf)
        writeVarInt(d, id)
        build(d)
        val payload = buf.toByteArray()
        synchronized(writeLock) {
            val out = output ?: return
            try {
                val frame = ByteArrayOutputStream()
                val f = DataOutputStream(frame)
                if (compression < 0) {
                    writeVarInt(f, payload.size)
                    f.write(payload)
                } else if (payload.size < compression) {
                    writeVarInt(f, payload.size + 1)
                    writeVarInt(f, 0)
                    f.write(payload)
                } else {
                    val def = Deflater()
                    def.setInput(payload)
                    def.finish()
                    val tmp = ByteArray(payload.size + 64)
                    val n = def.deflate(tmp)
                    def.end()
                    val lenBuf = ByteArrayOutputStream()
                    writeVarInt(DataOutputStream(lenBuf), payload.size)
                    writeVarInt(f, lenBuf.size() + n)
                    f.write(lenBuf.toByteArray())
                    f.write(tmp, 0, n)
                }
                out.write(frame.toByteArray())
                out.flush()
            } catch (e: Exception) {
                if (connected) { connected = false; log("ارسال ناموفق: ${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"}") }
            }
        }
    }

    // ---------------- متن (JSON / NBT) ----------------

    /** متن چت: از 1.20.3 به بعد NBT است، قبل از آن JSON. */
    private fun readComponent(p: DataInputStream): String =
        if (version.nbtText) cleanText(flattenAny(readNbtPayload(p, p.readUnsignedByte())))
        else chatText(readString(p))

    private fun chatText(json: String): String = try {
        val t = json.trim()
        val any: Any = when {
            t.startsWith("{") -> JSONObject(t)
            t.startsWith("[") -> org.json.JSONArray(t)
            else -> t
        }
        cleanText(flattenAny(jsonToAny(any)))
    } catch (_: Exception) { json }

    private fun jsonToAny(a: Any?): Any? = when (a) {
        is JSONObject -> a.keys().asSequence().associateWith { jsonToAny(a.opt(it)) }
        is org.json.JSONArray -> (0 until a.length()).map { jsonToAny(a.opt(it)) }
        else -> a
    }

    /** یک کامپوننت متنی (String / Map / List) را به متن ساده تبدیل می‌کند. */
    private fun flattenAny(a: Any?): String = when (a) {
        null -> ""
        is String -> a
        is List<*> -> a.joinToString("") { flattenAny(it) }
        is Map<*, *> -> {
            @Suppress("UNCHECKED_CAST")
            val m = a as Map<String, Any?>
            val sb = StringBuilder()
            val text = m["text"]
            val tr = m["translate"]
            if (text is String) sb.append(text) else if (text == null && tr is String) sb.append(tr)
            sb.append(flattenAny(m["extra"]))
            sb.toString()
        }
        else -> a.toString()
    }

    private fun cleanText(s: String) = s.replace(Regex("§."), "").trim()

    /** خواندن NBT شبکه‌ای (بدون نام ریشه) و تبدیل به Map/List/String. */
    private fun readNbtPayload(d: DataInputStream, type: Int, depth: Int = 0): Any? {
        if (depth > 32) throw IllegalStateException("NBT خیلی عمیق")
        return when (type) {
            0 -> null
            1 -> d.readByte()
            2 -> d.readShort()
            3 -> d.readInt()
            4 -> d.readLong()
            5 -> d.readFloat()
            6 -> d.readDouble()
            7 -> { val n = d.readInt(); d.skipBytes(n); null }
            8 -> d.readUTF()
            9 -> {
                val t = d.readUnsignedByte()
                val n = d.readInt()
                val list = ArrayList<Any?>()
                for (i in 0 until n) list.add(readNbtPayload(d, t, depth + 1))
                list
            }
            10 -> {
                val map = LinkedHashMap<String, Any?>()
                while (true) {
                    val t = d.readUnsignedByte()
                    if (t == 0) break
                    val name = d.readUTF()
                    map[name] = readNbtPayload(d, t, depth + 1)
                }
                map
            }
            11 -> { val n = d.readInt(); d.skipBytes(n * 4); null }
            12 -> { val n = d.readInt(); d.skipBytes(n * 8); null }
            else -> throw IllegalStateException("نوع NBT نامعتبر $type")
        }
    }

    // ---------------- ابزار باینری ----------------

    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while ((v and -128) != 0) {
            out.writeByte((v and 127) or 128)
            v = v ushr 7
        }
        out.writeByte(v)
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0
        var pos = 0
        while (true) {
            val cur = input.readUnsignedByte()
            result = result or ((cur and 127) shl pos)
            if ((cur and 128) == 0) return result
            pos += 7
            if (pos >= 35) throw IllegalStateException("VarInt نامعتبر")
        }
    }

    private fun writeString(out: DataOutputStream, s: String) {
        val b = s.toByteArray(StandardCharsets.UTF_8)
        writeVarInt(out, b.size)
        out.write(b)
    }

    private fun readString(input: DataInputStream): String {
        val len = readVarInt(input)
        if (len < 0 || len > 262144) throw IllegalStateException("رشته نامعتبر")
        val b = ByteArray(len)
        input.readFully(b)
        return String(b, StandardCharsets.UTF_8)
    }

    private fun writeUuid(out: DataOutputStream, u: UUID) {
        out.writeLong(u.mostSignificantBits)
        out.writeLong(u.leastSignificantBits)
    }
}
