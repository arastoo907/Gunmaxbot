package com.gunmax.bot

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt

private val GPanel = Color(0xFF101D19)
private val GPanel2 = Color(0xFF172923)
private val GMint = Color(0xFF39D6A0)
private val GMuted = Color(0xFF9AB0A8)
private val GWhite = Color(0xFFEAF5F0)

/**
 * تب «بازی»: نمایش زنده‌ی بات از بالا (شمال بالا)، جوی‌استیک حرکت و نوار ارسال چت/دستور.
 * نمایش کاملاً محلی و با ۳۰ فریم در ثانیه رسم می‌شود، پس به شبکه وابسته نیست و لگ ندارد.
 */
@Composable
fun GameTab(
    session: McBotSession?,
    botName: String,
    state: Int,                         // 0 آفلاین، 1 در حال ورود، 2 داخل بازی
    logs: List<String>,
    onJoyActive: (Boolean) -> Unit,
    onSend: (String) -> Unit
) {
    val inGame = session != null && state == 2

    // ۳۰ فریم بر ثانیه فقط برای رسم؛ و یک تیک کندتر برای متن مختصات
    var tick by remember { mutableStateOf(0) }
    var slowTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { tick++ } } }   // هم‌گام با نرخ تازه‌سازی صفحه (۶۰ فریم یا بیشتر)
    LaunchedEffect(Unit) { while (true) { delay(250); slowTick++ } }

    // تا وقتی تب بازی بازه صفحه خاموش نشود (برای دیدن طولانی‌مدت بات)
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // موقعیت نمایشی نرم‌شده (سرور ۲۰ بار در ثانیه حرکت می‌دهد، نمایش ۶۰ بار)
    val disp = remember { DoubleArray(3) }   // x, z, مقدار اولیه‌شده

    // با خروج از تب یا عوض‌شدن بات، حرکت متوقف شود
    DisposableEffect(session) {
        onDispose {
            session?.moveX = 0.0
            session?.moveZ = 0.0
            onJoyActive(false)
        }
    }

    val slow = slowTick
    val coords = if (inGame && session != null && slow >= 0)
        "X %.1f   Y %.1f   Z %.1f".format(session.x, session.y, session.z) else "—"
    val statusText = when {
        session == null || state == 0 -> "آفلاین — اول بات را در تب «بات‌ها» وصل کن"
        state == 1 -> "در حال ورود به سرور..."
        else -> "داخل بازی — $botName"
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(statusText, color = if (inGame) GMint else GMuted, fontSize = 13.sp)

        // ---------- نمایش زنده ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF0B1A16))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val t = tick   // خواندن این مقدار باعث می‌شود هر فریم دوباره رسم شود
                val w = size.width
                val h = size.height
                val cx = w / 2f
                val cy = h / 2f
                val s = session
                if (s == null || !inGame || t < 0) return@Canvas

                val ppb = w / 24f              // ۲۴ بلاک عرض نمایش داده می‌شود
                if (disp[2] == 0.0 || hypot(s.x - disp[0], s.z - disp[1]) > 8.0) {
                    disp[0] = s.x; disp[1] = s.z; disp[2] = 1.0   // اولین فریم یا تلپورت
                } else {
                    disp[0] += (s.x - disp[0]) * 0.3
                    disp[1] += (s.z - disp[1]) * 0.3
                }
                val bx = disp[0]
                val bz = disp[1]

                // شبکه‌ی بلاک‌ها؛ مرز چانک (هر ۱۶ بلاک) پررنگ‌تر
                val gx0 = floor(bx - 13).toInt()
                val gx1 = ceil(bx + 13).toInt()
                for (gx in gx0..gx1) {
                    val px = cx + ((gx - bx) * ppb).toFloat()
                    val chunk = Math.floorMod(gx, 16) == 0
                    drawLine(
                        if (chunk) Color(0x5539D6A0) else Color(0x1AFFFFFF),
                        Offset(px, 0f), Offset(px, h), strokeWidth = if (chunk) 2f else 1f
                    )
                }
                val gz0 = floor(bz - 13).toInt()
                val gz1 = ceil(bz + 13).toInt()
                for (gz in gz0..gz1) {
                    val py = cy + ((gz - bz) * ppb).toFloat()
                    val chunk = Math.floorMod(gz, 16) == 0
                    drawLine(
                        if (chunk) Color(0x5539D6A0) else Color(0x1AFFFFFF),
                        Offset(0f, py), Offset(w, py), strokeWidth = if (chunk) 2f else 1f
                    )
                }

                // ردّ مسیر
                val trail = s.trailSnapshot()
                if (trail.size > 1) {
                    val path = Path()
                    trail.forEachIndexed { i, p ->
                        val px = cx + ((p[0] - bx) * ppb).toFloat()
                        val py = cy + ((p[1] - bz) * ppb).toFloat()
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    drawPath(path, Color(0x8839D6A0), style = Stroke(width = 3f))
                }

                // خود بات + فلش جهت حرکت
                val mx = s.moveX.toFloat()
                val mz = s.moveZ.toFloat()
                val len = hypot(mx, mz)
                if (len > 0.08f) {
                    val k = (if (len > 1f) 1f / len else 1f) * ppb * 1.6f
                    drawLine(Color.White, Offset(cx, cy), Offset(cx + mx * k, cy + mz * k), strokeWidth = 4f)
                }
                drawCircle(Color(0xFF39D6A0), radius = ppb * 0.45f, center = Offset(cx, cy))
                drawCircle(Color.White, radius = ppb * 0.45f, center = Offset(cx, cy), style = Stroke(width = 2f))
            }

            // جهت‌ها
            Text("N", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp))
            Text("S", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
            Text("W", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp))
            Text("E", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp))

            // مختصات
            Surface(
                color = Color(0x99000000), shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            ) {
                Text(coords, color = GWhite, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }

            // آخرین پیام‌های سرور
            val chat = logs.filter { it.contains("💬 سرور:") }.take(3).reversed()
            if (chat.isNotEmpty()) {
                Surface(
                    color = Color(0x99000000), shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).fillMaxWidth(0.8f)
                ) {
                    Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        chat.forEach {
                            Text(
                                it.substringAfter("💬 سرور:").trim(), color = GWhite, fontSize = 11.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // ---------- جوی‌استیک ----------
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Joystick(
                enabled = inGame,
                onMove = { vx, vz ->
                    session?.moveX = vx.toDouble()
                    session?.moveZ = vz.toDouble()
                },
                onActive = onJoyActive
            )
        }

        // ---------- ارسال چت / دستور ----------
        var text by remember { mutableStateOf("") }
        val send = {
            val m = text.trim()
            if (m.isNotEmpty() && inGame) {
                onSend(m)
                text = ""
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("چت یا /دستور", color = GMuted) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            FilledIconButton(
                onClick = { send() },
                enabled = inGame,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = GMint, contentColor = Color(0xFF07110F))
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "ارسال")
            }
        }
    }
}

@Composable
private fun Joystick(enabled: Boolean, onMove: (Float, Float) -> Unit, onActive: (Boolean) -> Unit) {
    val size = 170.dp
    val radius = with(LocalDensity.current) { (size / 2).toPx() }
    var raw by remember { mutableStateOf(Offset.Zero) }
    var knob by remember { mutableStateOf(Offset.Zero) }

    fun release() {
        knob = Offset.Zero
        onMove(0f, 0f)
        onActive(false)
    }

    Box(
        modifier = Modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(CircleShape)
            .background(GPanel2)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { o ->
                        raw = o - Offset(radius, radius)
                        onActive(true)
                    },
                    onDragEnd = { release() },
                    onDragCancel = { release() },
                    onDrag = { change, delta ->
                        change.consume()
                        raw += delta
                        val len = hypot(raw.x, raw.y)
                        val v = if (len > radius) raw * (radius / len) else raw
                        knob = v
                        onMove(v.x / radius, v.y / radius)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(size * 0.9f)
                .clip(CircleShape)
                .background(GPanel)
        )
        Box(
            Modifier
                .offset { IntOffset(knob.x.roundToInt(), knob.y.roundToInt()) }
                .size(64.dp)
                .clip(CircleShape)
                .background(GMint)
        )
    }
}
