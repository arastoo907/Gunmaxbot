package com.gunmax.bot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

/** مودی که کاربر بارگذاری کرده و به یک نسخه + لودر وصل است. */
data class ModEntry(
    val file: String,     // اسم فایل کپی‌شده داخل حافظه‌ی برنامه
    val id: String,
    val name: String,
    val version: String,
    val loader: String,   // fabric / quilt / neoforge / forge
    val mc: String        // برچسب نسخه‌ی ماینکرفتی که این مود با آن استفاده می‌شود
)

/** تنظیمات ماندگار برنامه (آدرس، نام، رمز، نسخه، حالت لاگین، مودها، شناسه‌های دستی). */
class AppStore(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("gunmax", Context.MODE_PRIVATE)

    fun str(key: String, def: String): String = sp.getString(key, def) ?: def
    fun put(key: String, value: String) { sp.edit().putString(key, value).apply() }

    fun modsDir(): File = File(ctx.filesDir, "mods").also { it.mkdirs() }

    // ---------- مودها ----------
    fun mods(): List<ModEntry> = try {
        val arr = JSONArray(str("mods", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ModEntry(o.getString("file"), o.getString("id"), o.getString("name"),
                o.getString("version"), o.getString("loader"), o.getString("mc"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveMods(list: List<ModEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("file", it.file).put("id", it.id).put("name", it.name)
                .put("version", it.version).put("loader", it.loader).put("mc", it.mc))
        }
        put("mods", arr.toString())
    }

    // ---------- شناسه‌های دستی پکت ----------
    fun idOverrides(label: String): Map<String, Int> = try {
        val o = JSONObject(str("ids_$label", "{}"))
        o.keys().asSequence().associateWith { o.getInt(it) }
    } catch (_: Exception) { emptyMap() }

    fun saveIdOverrides(label: String, map: Map<String, Int>) {
        if (map.isEmpty()) { sp.edit().remove("ids_$label").apply(); return }
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        put("ids_$label", o.toString())
    }
}

object ModTools {
    val LOADERS = listOf("vanilla", "fabric", "quilt", "neoforge", "forge")

    fun loaderTitle(l: String) = when (l) {
        "fabric" -> "Fabric"
        "quilt" -> "Quilt"
        "neoforge" -> "NeoForge"
        "forge" -> "Forge"
        else -> "بدون لودر (Vanilla)"
    }

    /** نام کلاینتی که به سرور اعلام می‌شود. */
    fun brandFor(loader: String) = if (loader in LOADERS && loader != "vanilla") loader else "vanilla"

    /** فایل jar را باز می‌کند و شناسه، نسخه و لودر مود را از متادیتای داخلش می‌خواند. null = مود معتبر نیست. */
    fun inspect(file: File, mcLabel: String): ModEntry? {
        ZipFile(file).use { zip ->
            fun read(name: String): String? =
                zip.getEntry(name)?.let { e -> zip.getInputStream(e).bufferedReader(Charsets.UTF_8).readText() }

            read("fabric.mod.json")?.let { txt ->
                val o = JSONObject(txt)
                val id = o.optString("id", file.nameWithoutExtension)
                return ModEntry(file.name, id, o.optString("name", id), o.optString("version", "?"), "fabric", mcLabel)
            }
            read("quilt.mod.json")?.let { txt ->
                val q = JSONObject(txt).optJSONObject("quilt_loader")
                val id = q?.optString("id", file.nameWithoutExtension) ?: file.nameWithoutExtension
                val name = q?.optJSONObject("metadata")?.optString("name", id) ?: id
                return ModEntry(file.name, id, name, q?.optString("version", "?") ?: "?", "quilt", mcLabel)
            }
            for ((path, loader) in listOf("META-INF/neoforge.mods.toml" to "neoforge", "META-INF/mods.toml" to "forge")) {
                read(path)?.let { toml ->
                    fun field(k: String) = Regex("""(?m)^\s*$k\s*=\s*["']([^"']+)["']""").find(toml)?.groupValues?.get(1)
                    val id = field("modId") ?: file.nameWithoutExtension
                    return ModEntry(file.name, id, field("displayName") ?: id, field("version") ?: "?", loader, mcLabel)
                }
            }
        }
        return null
    }
}
