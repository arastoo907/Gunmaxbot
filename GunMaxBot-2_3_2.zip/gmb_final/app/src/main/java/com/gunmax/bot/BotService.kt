package com.gunmax.bot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.util.concurrent.CopyOnWriteArrayList

/** فهرست نشست‌های بات؛ برای قطع‌کردن همه وقتی کاربر برنامه را از لیست برنامه‌ها پاک می‌کند. */
object SessionRegistry {
    val list = CopyOnWriteArrayList<McBotSession>()
}

/**
 * سرویس پیش‌زمینه: تا وقتی بات‌ها وصل‌اند، اندروید برنامه، شبکه و CPU را در پس‌زمینه نمی‌کشد.
 * (یک نوتیفیکیشن دائمی نشان می‌دهد؛ این لازمه‌ی کار اندروید است.)
 */
class BotService : Service() {
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    companion object {
        private const val CH = "gmb_keepalive"
        private const val NOTIF_ID = 1

        fun update(ctx: Context, online: Int) {
            runCatching {
                val i = Intent(ctx, BotService::class.java).putExtra("online", online)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            }
        }

        fun stop(ctx: Context) {
            runCatching { ctx.stopService(Intent(ctx, BotService::class.java)) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "اتصال بات‌ها", NotificationManager.IMPORTANCE_LOW))
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gunmax:bots").apply {
            setReferenceCounted(false); acquire()
        }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "gunmax:wifi").apply {
            setReferenceCounted(false); acquire()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val online = intent?.getIntExtra("online", 0) ?: 0
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        val n = b.setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("GunMax Bot")
            .setContentText(if (online > 0) "$online بات داخل بازی است" else "در حال اتصال / نگه‌داشتن اتصال...")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        return START_NOT_STICKY
    }

    // کاربر برنامه را از لیست اخیر پاک کرد: همه‌ی بات‌ها را قطع کن تا بات «روح» نماند
    override fun onTaskRemoved(rootIntent: Intent?) {
        SessionRegistry.list.forEach { runCatching { it.stop() } }
        SessionRegistry.list.clear()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        runCatching { wake?.takeIf { it.isHeld }?.release() }
        runCatching { wifi?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }
}
