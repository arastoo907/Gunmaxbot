package com.gunmax.bot

import java.io.DataInputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * جدول رنگ/نوع بلاک هر نسخه (فایل assets/blocks_<نسخه>.bin).
 * برای هر شناسه‌ی state چهار بایت: R, G, B, flags
 * flags: bit0 = روی نقشه کشیده می‌شود، bit1 = برخورد دارد (جامد)، bit2 = مایع
 */
class BlockTable(private val data: ByteArray) {
    val size get() = data.size / 4
    fun flags(id: Int): Int = if (id < 0 || id * 4 + 3 >= data.size) 0 else data[id * 4 + 3].toInt() and 0xFF
    fun rgb(id: Int): Int {
        if (id < 0 || id * 4 + 3 >= data.size) return 0
        val i = id * 4
        return ((data[i].toInt() and 0xFF) shl 16) or ((data[i + 1].toInt() and 0xFF) shl 8) or (data[i + 2].toInt() and 0xFF)
    }
    fun solid(id: Int) = flags(id) and 2 != 0
}

/** بارگذاری جدول‌ها؛ در MainActivity با `BlockTables.loader = { assets.open(it).readBytes() }` تنظیم می‌شود. */
object BlockTables {
    @Volatile var loader: ((String) -> ByteArray)? = null
    private val cache = HashMap<String, BlockTable?>()
    @Synchronized fun forVersion(label: String): BlockTable? {
        if (cache.containsKey(label)) return cache[label]
        val t = try { loader?.invoke("blocks_$label.bin")?.let { BlockTable(it) } } catch (_: Exception) { null }
        cache[label] = t
        return t
    }
}

/** شناسه‌ی پکت‌های مربوط به دنیا برای هر نسخه (با داده‌ی مرجع PrismarineJS/minecraft-data تطبیق داده شده). */
private data class WorldIds(
    val chunk: Int, val bulk: Int, val unload: Int, val block: Int, val multi: Int,
    val login: Int, val respawn: Int, val batchFinished: Int, val batchAckOut: Int
)

private fun worldIdsFor(protocol: Int): WorldIds? = when (protocol) {
    47 -> WorldIds(0x21, 0x26, -1, 0x23, 0x22, 0x01, 0x07, -1, -1)
    340 -> WorldIds(0x20, -1, 0x1D, 0x0B, 0x10, 0x23, 0x34, -1, -1)
    754 -> WorldIds(0x20, -1, 0x1C, 0x0B, 0x3B, 0x24, 0x39, -1, -1)
    758 -> WorldIds(0x22, -1, 0x1D, 0x0C, 0x3F, 0x26, 0x3D, -1, -1)
    762 -> WorldIds(0x24, -1, 0x1E, 0x0A, 0x43, 0x28, 0x41, -1, -1)
    763 -> WorldIds(0x24, -1, 0x1E, 0x0A, 0x43, 0x28, 0x41, -1, -1)
    765 -> WorldIds(0x25, -1, 0x1F, 0x09, 0x47, 0x29, 0x45, 0x0C, 0x07)
    774 -> WorldIds(0x2C, -1, 0x25, 0x08, 0x52, 0x30, 0x50, 0x0B, 0x0A)
    else -> null
}

/** خواننده‌ی سریع روی آرایه‌ی بایت (برای داده‌ی چانک). */
private class Buf(val b: ByteArray, var pos: Int = 0, val end: Int = b.size) {
    fun u8(): Int { if (pos >= end) throw java.io.EOFException(); return b[pos++].toInt() and 0xFF }
    fun i16(): Int = (u8() shl 8) or u8()
    fun i32(): Int = (u8() shl 24) or (u8() shl 16) or (u8() shl 8) or u8()
    fun i64(): Long = (i32().toLong() shl 32) or (i32().toLong() and 0xFFFFFFFFL)
    fun varInt(): Int {
        var r = 0; var s = 0
        while (true) {
            val c = u8()
            r = r or ((c and 127) shl s)
            if (c and 128 == 0) return r
            s += 7
            if (s >= 35) throw IllegalStateException("VarInt")
        }
    }
    fun varLong(): Long {
        var r = 0L; var s = 0
        while (true) {
            val c = u8()
            r = r or ((c and 127).toLong() shl s)
            if (c and 128 == 0) return r
            s += 7
            if (s >= 70) throw IllegalStateException("VarLong")
        }
    }
    fun skip(n: Int) { if (n < 0 || pos + n > end) throw java.io.EOFException(); pos += n }
    fun left() = end - pos
}

/** یک چانک: بخش‌های 16×16×16 با شناسه‌ی state (Short بدون علامت)، به‌علاوه‌ی تصویر نمای بالا. */
class WorldChunk(val cx: Int, val cz: Int, var minSec: Int, var sections: Array<ShortArray?>) {
    @Volatile var version = 0                    // با هر تغییر زیاد می‌شود تا UI تصویر را تازه کند
    private var pix: IntArray? = null
    private var pixVersion = -1

    fun state(lx: Int, y: Int, lz: Int): Int {
        val si = Math.floorDiv(y, 16) - minSec
        if (si < 0 || si >= sections.size) return 0
        val s = sections[si] ?: return 0
        return s[((y and 15) shl 8) or (lz shl 4) or lx].toInt() and 0xFFFF
    }

    fun setState(lx: Int, y: Int, lz: Int, id: Int) {
        val si = Math.floorDiv(y, 16) - minSec
        if (si < 0) return
        if (si >= sections.size) {
            if (id == 0) return
            sections = sections.copyOf(si + 1)
        }
        var s = sections[si]
        if (s == null) { if (id == 0) return; s = ShortArray(4096); sections[si] = s }
        s[((y and 15) shl 8) or (lz shl 4) or lx] = id.toShort()
        version++
    }

    /** تصویر ۱۶×۱۶ از بالا (ARGB). مقدار 0 = ستونِ خالی. */
    @Synchronized fun pixels(table: BlockTable): IntArray {
        val cur = pix
        if (cur != null && pixVersion == version) return cur
        val v = version
        val col = IntArray(256)
        val hs = IntArray(256)
        val top = (sections.size + minSec) * 16 - 1
        val bottom = minSec * 16
        for (lz in 0 until 16) for (lx in 0 until 16) {
            var y = top
            var h = bottom
            var color = 0
            while (y >= bottom) {
                val si = (y shr 4) - minSec
                val s = if (si in sections.indices) sections[si] else null
                if (s == null) { y = ((y shr 4) shl 4) - 1; continue }   // کل بخش خالی
                val id = s[((y and 15) shl 8) or (lz shl 4) or lx].toInt() and 0xFFFF
                val f = table.flags(id)
                if (f and 1 != 0) {
                    h = y
                    if (f and 4 != 0) {
                        // مایع: هرچه عمیق‌تر، تیره‌تر
                        var depth = 1
                        var yy = y - 1
                        while (yy >= bottom && depth < 12) {
                            val s2 = sections.getOrNull((yy shr 4) - minSec)
                            val id2 = if (s2 == null) 0 else s2[((yy and 15) shl 8) or (lz shl 4) or lx].toInt() and 0xFFFF
                            if (table.flags(id2) and 4 == 0) break
                            depth++; yy--
                        }
                        val k = 1.0 - depth * 0.045
                        val rgb = table.rgb(id)
                        val r = (((rgb shr 16) and 255) * k).toInt()
                        val g = (((rgb shr 8) and 255) * k).toInt()
                        val b = ((rgb and 255) * k).toInt()
                        color = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    } else {
                        color = (0xFF shl 24) or table.rgb(id)
                    }
                    break
                }
                y--
            }
            val i = (lz shl 4) or lx
            col[i] = color
            hs[i] = h
        }
        // سایه‌ی ارتفاع (مثل نقشه‌ی خود ماینکرفت): بلندتر از ستون شمالی = روشن‌تر
        for (lz in 0 until 16) for (lx in 0 until 16) {
            val i = (lz shl 4) or lx
            val c = col[i]
            if (c == 0) continue
            val hn = if (lz > 0) hs[i - 16] else hs[i]
            val d = (hs[i] - hn).coerceIn(-3, 3)
            val k = 1.0 + d * 0.08
            val r = (((c shr 16) and 255) * k).toInt().coerceIn(0, 255)
            val g = (((c shr 8) and 255) * k).toInt().coerceIn(0, 255)
            val b = ((c and 255) * k).toInt().coerceIn(0, 255)
            col[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        pix = col
        pixVersion = v
        return col
    }
}

/**
 * دنیای بات: چانک‌هایی که سرور می‌فرستد را می‌خواند و نگه می‌دارد.
 * برای نسخه‌های 1.8.9، 1.12.2، 1.16.5، 1.18.2، 1.19.4، 1.20.1، 1.20.4 و 1.21.11.
 */
class WorldMap(private val protocol: Int, val table: BlockTable) {
    private val ids = worldIdsFor(protocol)
    val chunks = ConcurrentHashMap<Long, WorldChunk>()
    @Volatile var errorCount = 0
        private set
    @Volatile var lastError: String? = null
        private set
    @Volatile var loadedTotal = 0
        private set

    val supported get() = ids != null
    /** شناسه‌ی پکت «Chunk Batch Received» (1.20.2+)؛ -1 یعنی لازم نیست. */
    val batchAckId get() = ids?.batchAckOut ?: -1

    private fun key(cx: Int, cz: Int) = (cx.toLong() shl 32) or (cz.toLong() and 0xFFFFFFFFL)
    fun chunkAt(cx: Int, cz: Int): WorldChunk? = chunks[key(cx, cz)]
    fun clear() { chunks.clear() }

    /** شناسه‌ی state بلاک؛ -1 یعنی چانک لود نیست. */
    fun stateAt(x: Int, y: Int, z: Int): Int {
        val c = chunks[key(Math.floorDiv(x, 16), Math.floorDiv(z, 16))] ?: return -1
        return c.state(Math.floorMod(x, 16), y, Math.floorMod(z, 16))
    }
    fun isLoaded(x: Double, z: Double) = chunks.containsKey(key(Math.floorDiv(Math.floor(x).toInt(), 16), Math.floorDiv(Math.floor(z).toInt(), 16)))
    /** جامد است؟ (چانک ناشناخته = جامد نیست) */
    fun solidAt(x: Int, y: Int, z: Int): Boolean {
        val s = stateAt(x, y, z)
        return s > 0 && table.solid(s)
    }

    /** نتیجه‌ی بررسی یک پکت: true یعنی خودم مدیریتش کردم. */
    fun handlePacket(id: Int, p: DataInputStream, sendBatchAck: () -> Unit): Boolean {
        val w = ids ?: return false
        val mine = id == w.chunk || id == w.bulk || id == w.unload || id == w.block || id == w.multi ||
            id == w.login || id == w.respawn || (w.batchFinished >= 0 && id == w.batchFinished)
        if (!mine) return false
        try {
            when (id) {
                w.login, w.respawn -> clear()
                w.chunk -> {
                    val raw = ByteArray(p.available()); p.readFully(raw)
                    onChunk(Buf(raw))
                }
                w.bulk -> {
                    val raw = ByteArray(p.available()); p.readFully(raw)
                    onBulk18(Buf(raw))
                }
                w.unload -> {
                    val a = p.readInt(); val b = p.readInt()
                    if (protocol >= 765) chunks.remove(key(b, a)) else chunks.remove(key(a, b))
                }
                w.block -> {
                    val raw = ByteArray(p.available()); p.readFully(raw)
                    onBlock(Buf(raw))
                }
                w.multi -> {
                    val raw = ByteArray(p.available()); p.readFully(raw)
                    onMulti(Buf(raw))
                }
                w.batchFinished -> sendBatchAck()
            }
        } catch (e: Exception) {
            errorCount++
            lastError = "${e.javaClass.simpleName}: ${e.message}"
        }
        return true
    }

    // ------------------------------------------------------------------ چانک

    private fun onChunk(b: Buf) {
        val cx = b.i32(); val cz = b.i32()
        when {
            protocol == 47 -> {
                val groundUp = b.u8() != 0
                val mask = b.i16()
                val size = b.varInt()
                if (groundUp && mask == 0) { chunks.remove(key(cx, cz)); return }
                if (size < 0) throw IllegalStateException("اندازه")
                val secs = parse18(b, mask, Integer.bitCount(mask))
                store(cx, cz, groundUp, 0, secs, mask)
            }
            protocol < 754 -> {  // 1.9 – 1.15 (اینجا فقط 1.12.2)
                val groundUp = b.u8() != 0
                val mask = b.varInt()
                val size = b.varInt()
                val data = Buf(b.b, b.pos, b.pos + size)
                val n = Integer.bitCount(mask)
                val tail = if (groundUp) 256 else 0
                var secs: Array<ShortArray?>? = null
                for (sky in booleanArrayOf(true, false)) {
                    try {
                        data.pos = b.pos
                        val tmp = arrayOfNulls<ShortArray>(16)
                        for (i in 0 until 16) {
                            if (mask and (1 shl i) == 0) continue
                            tmp[i] = readSection112(data)
                            data.skip(2048 + if (sky) 2048 else 0)
                        }
                        if (data.pos + tail == b.pos + size) { secs = tmp; break }
                    } catch (_: Exception) {}
                }
                val use = secs ?: throw IllegalStateException("فرمت چانک 1.12 نامعتبر")
                store(cx, cz, groundUp, 0, use, mask)
            }
            protocol == 754 -> {
                val groundUp = b.u8() != 0
                val mask = b.varInt()
                skipNbt(b, true)
                if (groundUp) { val n = b.varInt(); for (i in 0 until n) b.varInt() }
                val size = b.varInt()
                val data = Buf(b.b, b.pos, b.pos + size)
                val secs = arrayOfNulls<ShortArray>(16)
                for (i in 0 until 16) {
                    if (mask and (1 shl i) == 0) continue
                    data.skip(2)                      // block count
                    secs[i] = readContainer(data, 4096, true, 4, false)
                }
                store(cx, cz, groundUp, 0, secs, mask)
            }
            else -> {  // 1.18+
                when {
                    protocol >= 774 -> {
                        val n = b.varInt()
                        for (i in 0 until n) { b.varInt(); val c = b.varInt(); b.skip(c * 8) }
                    }
                    protocol >= 765 -> skipNbt(b, false)
                    else -> skipNbt(b, true)
                }
                val size = b.varInt()
                val data = Buf(b.b, b.pos, b.pos + size)
                val list = ArrayList<ShortArray?>()
                while (data.left() > 0) {
                    data.skip(2)                      // block count
                    list.add(readContainer(data, 4096, true, 4, true))
                    readContainer(data, 64, false, 1, true)     // biomes (می‌خوانیم و دور می‌ریزیم)
                }
                val minSec = if (list.size == 24) -4 else 0
                store(cx, cz, true, minSec, list.toTypedArray(), -1)
            }
        }
        loadedTotal++
    }

    private fun store(cx: Int, cz: Int, full: Boolean, minSec: Int, secs: Array<ShortArray?>, mask: Int) {
        val k = key(cx, cz)
        if (full || mask == -1) {
            chunks[k] = WorldChunk(cx, cz, minSec, secs)
        } else {
            // به‌روزرسانی بخشی: فقط بخش‌های ماسک‌شده جایگزین می‌شوند
            val old = chunks[k] ?: return
            val s = old.sections.copyOf(16)
            for (i in 0 until 16) if (mask and (1 shl i) != 0) s[i] = secs[i]
            old.sections = s
            old.version++
        }
    }

    /** 1.8: آرایه‌های بلاک (۴۰۹۶ Short کوچک‌اندین) برای هر بخش در ماسک؛ نور و بایوم بعدش می‌آید (لازم نیست). */
    private fun parse18(b: Buf, mask: Int, n: Int): Array<ShortArray?> {
        val secs = arrayOfNulls<ShortArray>(16)
        for (i in 0 until 16) {
            if (mask and (1 shl i) == 0) continue
            val arr = ShortArray(4096)
            for (j in 0 until 4096) {
                val lo = b.u8(); val hi = b.u8()
                arr[j] = ((hi shl 8) or lo).toShort()
            }
            secs[i] = arr
        }
        return secs
    }

    private fun onBulk18(b: Buf) {
        val sky = b.u8() != 0
        val count = b.varInt()
        val xs = IntArray(count); val zs = IntArray(count); val masks = IntArray(count)
        for (i in 0 until count) { xs[i] = b.i32(); zs[i] = b.i32(); masks[i] = b.i16() }
        for (i in 0 until count) {
            val n = Integer.bitCount(masks[i])
            val secs = parse18(b, masks[i], n)
            b.skip(n * 2048 + if (sky) n * 2048 else 0)    // نور
            b.skip(256)                                    // بایوم
            store(xs[i], zs[i], true, 0, secs, masks[i])
            loadedTotal++
        }
    }

    /** 1.12.2: بایت bitsPerBlock، پالت، آرایه‌ی Long با فشرده‌سازی «عبوری از مرز Long». */
    private fun readSection112(d: Buf): ShortArray? {
        val bpb = d.u8()
        val palLen = d.varInt()
        val pal = IntArray(palLen) { d.varInt() }
        val longs = d.varInt()
        val data = LongArray(longs) { d.i64() }
        if (bpb == 0) return null
        val out = ShortArray(4096)
        val mask = (1L shl bpb) - 1
        var any = false
        for (i in 0 until 4096) {
            val bit = i * bpb
            val sl = bit shr 6
            val off = bit and 63
            var v = data[sl] ushr off
            if (off + bpb > 64) v = v or (data[sl + 1] shl (64 - off))
            val idx = (v and mask).toInt()
            val id = if (palLen > 0) (if (idx < palLen) pal[idx] else 0) else idx
            if (id != 0) any = true
            out[i] = id.toShort()
        }
        return if (any) out else null
    }

    /**
     * 1.16+: یک «کانتینر پالت‌دار». longها از مرز Long رد نمی‌شوند.
     * blocks = true: bpb 0 تک‌مقداری، ≤8 پالت، بیشتر مستقیم. blocks = false (بایوم): ≤3 پالت.
     * hasSingle = در 1.18+ حالت تک‌مقداری (bpb=0) وجود دارد.
     */
    private fun readContainer(d: Buf, count: Int, keep: Boolean, minBpb: Int, hasSingle: Boolean): ShortArray? {
        val bpb = d.u8()
        if (hasSingle && bpb == 0) {
            val v = d.varInt()
            val len = d.varInt()
            d.skip(len * 8)
            if (!keep) return null
            if (v == 0) return null
            return ShortArray(count).also { java.util.Arrays.fill(it, v.toShort()) }
        }
        val indirect = if (keep) bpb <= 8 else bpb <= 3
        var pal: IntArray? = null
        if (indirect) {
            val n = d.varInt()
            pal = IntArray(n) { d.varInt() }
        }
        val longs = d.varInt()
        if (!keep) { d.skip(longs * 8); return null }
        val data = LongArray(longs) { d.i64() }
        val b = if (bpb < minBpb && indirect) minBpb else bpb
        val perLong = 64 / b
        val mask = (1L shl b) - 1
        val out = ShortArray(count)
        var any = false
        for (i in 0 until count) {
            val li = i / perLong
            if (li >= data.size) break
            val idx = ((data[li] ushr ((i % perLong) * b)) and mask).toInt()
            val id = if (pal != null) (if (idx < pal.size) pal[idx] else 0) else idx
            if (id != 0) any = true
            out[i] = id.toShort()
        }
        return if (any) out else null
    }

    /** NBT شبکه‌ای را رد می‌کند. named = ریشه نام دارد (قبل از 1.20.2). */
    private fun skipNbt(b: Buf, named: Boolean) {
        val t = b.u8()
        if (t == 0) return
        if (named) b.skip(b.i16())
        skipPayload(b, t, 0)
    }

    private fun skipPayload(b: Buf, t: Int, depth: Int) {
        if (depth > 40) throw IllegalStateException("NBT عمیق")
        when (t) {
            1 -> b.skip(1)
            2 -> b.skip(2)
            3, 5 -> b.skip(4)
            4, 6 -> b.skip(8)
            7 -> b.skip(b.i32())
            8 -> b.skip(b.i16())
            9 -> { val et = b.u8(); val n = b.i32(); for (i in 0 until n) skipPayload(b, et, depth + 1) }
            10 -> while (true) {
                val ct = b.u8()
                if (ct == 0) break
                b.skip(b.i16())
                skipPayload(b, ct, depth + 1)
            }
            11 -> b.skip(b.i32() * 4)
            12 -> b.skip(b.i32() * 8)
            else -> throw IllegalStateException("NBT نوع $t")
        }
    }

    // ------------------------------------------------------------------ تغییر بلاک

    private fun onBlock(b: Buf) {
        val pos = b.i64()
        val state = b.varInt()
        val x: Int; val y: Int; val z: Int
        if (protocol < 754) {
            x = (pos shr 38).toInt(); y = ((pos shr 26) and 0xFFF).toInt(); z = ((pos shl 38) shr 38).toInt()
        } else {
            x = (pos shr 38).toInt(); z = ((pos shl 26) shr 38).toInt(); y = ((pos shl 52) shr 52).toInt()
        }
        chunks[key(Math.floorDiv(x, 16), Math.floorDiv(z, 16))]
            ?.setState(Math.floorMod(x, 16), y, Math.floorMod(z, 16), state)
    }

    private fun onMulti(b: Buf) {
        if (protocol < 754) {
            val cx = b.i32(); val cz = b.i32()
            val n = b.varInt()
            val c = chunks[key(cx, cz)]
            for (i in 0 until n) {
                val hp = b.u8(); val y = b.u8(); val id = b.varInt()
                c?.setState((hp shr 4) and 15, y, hp and 15, id)
            }
        } else {
            val v = b.i64()
            val cx = (v shr 42).toInt()
            val cz = ((v shl 22) shr 42).toInt()
            val sy = ((v shl 44) shr 44).toInt()
            if (protocol in 754..762) b.u8()       // trust edges / suppress light updates
            val n = b.varInt()
            val c = chunks[key(cx, cz)]
            for (i in 0 until n) {
                val r = b.varLong()
                val id = (r ushr 12).toInt()
                val lx = ((r shr 8) and 15).toInt(); val lz = ((r shr 4) and 15).toInt(); val ly = (r and 15).toInt()
                c?.setState(lx, sy * 16 + ly, lz, id)
            }
        }
    }
}
