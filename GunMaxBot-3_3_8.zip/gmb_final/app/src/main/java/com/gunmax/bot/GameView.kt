package com.gunmax.bot

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import android.annotation.SuppressLint
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt
import android.graphics.Bitmap
import android.graphics.RectF

private class BmpEntry(val ver: Int, val bmp: Bitmap)

private val GPanel = Color(0xFF101D19)
private val GPanel2 = Color(0xFF172923)
private val GMint = Color(0xFF39D6A0)
private val GMuted = Color(0xFF9AB0A8)
private val GWhite = Color(0xFFEAF5F0)

/**
 * تب «بازی»: نمایش زنده‌ی بات از بالا (شمال بالا)، جوی‌استیک حرکت و نوار ارسال چت/دستور.
 * نمایش کاملاً محلی و با ۳۰ فریم در ثانیه رسم می‌شود، پس به شبکه وابسته نیست و لگ ندارد.
 */
@Composable
fun GameTab(
    session: McBotSession?,
    botName: String,
    state: Int,                         // 0 آفلاین، 1 در حال ورود، 2 داخل بازی
    logs: List<String>,
    onJoyActive: (Boolean) -> Unit,
    onSend: (String) -> Unit
) {
    val inGame = session != null && state == 2

    // ۳۰ فریم بر ثانیه فقط برای رسم؛ و یک تیک کندتر برای متن مختصات
    var tick by remember { mutableStateOf(0) }
    var slowTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { tick++ } } }   // هم‌گام با نرخ تازه‌سازی صفحه (۶۰ فریم یا بیشتر)
    LaunchedEffect(Unit) { while (true) { delay(250); slowTick++ } }
    val bmpCache = remember(session) { HashMap<Long, BmpEntry>() }
    LaunchedEffect(session) {
        while (true) {
            delay(3000)
            val w = session?.world
            if (w == null) bmpCache.clear()
            else bmpCache.keys.filter { k -> !w.chunks.containsKey(k) }.forEach { k -> bmpCache.remove(k)?.bmp?.recycle() }
        }
    }

    // تا وقتی تب بازی بازه صفحه خاموش نشود (برای دیدن طولانی‌مدت بات)
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // بزرگ‌نمایی (چند بلاک عرض نمایش داده شود) و تصویرِ هر چانک برای رسم سریع
    var zoom by remember { mutableStateOf(32f) }
    val terrainPaint = remember { android.graphics.Paint().apply { isFilterBitmap = false; isAntiAlias = false } }
    val dstRect = remember { RectF() }
    val world = session?.world

    // موقعیت نمایشی نرم‌شده (سرور ۲۰ بار در ثانیه حرکت می‌دهد، نمایش ۶۰ بار)
    val disp = remember { DoubleArray(3) }   // x, z, مقدار اولیه‌شده
    val spawn = remember(session) { DoubleArray(3) }   // نقطه‌ی ورود بات: x, z, ثبت‌شده؟
    val labelPaint = remember { android.graphics.Paint().apply { color = 0xCCBFD3CB.toInt(); isAntiAlias = true } }
    val spawnPaint = remember { android.graphics.Paint().apply { color = 0xFFFFB454.toInt(); isAntiAlias = true; isFakeBoldText = true } }

    // با خروج از تب یا عوض‌شدن بات، حرکت متوقف شود
    DisposableEffect(session) {
        onDispose {
            session?.moveX = 0.0
            session?.moveZ = 0.0
            onJoyActive(false)
        }
    }

    val slow = slowTick
    val coords = if (inGame && session != null && slow >= 0)
        "X %.1f   Y %.1f   Z %.1f".format(session.x, session.y, session.z) else "—"
    val statusText = when {
        session == null || state == 0 -> "آفلاین — اول بات را در تب «بات‌ها» وصل کن"
        state == 1 -> "در حال ورود به سرور..."
        else -> "داخل بازی — $botName"
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(statusText, color = if (inGame) GMint else GMuted, fontSize = 13.sp)

        // ---------- نمایش زنده ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF12302A))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val t = tick   // خواندن این مقدار باعث می‌شود هر فریم دوباره رسم شود
                val w = size.width
                val h = size.height
                val cx = w / 2f
                val cy = h / 2f
                val s = session
                if (s == null || !inGame || t < 0) return@Canvas

                val ppb = w / zoom             // zoom بلاک عرض نمایش داده می‌شود
                if (disp[2] == 0.0 || hypot(s.x - disp[0], s.z - disp[1]) > 8.0) {
                    disp[0] = s.x; disp[1] = s.z; disp[2] = 1.0   // اولین فریم یا تلپورت
                } else {
                    disp[0] += (s.x - disp[0]) * 0.3
                    disp[1] += (s.z - disp[1]) * 0.3
                }
                val bx = disp[0]
                val bz = disp[1]

                val half = zoom / 2f + 2f

                // ---- زمین واقعی از بالا (چانک‌هایی که سرور فرستاده) ----
                if (world != null) {
                    val c0x = floor((bx - half) / 16.0).toInt()
                    val c1x = floor((bx + half) / 16.0).toInt()
                    val c0z = floor((bz - half) / 16.0).toInt()
                    val c1z = floor((bz + half) / 16.0).toInt()
                    drawIntoCanvas { cv ->
                        val nc = cv.nativeCanvas
                        for (ccx in c0x..c1x) for (ccz in c0z..c1z) {
                            val ch = world.chunkAt(ccx, ccz) ?: continue
                            val k = (ccx.toLong() shl 32) or (ccz.toLong() and 0xFFFFFFFFL)
                            val ver = ch.version
                            var entry = bmpCache[k]
                            if (entry == null || entry.ver != ver) {
                                val px = ch.pixels(world.table)
                                val bm = entry?.bmp ?: Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
                                bm.setPixels(px, 0, 16, 0, 0, 16, 16)
                                entry = BmpEntry(ver, bm)
                                bmpCache[k] = entry
                            }
                            val l = cx + ((ccx * 16 - bx) * ppb).toFloat()
                            val t = cy + ((ccz * 16 - bz) * ppb).toFloat()
                            val sz = (16 * ppb).toFloat()
                            dstRect.set(l, t, l + sz + 0.6f, t + sz + 0.6f)
                            nc.drawBitmap(entry.bmp, null, dstRect, terrainPaint)
                        }
                    }
                }
                val hasTerrain = world != null && world.chunks.isNotEmpty()
                val fineA = if (hasTerrain) 0.35f else 1f

                // شبکه‌ی بلاک‌ها؛ مرز چانک (هر ۱۶ بلاک) پررنگ‌تر. خطوط ریز فقط وقتی زوم بالاست
                val gx0 = floor(bx - half).toInt()
                val gx1 = ceil(bx + half).toInt()
                val drawFine = ppb >= 9f
                val draw4 = ppb >= 4f
                for (gx in gx0..gx1) {
                    val chunk = Math.floorMod(gx, 16) == 0
                    val four = Math.floorMod(gx, 4) == 0
                    if (!chunk && !(four && draw4) && !drawFine) continue
                    val px = cx + ((gx - bx) * ppb).toFloat()
                    drawLine(
                        if (chunk) Color(0xAA39D6A0) else if (four) Color(0x55FFFFFF).copy(alpha = 0.33f * fineA) else Color(0x28FFFFFF).copy(alpha = 0.16f * fineA),
                        Offset(px, 0f), Offset(px, h), strokeWidth = if (chunk) 2f else 1f
                    )
                }
                val gz0 = floor(bz - half).toInt()
                val gz1 = ceil(bz + half).toInt()
                for (gz in gz0..gz1) {
                    val chunk = Math.floorMod(gz, 16) == 0
                    val four = Math.floorMod(gz, 4) == 0
                    if (!chunk && !(four && draw4) && !drawFine) continue
                    val py = cy + ((gz - bz) * ppb).toFloat()
                    drawLine(
                        if (chunk) Color(0xAA39D6A0) else if (four) Color(0x55FFFFFF).copy(alpha = 0.33f * fineA) else Color(0x28FFFFFF).copy(alpha = 0.16f * fineA),
                        Offset(0f, py), Offset(w, py), strokeWidth = if (chunk) 2f else 1f
                    )
                }

                // برچسب عدد مختصات روی شبکه تا معلوم باشد بات کجای دنیاست
                val step = if (zoom <= 40f) 4 else 16
                labelPaint.textSize = 10.sp.toPx()
                spawnPaint.textSize = 11.sp.toPx()
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    for (gx in gx0..gx1) {
                        if (Math.floorMod(gx, step) != 0) continue
                        val px = cx + ((gx - bx) * ppb).toFloat()
                        nc.drawText("$gx", px + 3f, cy + ppb * 1.1f, labelPaint)
                    }
                    for (gz in gz0..gz1) {
                        if (Math.floorMod(gz, step) != 0) continue
                        val py = cy + ((gz - bz) * ppb).toFloat()
                        nc.drawText("$gz", cx + ppb * 0.8f, py - 3f, labelPaint)
                    }
                }

                // نقطه‌ی ورود (اسپاون) بات؛ اگر خارج از نمایش باشد، روی لبه با فاصله نشان داده می‌شود
                if (spawn[2] == 0.0) { spawn[0] = s.x; spawn[1] = s.z; spawn[2] = 1.0 }
                val spx = cx + ((spawn[0] - bx) * ppb).toFloat()
                val spy = cy + ((spawn[1] - bz) * ppb).toFloat()
                val ex = spx.coerceIn(18f, w - 18f)
                val ey = spy.coerceIn(18f, h - 18f)
                val dSpawn = hypot(s.x - spawn[0], s.z - spawn[1]).toInt()
                drawCircle(Color(0xFFFFB454), radius = (ppb * 0.4f).coerceAtLeast(6f), center = Offset(ex, ey), style = Stroke(width = 3f))
                drawIntoCanvas { c ->
                    val tx = if (ex > w - 100f) ex - 96f else ex + 12f
                    c.nativeCanvas.drawText("SPAWN ${dSpawn}m", tx, ey + 4f, spawnPaint)
                }

                // ردّ مسیر
                val trail = s.trailSnapshot()
                if (trail.size > 1) {
                    val path = Path()
                    trail.forEachIndexed { i, p ->
                        val px = cx + ((p[0] - bx) * ppb).toFloat()
                        val py = cy + ((p[1] - bz) * ppb).toFloat()
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    drawPath(path, Color(0x8839D6A0), style = Stroke(width = 3f))
                }

                // خود بات + فلش جهت حرکت
                val mx = s.moveX.toFloat()
                val mz = s.moveZ.toFloat()
                val len = hypot(mx, mz)
                if (len > 0.08f) {
                    val k = (if (len > 1f) 1f / len else 1f) * ppb * 1.6f
                    drawLine(Color.White, Offset(cx, cy), Offset(cx + mx * k, cy + mz * k), strokeWidth = 4f)
                }
                val br = (ppb * 0.45f).coerceAtLeast(7f)
                drawCircle(Color(0xFF39D6A0), radius = br, center = Offset(cx, cy))
                drawCircle(Color.White, radius = br, center = Offset(cx, cy), style = Stroke(width = 2f))
            }

            // جهت‌ها
            Text("N", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp))
            Text("S", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
            Text("W", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(AbsoluteAlignment.CenterLeft).absolutePadding(left = 8.dp))
            Text("E", color = GMuted, fontSize = 11.sp, modifier = Modifier.align(AbsoluteAlignment.CenterRight).absolutePadding(right = 8.dp))

            // مختصات
            Surface(
                color = Color(0x99000000), shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            ) {
                Text(coords, color = GWhite, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }

            // آخرین پیام‌های سرور
            val chat = logs.filter { it.contains("💬 سرور:") }.take(3).reversed()
            if (chat.isNotEmpty()) {
                Surface(
                    color = Color(0x99000000), shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).fillMaxWidth(0.8f)
                ) {
                    Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        chat.forEach {
                            Text(
                                it.substringAfter("💬 سرور:").trim(), color = GWhite, fontSize = 11.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // ---------- بزرگ‌نمایی و وضعیت دنیا ----------
        val nChunks = world?.chunks?.size ?: 0
        val worldText = when {
            session == null || !inGame -> ""
            world == null -> "این نسخه جدول بلاک ندارد؛ فقط شبکه نشان داده می‌شود."
            nChunks == 0 -> "هنوز چانکی از سرور نیامده… (چند ثانیه صبر کن)" +
                (if ((world?.errorCount ?: 0) > 0) " — خطای خواندن: ${world?.lastError}" else "")
            else -> "$nChunks چانک بارگذاری شده" +
                (if ((world?.errorCount ?: 0) > 0) " — ${world?.errorCount} خطا: ${world?.lastError}" else "")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            val zoomValues = floatArrayOf(16f, 32f, 64f, 128f)
            val zoomLabels = arrayOf("نزدیک", "۳۲", "۶۴", "دور")
            for (zi in zoomValues.indices) {
                FilterChip(
                    selected = zoom == zoomValues[zi],
                    onClick = { zoom = zoomValues[zi] },
                    label = { Text(zoomLabels[zi], fontSize = 12.sp) }
                )
            }
            if (world != null) {
                var phys by remember(session) { mutableStateOf(session?.worldPhysics ?: true) }
                FilterChip(
                    selected = phys,
                    onClick = { phys = !phys; session?.worldPhysics = phys },
                    label = { Text("روی زمین", fontSize = 12.sp) }
                )
            }
        }
        if (worldText.isNotEmpty()) Text(worldText, color = GMuted, fontSize = 11.sp)

        // ---------- جوی‌استیک ----------
        var joyText by remember { mutableStateOf("") }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Joystick(
                enabled = inGame,
                onMove = { vx, vz ->
                    session?.moveX = vx.toDouble()
                    session?.moveZ = vz.toDouble()
                    joyText = if (vx == 0f && vz == 0f) "" else "جوی‌استیک: X %.2f  Z %.2f".format(vx, vz)
                },
                onActive = onJoyActive
            )
        }
        Text(
            if (!inGame) "جوی‌استیک غیرفعال است: اول بات باید «داخل بازی» باشد"
            else if (joyText.isNotEmpty()) joyText + "   |   spawned=" + (session?.spawned == true)
            else "جوی‌استیک را بکش…",
            color = GMuted, fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth()
        )

        // ---------- ارسال چت / دستور ----------
        var text by remember { mutableStateOf("") }
        val send = {
            val m = text.trim()
            if (m.isNotEmpty() && inGame) {
                onSend(m)
                text = ""
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("چت یا /دستور", color = GMuted) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            FilledIconButton(
                onClick = { send() },
                enabled = inGame,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = GMint, contentColor = Color(0xFF07110F))
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "ارسال")
            }
        }
    }
}

@Composable
private fun Joystick(enabled: Boolean, onMove: (Float, Float) -> Unit, onActive: (Boolean) -> Unit) {
    val size = 170.dp
    val radius = with(LocalDensity.current) { (size / 2).toPx() }
    var knob by remember { mutableStateOf(Offset.Zero) }
    // همیشه آخرین lambda ها را صدا بزن (قبلاً بعد از اتصال دوباره، جوی‌استیک به نشست قدیمی وصل می‌ماند)
    val moveNow by rememberUpdatedState(onMove)
    val activeNow by rememberUpdatedState(onActive)

    Box(
        modifier = Modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(CircleShape)
            .background(GPanel2)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                awaitEachGesture {
                    // از لحظه‌ی لمس کار می‌کند (بدون فاصله‌ی تشخیص کشیدن) و اسکرول صفحه را قطع می‌کند
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    activeNow(true)
                    val center = Offset(radius, radius)
                    fun apply(pos: Offset) {
                        val raw = pos - center
                        val len = hypot(raw.x, raw.y)
                        val v = if (len > radius) raw * (radius / len) else raw
                        knob = v
                        moveNow(v.x / radius, v.y / radius)
                    }
                    apply(down.position)
                    try {
                        while (true) {
                            val event = awaitPointerEvent()
                            val ch = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed) { ch.consume(); break }
                            apply(ch.position)
                            ch.consume()
                        }
                    } finally {
                        knob = Offset.Zero
                        moveNow(0f, 0f)
                        activeNow(false)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(size * 0.9f)
                .clip(CircleShape)
                .background(GPanel)
        )
        Box(
            Modifier
                .absoluteOffset { IntOffset(knob.x.roundToInt(), knob.y.roundToInt()) }
                .size(64.dp)
                .clip(CircleShape)
                .background(GMint)
        )
    }
}


/**
 * نمای کامل داخل خود برنامه: صفحه‌ی GunMax Viewer را (که در Termux روی همین گوشی اجرا می‌شود)
 * اینجا نشان می‌دهد؛ یعنی دید اول‌شخص + مینی‌مپ واقعی + جوی‌استیک، بدون نیاز به Chrome.
 * اول باید در Termux این را بزنی:  cd ~/viewer && npm start
 */
@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
@Composable
fun LiveWebView(modifier: Modifier, reloadKey: Int) {
    val ctx = LocalContext.current
    val wv = remember(reloadKey) {
        WebView(ctx).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            // لمس‌های جوی‌استیک و چرخش دید نباید با اسکرول صفحه قاطی شوند
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
            webViewClient = object : WebViewClient() {
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) {
                        view.loadDataWithBaseURL(
                            null,
                            "<html dir='rtl'><body style='background:#101d19;color:#eaf5f0;font-family:sans-serif;padding:24px;line-height:2'>" +
                                "اتصال برقرار نشد.<br>اول در Termux بنویس:<br><b dir='ltr'>cd ~/viewer && npm start</b><br>" +
                                "صبر کن بنویسد «کنترل‌پنل» و بعد بالا «بارگذاری دوباره» را بزن.</body></html>",
                            "text/html", "UTF-8", null
                        )
                    }
                }
            }
            loadUrl("http://127.0.0.1:8080/")
        }
    }
    DisposableEffect(wv) { onDispose { wv.destroy() } }
    AndroidView(factory = { wv }, modifier = modifier.clip(RoundedCornerShape(16.dp)))
}
