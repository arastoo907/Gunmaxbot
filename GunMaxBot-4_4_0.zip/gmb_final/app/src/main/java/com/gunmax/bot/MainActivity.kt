package com.gunmax.bot

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.nio.charset.StandardCharsets
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF07110F)
private val Panel = Color(0xFF101D19)
private val Panel2 = Color(0xFF172923)
private val Mint = Color(0xFF39D6A0)
private val Muted = Color(0xFF9AB0A8)
private val White = Color(0xFFEAF5F0)

class MainActivity : ComponentActivity() {
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askBatteryOnce() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val am = applicationContext.assets
        BlockTables.loader = { name -> am.open(name).use { it.readBytes() } }   // جدول رنگ بلاک‌ها برای نقشه‌ی بازی
        setContent { GunMaxApp() }
        // اجازه‌ی نوتیفیکیشن (برای سرویس پس‌زمینه) و بعدش معافیت از بهینه‌سازی باتری، تا اندروید بات‌ها را قطع نکند
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            askBatteryOnce()
        }
    }

    private fun askBatteryOnce() {
        val sp = getSharedPreferences("gmb_perm", MODE_PRIVATE)
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !sp.getBoolean("askedBatt", false)) {
            sp.edit().putBoolean("askedBatt", true).apply()
            runCatching {
                startActivity(
                    android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
        }
    }
}

/** یک اکانت بات (از ۳ تا). آدرس سرور، نسخه و لودر بین همه مشترک است. */
private class BotSlot(val index: Int, store: AppStore) {
    val title = "بات شماره ${index + 1}"
    val short = "بات ${index + 1}"
    var name by mutableStateOf(store.str(if (index == 0) "botName" else "botName${index + 1}", "GunMax_${index + 1}"))
    var password by mutableStateOf(store.str(if (index == 0) "botPass" else "botPass${index + 1}", ""))
    var session by mutableStateOf<McBotSession?>(null)
    var connecting by mutableStateOf(false)
    var state by mutableStateOf(0)            // 0 آفلاین، 1 در حال ورود، 2 داخل بازی
    var pendingReconnect by mutableStateOf(false)
    var reconnectIn by mutableStateOf(0)
    var retries by mutableStateOf(0)
    var lastMode by mutableStateOf(AuthMode.LOGIN)
}

@Composable
fun GunMaxApp() {
    val ctx = LocalContext.current
    val store = remember { AppStore(ctx) }
    remember { ModTools.installBundled(ctx, store); true }   // مود همراه برنامه: بار اول نصب و فعال می‌شود
    var command by remember { mutableStateOf("") }
    var commandResult by remember { mutableStateOf("هنوز دستوری ثبت نشده است.") }
    var selected by remember { mutableStateOf("داشبورد") }
    var gameBot by remember { mutableStateOf(0) }
    var joyActive by remember { mutableStateOf(false) }
    var serverHost by remember { mutableStateOf(store.str("host", "play.gunmax.org")) }
    var serverPort by remember { mutableStateOf(store.str("port", "25565")) }
    var pingState by remember { mutableStateOf("هنوز بررسی نشده") }
    var checking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val slots = remember { List(3) { BotSlot(it, store) } }
    var target by remember { mutableStateOf(-1) }   // -1 = همه‌ی بات‌های داخل بازی
    var idsRev by remember { mutableStateOf(0) }
    var versionLabel by remember { mutableStateOf(McVersion.normalize(store.str("version", "1.20.1"))) }
    val selectedVersion = remember(versionLabel, idsRev) { McVersion.resolve(versionLabel, store) }
    var versionMenu by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf(runCatching { AuthMode.valueOf(store.str("authMode", "LOGIN")) }.getOrDefault(AuthMode.LOGIN)) }
    var loginTpl by remember { mutableStateOf(store.str("loginTpl", "/login {pass}")) }
    var registerTpl by remember { mutableStateOf(store.str("registerTpl", "/register {pass} {pass}")) }
    var loader by remember { mutableStateOf(store.str("loader", "vanilla")) }
    var loaderMenu by remember { mutableStateOf(false) }
    var mods by remember { mutableStateOf(store.mods()) }
    var activeMod by remember { mutableStateOf(store.str("activeMod", "")) }
    var idsDialog by remember { mutableStateOf(false) }
    var autoReconnect by remember { mutableStateOf(store.str("autoRe", "0") == "1") }
    var reconnectDelay by remember { mutableStateOf(store.str("reDelay", "10")) }
    var reconnectMax by remember { mutableStateOf(store.str("reMax", "0")) }   // 0 = بی‌نهایت
    val logs = remember { mutableStateListOf<String>() }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    fun addLog(m: String, slot: BotSlot? = null) {
        logs.add(0, "[${timeFmt.format(Date())}] ${if (slot != null) "[${slot.short}] " else ""}$m")
        while (logs.size > 200) logs.removeAt(logs.size - 1)
    }

    LaunchedEffect(serverHost, serverPort, slots[0].name, slots[0].password, slots[1].name, slots[1].password, slots[2].name, slots[2].password, authMode, loginTpl, registerTpl, versionLabel, loader, activeMod, autoReconnect, reconnectDelay, reconnectMax) {
        store.put("autoRe", if (autoReconnect) "1" else "0"); store.put("reDelay", reconnectDelay); store.put("reMax", reconnectMax)
        store.put("host", serverHost); store.put("port", serverPort)
        slots.forEach {
            store.put(if (it.index == 0) "botName" else "botName${it.index + 1}", it.name)
            store.put(if (it.index == 0) "botPass" else "botPass${it.index + 1}", it.password)
        }
        store.put("authMode", authMode.name)
        store.put("loginTpl", loginTpl); store.put("registerTpl", registerTpl)
        store.put("version", versionLabel); store.put("loader", loader); store.put("activeMod", activeMod)
    }

    // انتخاب فایل مود (.jar) از حافظه‌ی گوشی
    val pickMod = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val mcNow = versionLabel
            scope.launch(Dispatchers.IO) {
                try {
                    var name = "mod_${System.currentTimeMillis()}.jar"
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
                    }
                    val dest = File(store.modsDir(), name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    ctx.contentResolver.openInputStream(uri)!!.use { inp -> dest.outputStream().use { inp.copyTo(it) } }
                    val info = ModTools.inspect(dest, mcNow)
                    withContext(Dispatchers.Main) {
                        if (info == null) {
                            dest.delete()
                            addLog("✗ این فایل یک مود معتبر Fabric / Quilt / Forge نیست.")
                        } else {
                            val list = mods.filter { it.file != info.file } + info
                            mods = list; store.saveMods(list)
                            activeMod = info.file; loader = info.loader
                            addLog("✓ مود «${info.name}» ${info.version} (${ModTools.loaderTitle(info.loader)}) برای $mcNow بارگذاری و فعال شد.")
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { addLog("✗ خواندن مود ناموفق: ${e.message ?: e.javaClass.simpleName}") }
                }
            }
        }
    }

    // رمز بات ۲ و ۳ اگر خالی باشد همان رمز بات ۱ استفاده می‌شود
    // ---------- فروشگاه (مود Gun Shop Bot) ----------
    // بات برنامه کد مود را اجرا نمی‌کند؛ این بخش همان کاری را می‌کند که مود برای شمارش فروش می‌کند:
    // پیام سرور شامل «[Divar]» + «just bought» + «9mm» را (از چتی که بات‌ها می‌بینند) می‌شمارد.
    var shopOn by remember { mutableStateOf(store.str("shopOn", "1") == "1") }
    var shopPrice by remember { mutableStateOf(store.str("shopPrice", "100")) }   // پیش‌فرض مود: ۱۰۰ (بازه‌ی ۱ تا ۹۹۹۹۹۹)
    var shopSold by remember { mutableStateOf(store.str("shopSold", "0").toIntOrNull() ?: 0) }
    var shopRevenue by remember { mutableStateOf(store.str("shopRev", "0").toLongOrNull() ?: 0L) }
    val shopLog = remember { mutableStateListOf<String>().also { l -> store.str("shopLog", "").split("\n").filter { it.isNotBlank() }.forEach { l.add(it) } } }
    var shopLastText by remember { mutableStateOf("") }
    var shopLastAt by remember { mutableStateOf(0L) }
    var shopResetAsk by remember { mutableStateOf(false) }
    val shopPriceValue = shopPrice.toIntOrNull()?.takeIf { it in 1..999999 }
    LaunchedEffect(shopOn, shopPrice) { store.put("shopOn", if (shopOn) "1" else "0"); store.put("shopPrice", shopPrice) }

    fun shopOnChat(text: String) {
        if (!shopOn) return
        if (!(text.contains("[Divar]") && text.contains("just bought") && text.contains("9mm"))) return
        val now = System.currentTimeMillis()
        // اگر چند بات هم‌زمان داخل سرور باشند همان پیام را چندبار می‌بینند؛ یک‌بار شمرده شود
        if (text == shopLastText && now - shopLastAt < 3000) return
        shopLastText = text; shopLastAt = now
        shopSold += 1
        shopRevenue += (shopPriceValue ?: 0)
        store.put("shopSold", shopSold.toString()); store.put("shopRev", shopRevenue.toString())
        shopLog.add(0, "[${timeFmt.format(Date(now))}] ${text.replace("\n", " ")}")
        while (shopLog.size > 30) shopLog.removeAt(shopLog.size - 1)
        store.put("shopLog", shopLog.joinToString("\n"))
        addLog("🛒 فروش ثبت شد! مجموع: $shopSold")
    }

    fun shopListNow() {
        val price = shopPriceValue
        if (price == null) { addLog("✗ قیمت باید عددی بین ۱ تا ۹۹۹۹۹۹ باشد."); return }
        val sl = slots.firstOrNull { it.state == 2 && it.session != null }
        if (sl == null) { addLog("✗ هیچ باتی داخل سرور نیست."); return }
        scope.launch(Dispatchers.IO) { sl.session?.sendChat("/ah sell $price") }
    }

    fun passOf(slot: BotSlot) = slot.password.ifBlank { slots[0].password }

    // یک تابع مشترک برای وصل/قطع هر بات؛ هم از کارت هر بات و هم از دکمه‌های «همه» صدا زده می‌شود
    fun toggleBot(slot: BotSlot, mode: AuthMode = authMode) {
        val cur = slot.session
        slot.pendingReconnect = false
        if (cur != null && cur.connected) {
            cur.stop()
            addLog("دستور قطع اتصال صادر شد.", slot)
            return
        }
        if (slot.connecting) return
        val port = serverPort.toIntOrNull()
        if (serverHost.isBlank() || port == null || port !in 1..65535 || slot.name.length < 3) {
            addLog("✗ آدرس، پورت یا نام بات نامعتبر است (نام بات حداقل ۳ کاراکتر).", slot)
            return
        }
        if (slots.any { it !== slot && it.name.equals(slot.name, ignoreCase = true) }) {
            addLog("✗ نام «${slot.name}» با بات دیگری یکی است. سرور دو بازیکن هم‌نام را قبول نمی‌کند؛ در تنظیمات نام‌ها را متفاوت کن.", slot)
            return
        }
        val pass = passOf(slot)
        val tpl = if (mode == AuthMode.LOGIN) loginTpl else registerTpl
        if (mode != AuthMode.NONE && tpl.isBlank()) {
            addLog("✗ دستور ${if (mode == AuthMode.LOGIN) "لاگین" else "ریجستر"} در تنظیمات خالی است.", slot)
            return
        }
        if (mode != AuthMode.NONE && tpl.contains("{pass}") && pass.isBlank()) {
            addLog("✗ دستور شامل {pass} است ولی رمز خالی است. یا رمز را بگذار یا دستور کامل را بنویس (مثلاً /login 1234).", slot)
            return
        }
        slot.lastMode = mode
        slot.connecting = true
        val brand = ModTools.brandFor(loader)
        val s = McBotSession(serverHost.trim(), port, selectedVersion, slot.name, pass,
            mode, loginTpl, registerTpl, brand) { m ->
            scope.launch { addLog(m, slot) }
        }
        s.chatListener = { t -> scope.launch { shopOnChat(t) } }
        slot.session = s
        SessionRegistry.list.removeAll { it.manualStop }
        SessionRegistry.list.add(s)
        val modeText = when (mode) { AuthMode.LOGIN -> "حالت لاگین"; AuthMode.REGISTER -> "حالت ریجستر"; else -> "بدون لاگین/ریجستر" }
        addLog("در حال اتصال به ${serverHost.trim()}:$port با نام «${slot.name}» (${selectedVersion.label}، ${ModTools.loaderTitle(loader)}، $modeText)...", slot)
        mods.firstOrNull { it.file == activeMod }?.let {
            addLog("مود فعال: ${it.name} ${it.version} (${ModTools.loaderTitle(it.loader)})", slot)
        }
        scope.launch(Dispatchers.IO) {
            try {
                s.connect()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    addLog("✗ اتصال برقرار نشد: ${e.javaClass.simpleName} — ${e.message ?: "بدون پیام خطا"}", slot)
                    if (autoReconnect && !s.manualStop) slot.pendingReconnect = true
                }
            }
            withContext(Dispatchers.Main) { slot.connecting = false }
        }
    }

    // وصل‌کردن هر ۳ بات؛ بین هر دو بات ۵ ثانیه فاصله است چون سرورها (connection-throttle) اتصال‌های پشت‌سرهم از یک IP را رد می‌کنند
    fun connectAll(mode: AuthMode = authMode) {
        scope.launch {
            var first = true
            for (slot in slots) {
                if (slot.connecting || slot.session?.connected == true) continue
                if (!first) delay(5000)
                first = false
                toggleBot(slot, mode)
            }
        }
    }

    fun disconnectAll() {
        slots.forEach { sl ->
            sl.pendingReconnect = false
            val cur = sl.session
            if (cur != null && cur.connected) { cur.stop(); addLog("دستور قطع اتصال صادر شد.", sl) }
        }
    }

    val onlineCount = slots.count { it.state == 2 }
    val anyActive = slots.any { it.state != 0 }
    val allActive = slots.all { it.state != 0 }

    // تا وقتی بات وصل است (یا منتظر ری‌کانکت)، سرویس پیش‌زمینه روشن بماند تا در پس‌زمینه قطع نشود
    val keepAlive = anyActive || slots.any { it.pendingReconnect || it.connecting }
    LaunchedEffect(keepAlive, onlineCount) {
        if (keepAlive) BotService.update(ctx, onlineCount) else BotService.stop(ctx)
    }

    slots.forEach { slot ->
        // وضعیت هر بات را هر نیم‌ثانیه از روی نشست می‌خواند
        LaunchedEffect(slot.session) {
            var prev = 0
            while (true) {
                val cur = slot.session
                val ns = when {
                    cur == null || !cur.connected -> 0
                    cur.spawned -> 2
                    else -> 1
                }
                if (ns == 2) slot.retries = 0
                if (prev != 0 && ns == 0 && cur != null && !cur.manualStop && autoReconnect) slot.pendingReconnect = true
                slot.state = ns
                prev = ns
                delay(500)
            }
        }

        // اتو ری‌کانکت: بعد از قطع‌شدن (نه قطع دستی) به اندازه‌ی تایمی که خودت گذاشتی صبر می‌کند و دوباره وصل می‌شود
        // (بات ۲ و ۳ هر کدام ۵ ثانیه دیرتر تا سرور اتصال‌ها را throttle نکند)
        LaunchedEffect(slot.pendingReconnect) {
            if (!slot.pendingReconnect) { slot.reconnectIn = 0; return@LaunchedEffect }
            val max = reconnectMax.toIntOrNull() ?: 0
            if (max > 0 && slot.retries >= max) {
                addLog("⏹ اتو ری‌کانکت بعد از $max تلاش متوقف شد.", slot)
                slot.pendingReconnect = false
                return@LaunchedEffect
            }
            val wait = (reconnectDelay.toIntOrNull() ?: 10).coerceIn(1, 3600) + slot.index * 5
            addLog("🔁 اتصال دوباره تا $wait ثانیه‌ی دیگر...", slot)
            for (i in wait downTo 1) { slot.reconnectIn = i; delay(1000) }
            slot.reconnectIn = 0
            slot.retries++
            slot.pendingReconnect = false
            toggleBot(slot, slot.lastMode)
        }
    }


    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Mint,
        onBackground = White, onSurface = White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (idsDialog) {
                IdsDialog(selectedVersion, store, onDismiss = { idsDialog = false }, onSaved = { idsRev++; idsDialog = false })
            }
            if (shopResetAsk) {
                AlertDialog(
                    onDismissRequest = { shopResetAsk = false },
                    title = { Text("صفر کردن آمار فروش؟") },
                    text = { Text("تعداد فروش، درآمد و فهرست آخرین فروش‌ها پاک می‌شود.") },
                    confirmButton = {
                        TextButton(onClick = {
                            shopSold = 0; shopRevenue = 0L; shopLog.clear()
                            store.put("shopSold", "0"); store.put("shopRev", "0"); store.put("shopLog", "")
                            shopResetAsk = false
                        }) { Text("صفر کن", color = Mint) }
                    },
                    dismissButton = { TextButton(onClick = { shopResetAsk = false }) { Text("انصراف") } }
                )
            }
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Mint) {
                        listOf("داشبورد" to Icons.Default.Dashboard,
                            "بات‌ها" to Icons.Default.SmartToy,
                            "بازی" to Icons.Default.SportsEsports,
                            "فروشگاه" to Icons.Default.Storefront,
                            "کنسول" to Icons.Default.Terminal,
                            "تنظیمات" to Icons.Default.Settings).forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = selected == label,
                                onClick = { selected = label },
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Mint, selectedTextColor = Mint,
                                    indicatorColor = Panel2, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    userScrollEnabled = !joyActive
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()) {
                            Column {
                                Text("گانمکس بات", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
                                Text("مدیریت هوشمند بات‌های Minecraft", color = Muted, fontSize = 12.sp)
                            }
                            Surface(shape = RoundedCornerShape(16.dp), color = Mint.copy(alpha = .16f)) {
                                Icon(Icons.Default.Diamond, null, tint = Mint, modifier = Modifier.padding(14.dp).size(28.dp))
                            }
                        }
                    }
                    when (selected) {
                        "داشبورد" -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StatCard("بات‌های فعال", "$onlineCount / 3", Icons.Default.SmartToy, Modifier.weight(1f))
                                    StatCard("وظایف امروز", "۰", Icons.Default.TaskAlt, Modifier.weight(1f))
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Hub, null, tint = Mint)
                                            Spacer(Modifier.width(8.dp))
                                            Text("کنترل مرکزی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                            Spacer(Modifier.weight(1f))
                                            Surface(color = if (anyActive) Mint.copy(alpha=.18f) else Panel2, shape = RoundedCornerShape(30.dp)) {
                                                Text(
                                                    when { onlineCount > 0 -> "$onlineCount آنلاین"; anyActive -> "در حال ورود"; else -> "متوقف" },
                                                    color = if (anyActive) Mint else Muted,
                                                    modifier = Modifier.padding(horizontal=12.dp, vertical=6.dp), fontSize=12.sp
                                                )
                                            }
                                        }
                                        // این دکمه هر ۳ بات را با تنظیمات فعلی (آدرس/پورت/نام/نسخه در تب «تنظیمات») وصل یا قطع می‌کند
                                        Button(
                                            onClick = { if (allActive) disconnectAll() else connectAll() },
                                            enabled = slots.none { it.connecting },
                                            modifier = Modifier.fillMaxWidth().height(52.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (allActive) Color(0xFFB83D62) else Mint),
                                            shape = RoundedCornerShape(15.dp)
                                        ) {
                                            Icon(if (allActive) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                if (slots.any { it.connecting }) "در حال اتصال..." else if (allActive) "قطع همه‌ی بات‌ها" else if (anyActive) "اتصال بات‌های آفلاین" else "اتصال هر ۳ بات",
                                                color = Color(0xFF06110D), fontWeight = FontWeight.Bold
                                            )
                                        }
                                        slots.forEach { sl ->
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Column(Modifier.weight(1f)) {
                                                    Text(sl.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                    Text(
                                                        "${sl.name} • " + when {
                                                            sl.state == 2 -> "آنلاین"
                                                            sl.state == 1 -> "در حال ورود"
                                                            sl.pendingReconnect -> "ری‌کانکت ${sl.reconnectIn}ث"
                                                            else -> "آفلاین"
                                                        },
                                                        color = if (sl.state == 2) Mint else Muted, fontSize = 11.sp
                                                    )
                                                }
                                                Button(
                                                    onClick = { toggleBot(sl) },
                                                    enabled = !sl.connecting,
                                                    colors = ButtonDefaults.buttonColors(containerColor = if (sl.state != 0) Color(0xFFB83D62) else Mint)
                                                ) { Text(if (sl.state != 0) "قطع" else "اتصال", color = Bg, fontWeight = FontWeight.Bold) }
                                            }
                                        }
                                        Text("آدرس، پورت، نام‌ها و نسخه را از تب «تنظیمات» عوض کن. بات‌ها با ۵ ثانیه فاصله وصل می‌شوند.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Text("آخرین رویدادها", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (logs.isEmpty()) {
                                            LogLine("سیستم", "آماده. از تب بات‌ها شروع کن.", Mint)
                                        } else {
                                            logs.take(5).forEach { LogLine("بات", it, Mint) }
                                            TextButton(onClick = { selected = "کنسول" }) { Text("مشاهده کنسول کامل ›", color = Mint) }
                                        }
                                    }
                                }
                            }
                        }
                        "بات‌ها" -> {
                            item {
                                Text("اکانت‌های بات", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                            items(3) { index ->
                                val slot = slots[index]
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                                                Icon(Icons.Default.SmartToy, null, tint = Mint, modifier = Modifier.padding(11.dp))
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(slot.title, fontWeight = FontWeight.SemiBold)
                                                Text("${slot.name} • ${selectedVersion.label}", color = Muted, fontSize = 11.sp)
                                            }
                                            Surface(color = if (slot.state == 2) Mint.copy(alpha = .18f) else Color(0xFF39453F), shape = RoundedCornerShape(30.dp)) {
                                                Text(
                                                    when {
                                                        slot.state == 2 -> "آنلاین"
                                                        slot.state == 1 -> "در حال ورود"
                                                        slot.pendingReconnect -> "ری‌کانکت ${slot.reconnectIn}ث"
                                                        else -> "آفلاین"
                                                    },
                                                    color = if (slot.state == 2) Mint else Muted, fontSize = 11.sp,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                        if (slot.state != 0) {
                                            Button(
                                                onClick = { toggleBot(slot) },
                                                modifier = Modifier.fillMaxWidth().height(46.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB83D62))
                                            ) { Text("قطع اتصال ${slot.short}", color = Bg, fontWeight = FontWeight.Bold) }
                                        } else {
                                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                                Button(
                                                    onClick = { toggleBot(slot, AuthMode.LOGIN) },
                                                    enabled = !slot.connecting,
                                                    modifier = Modifier.weight(1f).height(46.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = Mint)
                                                ) { Text("ورود (لاگین)", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                                Button(
                                                    onClick = { toggleBot(slot, AuthMode.REGISTER) },
                                                    enabled = !slot.connecting,
                                                    modifier = Modifier.weight(1f).height(46.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5BA8F5))
                                                ) { Text("ثبت‌نام (ریجستر)", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                            }
                                            TextButton(onClick = { toggleBot(slot, AuthMode.NONE) }, enabled = !slot.connecting, modifier = Modifier.fillMaxWidth()) {
                                                Text("ورود بدون لاگین/ریجستر", color = Muted, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("وضعیت واقعی سرور Minecraft", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("آدرس فعلی: $serverHost:$serverPort (قابل تغییر در تنظیمات)", color = Muted, fontSize = 11.sp)
                                        Button(onClick = {
                                            val port = serverPort.toIntOrNull()
                                            if (serverHost.isBlank() || port == null || port !in 1..65535) {
                                                pingState = "آدرس یا پورت نامعتبر است"
                                            } else {
                                                checking = true
                                                pingState = "در حال دریافت وضعیت Minecraft..."
                                                scope.launch {
                                                    val result = withContext(Dispatchers.IO) {
                                                        try {
                                                            MinecraftStatusClient.query(serverHost.trim(), port)
                                                        } catch (e: Exception) {
                                                            "اتصال برقرار نشد: ${e.javaClass.simpleName} — ${e.message ?: "بدون جزئیات"}"
                                                        }
                                                    }
                                                    pingState = result
                                                    checking = false
                                                }
                                            }
                                        }, enabled = !checking, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Text(if (checking) "در حال بررسی..." else "بررسی اتصال", color = Bg)
                                        }
                                        Text(pingState, color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("ورود هر ۳ بات به سرور", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("سرور: $serverHost:$serverPort • نسخه: ${selectedVersion.label} • لودر: ${ModTools.loaderTitle(loader)} (قابل تغییر در تنظیمات)", color = Muted, fontSize = 11.sp)
                                        Text("$onlineCount از ۳ بات داخل بازی است", color = if (onlineCount > 0) Mint else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        // لاگین همیشه فقط /login می‌زند، ریجستر همیشه فقط /register
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                            Button(
                                                onClick = { connectAll(AuthMode.LOGIN) },
                                                enabled = slots.none { it.connecting },
                                                modifier = Modifier.weight(1f).height(50.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Mint)
                                            ) { Text("لاگین هر ۳", color = Bg, fontWeight = FontWeight.Bold) }
                                            Button(
                                                onClick = { connectAll(AuthMode.REGISTER) },
                                                enabled = slots.none { it.connecting },
                                                modifier = Modifier.weight(1f).height(50.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5BA8F5))
                                            ) { Text("ریجستر هر ۳", color = Bg, fontWeight = FontWeight.Bold) }
                                        }
                                        TextButton(onClick = { connectAll(AuthMode.NONE) }, enabled = slots.none { it.connecting }, modifier = Modifier.fillMaxWidth()) {
                                            Text("ورود هر ۳ بدون لاگین/ریجستر", color = Muted, fontSize = 12.sp)
                                        }
                                        if (anyActive) {
                                            Button(
                                                onClick = { disconnectAll() },
                                                modifier = Modifier.fillMaxWidth().height(46.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB83D62))
                                            ) { Text("قطع همه‌ی بات‌ها", color = Bg, fontWeight = FontWeight.Bold) }
                                        }
                                        Text("بات‌ها با ۵ ثانیه فاصله وارد می‌شوند تا سرور به‌خاطر اتصال پشت‌سرهم از یک IP آن‌ها را رد نکند. هر بات را جداگانه هم می‌توانی پایین همین صفحه وصل کنی.", color = Muted, fontSize = 11.sp)
                                        Text("فقط سرورهای آفلاین‌مود (کرک) پشتیبانی می‌شود. از بات فقط روی سرور خودت یا سروری که اجازه داده استفاده کن.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("دستور هوشمند", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("این بخش هوش مصنوعی نیست؛ فقط چند دستور مشخص را می‌فهمد: سلام یا بگو ...، برو (۳ عدد مختصات، یا مثلاً «برو شمال 10»)، منتظر، /دستور، وضعیت، بایست، قطع. چند دستور را با «سپس» یا | یا خط جدید پشت‌سر هم بنویس.", color = Muted, fontSize = 12.sp)
                                        Surface(color = Bg, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                            BasicTextField(
                                                value = command, onValueChange = { command = it },
                                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                                textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
                                                decorationBox = { inner ->
                                                    if (command.isEmpty()) Text("مثلاً: بگو سلام سپس برو به مختصات 250 40 120", color = Muted)
                                                    inner()
                                                }
                                            )
                                        }
                                        Text("دستور برای کدام بات اجرا شود؟", color = Muted, fontSize = 12.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                            listOf(-1 to "همه", 0 to "بات ۱", 1 to "بات ۲", 2 to "بات ۳").forEach { (idx, t) ->
                                                Button(
                                                    onClick = { target = idx },
                                                    modifier = Modifier.weight(1f),
                                                    contentPadding = PaddingValues(horizontal = 2.dp),
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = if (target == idx) Mint else Panel2,
                                                        contentColor = if (target == idx) Bg else White
                                                    )
                                                ) { Text(t, fontSize = 12.sp) }
                                            }
                                        }
                                        Button(onClick = {
                                            val targets = slots.filter { (target == -1 || it.index == target) && it.state == 2 && it.session != null }
                                            if (targets.isEmpty()) {
                                                commandResult = "اول بات انتخاب‌شده را وارد سرور کن."
                                            } else {
                                                commandResult = "در حال اجرا..."
                                                val text = command
                                                val pairs = targets.mapNotNull { sl -> sl.session?.let { sl to it } }
                                                scope.launch(Dispatchers.IO) {
                                                    val results = pairs.map { (sl, sess) ->
                                                        async { sl.short to executeCommands(sess, text) }
                                                    }.awaitAll()
                                                    val r = if (results.size == 1) results[0].second
                                                        else results.joinToString("\n\n") { (n, res) -> "$n:\n$res" }
                                                    withContext(Dispatchers.Main) { commandResult = r }
                                                }
                                            }
                                        }, enabled = command.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Icon(Icons.Default.AutoAwesome, null, tint = Bg)
                                            Spacer(Modifier.width(8.dp))
                                            Text("اجرای دستور", color = Bg, fontWeight = FontWeight.Bold)
                                        }
                                        Surface(color = Panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text(commandResult, color = White, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                                        }
                                        Text("نمونه: برو به مختصات 250 40 120 و منتظر بمان 5 ثانیه سپس بگو سلام | /home | قطع شو", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        "بازی" -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    slots.forEach { sl ->
                                        FilterChip(
                                            selected = gameBot == sl.index,
                                            onClick = { gameBot = sl.index },
                                            label = { Text(sl.short) }
                                        )
                                    }
                                }
                            }
                            item {
                                val gs = slots[gameBot]
                                GameTab(
                                    session = gs.session,
                                    botName = gs.name,
                                    state = gs.state,
                                    logs = logs,
                                    onJoyActive = { joyActive = it },
                                    onSend = { msg ->
                                        val ss = gs.session
                                        if (ss != null) scope.launch(Dispatchers.IO) { ss.sendChat(msg) }
                                    }
                                )
                            }
                        }
                        "کنسول" -> {
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("کنسول کامل", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { logs.clear() }) { Text("پاک کردن", color = Muted) }
                                }
                            }
                            item {
                                Text(
                                    "همه‌ی پیام‌های بازی (چت بازیکنان، جواب دستورها، پیام‌های سرور)، رویدادها، خطاها و دلیل قطع اتصال اینجا ثبت می‌شود.",
                                    color = Muted, fontSize = 12.sp
                                )
                            }
                            if (logs.isEmpty()) {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                                        Text("هنوز رویدادی ثبت نشده.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
                                    }
                                }
                            } else {
                                items(logs.size) { i ->
                                    Surface(color = Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Text(
                                            logs[i], color = if (logs[i].contains("✗") || logs[i].contains("بیرون انداخته") || logs[i].contains("قطع شد")) Color(0xFFE8738B) else White,
                                            fontSize = 12.sp, modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                        "فروشگاه" -> {
                            item { Text("فروشگاه مود (Gun Shop Bot)", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Column(Modifier.weight(1f)) {
                                                Text("روشن / خاموش", fontWeight = FontWeight.Bold)
                                                Text(
                                                    if (shopOn) "روشن — فروش‌ها شمرده می‌شود" else "خاموش — هیچ فروشی ثبت نمی‌شود",
                                                    color = if (shopOn) Mint else Muted, fontSize = 12.sp
                                                )
                                            }
                                            Switch(checked = shopOn, onCheckedChange = { shopOn = it })
                                        }
                                        Surface(color = if (onlineCount > 0) Mint.copy(alpha = .16f) else Panel2, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                if (onlineCount > 0) "✓ $onlineCount بات داخل سرور است؛ پیام‌های فروش را می‌بیند."
                                                else "✗ هیچ باتی داخل سرور نیست، پس فعلاً چیزی شمرده نمی‌شود. اول در تب «بات‌ها» وصل شو (اگر وصل نمی‌شود، کنسول را ببین).",
                                                fontSize = 12.sp, modifier = Modifier.padding(10.dp)
                                            )
                                        }
                                        OutlinedTextField(
                                            value = shopPrice,
                                            onValueChange = { shopPrice = it.filter(Char::isDigit).take(6) },
                                            label = { Text("قیمت فروش (۱ تا ۹۹۹۹۹۹)") },
                                            isError = shopPriceValue == null,
                                            singleLine = true, modifier = Modifier.fillMaxWidth()
                                        )
                                        Button(
                                            onClick = { shopListNow() },
                                            enabled = shopOn && shopPriceValue != null && onlineCount > 0,
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Mint)
                                        ) {
                                            Icon(Icons.Default.Sell, null, tint = Bg)
                                            Spacer(Modifier.width(8.dp))
                                            Text("ارسال /ah sell ${shopPriceValue ?: ""} با بات", color = Bg, fontWeight = FontWeight.Bold)
                                        }
                                        Text("دکمه‌ی بالا همان دستوری را می‌زند که مود می‌زند، با آیتم داخل دست بات (اگر بات آیتمی در دست نداشته باشد سرور رد می‌کند).", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StatCard("فروش‌رفته", "$shopSold", Icons.Default.ShoppingCart, Modifier.weight(1f))
                                    StatCard("درآمد", String.format(Locale.US, "%,d", shopRevenue), Icons.Default.Paid, Modifier.weight(1f))
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("آخرین فروش‌ها", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { shopResetAsk = true }, enabled = shopSold > 0 || shopLog.isNotEmpty()) { Text("صفر کردن آمار", color = Mint) }
                                }
                            }
                            if (shopLog.isEmpty()) {
                                item { Text("هنوز فروشی ثبت نشده. فروش وقتی شمرده می‌شود که حداقل یک بات داخل سرور باشد و پیام «[Divar] … just bought … 9mm» را ببیند.", color = Muted, fontSize = 12.sp) }
                            } else {
                                items(shopLog.size) { i ->
                                    Surface(color = Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Text(shopLog[i], fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                                    }
                                }
                            }
                            item {
                                Text("توجه: بات برنامه کد مود را اجرا نمی‌کند، پس این بخش مود داخل ماینکرفت واقعی را کنترل نمی‌کند؛ قیمت و روشن/خاموش مخصوص خود برنامه است. «درآمد» = قیمتِ تنظیم‌شده در لحظه‌ی هر فروش، جمع‌شده. آمار فقط فروش‌هایی را می‌شمارد که وقتی بات داخل سرور بوده اتفاق افتاده.", color = Muted, fontSize = 11.sp)
                            }
                        }
                        "تنظیمات" -> {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("تنظیمات اتصال", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(value = serverHost, onValueChange = { serverHost = it }, label = { Text("آدرس سرور") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = serverPort, onValueChange = { serverPort = it.filter(Char::isDigit).take(5) }, label = { Text("پورت") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        slots.forEach { sl ->
                                            OutlinedTextField(
                                                value = sl.name,
                                                onValueChange = { sl.name = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(16) },
                                                label = { Text("نام ${sl.short} (انگلیسی، متفاوت از بقیه)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                                            )
                                            OutlinedTextField(
                                                value = sl.password,
                                                onValueChange = { sl.password = it.filter { c -> !c.isWhitespace() }.take(32) },
                                                label = { Text(if (sl.index == 0) "رمز ${sl.short} (فقط اگه تو دستور {pass} نوشتی)" else "رمز ${sl.short} (خالی = همان رمز بات ۱)") }, singleLine = true,
                                                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                        Text("حالت پیش‌فرض دکمه‌ی «اتصال هر ۳ بات» در داشبورد:", color = Muted, fontSize = 12.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                            listOf(AuthMode.LOGIN to "فقط لاگین", AuthMode.REGISTER to "فقط ریجستر", AuthMode.NONE to "هیچ‌کدام").forEach { (m, t) ->
                                                Button(
                                                    onClick = { authMode = m },
                                                    modifier = Modifier.weight(1f),
                                                    contentPadding = PaddingValues(horizontal = 4.dp),
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = if (authMode == m) Mint else Panel2,
                                                        contentColor = if (authMode == m) Bg else White
                                                    )
                                                ) { Text(t, fontSize = 12.sp) }
                                            }
                                        }
                                        OutlinedTextField(value = loginTpl, onValueChange = { loginTpl = it }, label = { Text("دستور لاگین کامل (مثلاً /login 1234)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(value = registerTpl, onValueChange = { registerTpl = it }, label = { Text("دستور ریجستر کامل (مثلاً /register 1234 1234)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Text("اتو ری‌کانکت (وصل‌شدن دوباره بعد از قطع)", modifier = Modifier.weight(1f), fontSize = 13.sp)
                                            Switch(checked = autoReconnect, onCheckedChange = { autoReconnect = it; if (!it) slots.forEach { sl -> sl.pendingReconnect = false } })
                                        }
                                        if (autoReconnect) {
                                            OutlinedTextField(value = reconnectDelay, onValueChange = { reconnectDelay = it.filter(Char::isDigit).take(4) },
                                                label = { Text("تایم ری‌کانکت (ثانیه)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(value = reconnectMax, onValueChange = { reconnectMax = it.filter(Char::isDigit).take(3) },
                                                label = { Text("حداکثر تلاش پشت‌سرهم (۰ = بی‌نهایت)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        }
                                        Box(Modifier.fillMaxWidth()) {
                                            OutlinedButton(onClick = { versionMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text("نسخه‌ی ورود: ${selectedVersion.label}", color = White)
                                            }
                                            DropdownMenu(expanded = versionMenu, onDismissRequest = { versionMenu = false }) {
                                                McVersion.ALL.forEach { v ->
                                                    DropdownMenuItem(
                                                        text = { Text(v.label) },
                                                        onClick = { versionLabel = v.label; versionMenu = false }
                                                    )
                                                }
                                            }
                                        }
                                        Box(Modifier.fillMaxWidth()) {
                                            OutlinedButton(onClick = { loaderMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                                Text("لودر: ${ModTools.loaderTitle(loader)}", color = White)
                                            }
                                            DropdownMenu(expanded = loaderMenu, onDismissRequest = { loaderMenu = false }) {
                                                ModTools.LOADERS.forEach { l ->
                                                    DropdownMenuItem(text = { Text(ModTools.loaderTitle(l)) }, onClick = { loader = l; loaderMenu = false })
                                                }
                                            }
                                        }
                                        OutlinedButton(onClick = { idsDialog = true }, modifier = Modifier.fillMaxWidth()) {
                                            Text("ویرایش شناسه‌ی پکت‌های ${selectedVersion.label}", color = White, fontSize = 12.sp)
                                        }
                                        Text("آدرس، نسخه و لودر بین هر ۳ بات مشترک است؛ نام و رمز هر بات جدا. این تنظیمات برای دکمه‌های اتصال در تب‌های داشبورد و بات‌ها استفاده می‌شود.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("مود و لودر (Fabric / Forge ...)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                        Text("فایل .jar مود را بارگذاری کن؛ بات با همان نسخه و لودر وارد سرور می‌شود (نام کلاینت مثلاً fabric اعلام می‌شود و جواب پرس‌وجوهای Fabric API داده می‌شود). بات یک کلاینت واقعی نیست و کد مود را اجرا نمی‌کند؛ هندشیک کامل مودهای Forge پشتیبانی نمی‌شود.", color = Muted, fontSize = 11.sp)
                                        Button(onClick = { pickMod.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                            Icon(Icons.Default.Add, null, tint = Bg)
                                            Spacer(Modifier.width(8.dp))
                                            Text("بارگذاری فایل مود (.jar) برای ${selectedVersion.label}", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        if (mods.isEmpty()) {
                                            Text("هنوز مودی بارگذاری نشده.", color = Muted, fontSize = 12.sp)
                                        }
                                        mods.forEach { m ->
                                            val active = m.file == activeMod
                                            Surface(color = if (active) Mint.copy(alpha = .14f) else Panel2, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Column(Modifier.weight(1f)) {
                                                        Text(m.name + " " + m.version, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                        Text("${ModTools.loaderTitle(m.loader)} • ${m.mc}${if (active) " • فعال" else ""}", color = Muted, fontSize = 11.sp)
                                                    }
                                                    if (!active) {
                                                        TextButton(onClick = { activeMod = m.file; versionLabel = McVersion.normalize(m.mc); loader = m.loader }) { Text("استفاده", color = Mint) }
                                                    }
                                                    TextButton(onClick = {
                                                        File(store.modsDir(), m.file).delete()
                                                        val list = mods.filter { it.file != m.file }
                                                        mods = list; store.saveMods(list)
                                                        if (activeMod == m.file) activeMod = ""
                                                    }) { Text("حذف", color = Color(0xFFE8738B)) }
                                                }
                                            }
                                        }
                                        if (activeMod.isNotEmpty()) {
                                            TextButton(onClick = { activeMod = "" }, modifier = Modifier.fillMaxWidth()) { Text("غیرفعال کردن مود", color = Muted) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IdsDialog(v: McVersion, store: AppStore, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val base = McVersion.ALL.first { it.label == v.label }
    val fields = listOf(
        "sKeepAlive" to "Keep-Alive از سرور",
        "sDisconnect" to "Disconnect (بیرون‌انداختن) از سرور",
        "sPosLook" to "موقعیت بات از سرور",
        "sSystemChat" to "پیام چت سیستم از سرور",
        "cKeepAlive" to "Keep-Alive به سرور",
        "cPosition" to "موقعیت به سرور",
        "cChat" to "چت به سرور",
        "cChatCommand" to "دستور (/) به سرور"
    )
    fun valueOf(m: McVersion, k: String) = when (k) {
        "sKeepAlive" -> m.sKeepAlive; "sDisconnect" -> m.sDisconnect; "sPosLook" -> m.sPosLook
        "sSystemChat" -> m.sSystemChat; "cKeepAlive" -> m.cKeepAlive; "cPosition" -> m.cPosition
        "cChat" -> m.cChat; else -> m.cChatCommand
    }
    val texts = remember { mutableStateMapOf<String, String>().apply { fields.forEach { (k, _) -> put(k, "%02X".format(maxOf(valueOf(v, k), 0))) } } }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("شناسه‌ی پکت‌ها (هگز)", fontSize = 16.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("عددها هگز هستند (مثلاً 2B). مقدار درست را از minecraft.wiki بخش Java Edition protocol یا از هشدار کنسول بردار.", color = Muted, fontSize = 11.sp)
                fields.forEach { (k, title) ->
                    if (valueOf(base, k) >= 0) {
                        OutlinedTextField(
                            value = texts[k] ?: "", onValueChange = { t -> texts[k] = t.filter { it.isLetterOrDigit() }.take(3).uppercase() },
                            label = { Text(title, fontSize = 12.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val o = mutableMapOf<String, Int>()
                fields.forEach { (k, _) ->
                    val n = texts[k]?.toIntOrNull(16)
                    if (n != null && valueOf(base, k) >= 0 && n != valueOf(base, k)) o[k] = n
                }
                store.saveIdOverrides(base.label, o)
                onSaved()
            }) { Text("ذخیره", color = Mint) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { store.saveIdOverrides(base.label, emptyMap()); onSaved() }) { Text("بازنشانی", color = Muted) }
                TextButton(onClick = onDismiss) { Text("بستن", color = Muted) }
            }
        }
    )
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Mint)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun LogLine(tag: String, message: String, color: Color) {
    Row(verticalAlignment = Alignment.Top) {
        Text(tag, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(58.dp))
        Text(message, color = Muted, fontSize = 12.sp)
    }
}


/** Performs the Minecraft Java Server List Ping (status) exchange. */
private object MinecraftStatusClient {
    fun query(host: String, port: Int): String {
        val started = System.nanoTime()
        Socket().use { socket ->
            socket.tcpNoDelay = true
            socket.soTimeout = 7000
            socket.connect(InetSocketAddress(host, port), 5000)
            val output = DataOutputStream(socket.getOutputStream())
            val input = DataInputStream(socket.getInputStream())

            val hostBytes = host.toByteArray(StandardCharsets.UTF_8)
            val handshake = java.io.ByteArrayOutputStream().also { bytes ->
                val packet = DataOutputStream(bytes)
                writeVarInt(packet, 0) // handshake packet id
                writeVarInt(packet, -1) // status-only protocol version
                writeVarInt(packet, hostBytes.size)
                packet.write(hostBytes)
                packet.writeShort(port)
                writeVarInt(packet, 1) // next state: status
            }.toByteArray()
            writeVarInt(output, handshake.size)
            output.write(handshake)

            writeVarInt(output, 1) // status request packet length
            writeVarInt(output, 0) // status request packet id
            output.flush()

            val packetLength = readVarInt(input)
            require(packetLength in 1..1_048_576) { "پاسخ سرور نامعتبر است" }
            val packetId = readVarInt(input)
            require(packetId == 0) { "پاسخ وضعیت شناخته نشد" }
            val jsonLength = readVarInt(input)
            require(jsonLength in 1..1_000_000) { "داده وضعیت نامعتبر است" }
            val jsonBytes = ByteArray(jsonLength)
            input.readFully(jsonBytes)
            val elapsedMs = (System.nanoTime() - started) / 1_000_000

            val root = JSONObject(String(jsonBytes, StandardCharsets.UTF_8))
            val version = root.optJSONObject("version")?.optString("name", "نامشخص") ?: "نامشخص"
            val players = root.optJSONObject("players")
            val online = players?.optInt("online", -1) ?: -1
            val max = players?.optInt("max", -1) ?: -1
            val playerText = if (online >= 0 && max >= 0) "$online / $max" else "نامشخص"
            return "سرور پاسخ داد ✓\nنسخه: $version\nبازیکنان: $playerText\nزمان پاسخ: ${elapsedMs}ms"
        }
    }

    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while ((v and -128) != 0) {
            out.writeByte((v and 127) or 128)
            v = v ushr 7
        }
        out.writeByte(v)
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0
        var position = 0
        while (true) {
            val current = input.readUnsignedByte()
            result = result or ((current and 127) shl position)
            if ((current and 128) == 0) return result
            position += 7
            require(position < 35) { "VarInt نامعتبر است" }
        }
    }
}


private fun normalizeDigits(s: String): String = buildString {
    for (c in s) append(when (c) {
        in '۰'..'۹' -> '0' + (c - '۰')
        in '٠'..'٩' -> '0' + (c - '٠')
        '،' -> ','
        '−' -> '-'
        else -> c
    })
}

private val greetWords = setOf("سلام", "درود", "سلام به همه", "hi", "hello", "hey", "خداحافظ", "بای", "bye", "مرسی", "ممنون")

private fun compassVector(t: String): DoubleArray? = when {
    t.contains("شمال") || t.contains("north") -> doubleArrayOf(0.0, -1.0)
    t.contains("جنوب") || t.contains("south") -> doubleArrayOf(0.0, 1.0)
    t.contains("شرق") || t.contains("east") -> doubleArrayOf(1.0, 0.0)
    t.contains("غرب") || t.contains("west") -> doubleArrayOf(-1.0, 0.0)
    else -> null
}

/** دستورهای فارسی/انگلیسی را مرحله‌به‌مرحله روی بات اجرا می‌کند. */
private suspend fun executeCommands(bot: McBotSession, raw: String): String {
    val text = normalizeDigits(raw.trim())
    val steps = text.split(Regex("\\s*(?:\\n|;|؛|\\||سپس|بعد از آن|بعدش|\\s+و\\s+(?=منتظر|صبر|بگو|بنویس|برو|حرکت|قطع))\\s*"))
        .map { it.trim() }
        .filter { it.isNotBlank() }
    if (steps.isEmpty()) return "دستور خالی است."
    val report = StringBuilder()
    for (original in steps) {
        if (!bot.connected) { report.appendLine("اتصال قطع است."); break }
        // پیشوندهای محاوره‌ای مثل «بهش بگو …» یا «لطفاً …» حذف می‌شود
        var step = original.replace(Regex("^(?:لطفاً?|please|بات|به بات|بهش|بهش بگو که|به او)\\s+"), "").trim()
        if (step.startsWith("بگو که ")) step = "بگو " + step.removePrefix("بگو که ")
        val lower = step.lowercase()
        val nums = Regex("-?\\d+(?:\\.\\d+)?").findAll(step).mapNotNull { it.value.toDoubleOrNull() }.toList()
        val plain = lower.trim().trim('!', '.', '،', '؟', '?', '…', ' ')
        val sayVerb = Regex("^(?:بگو|بنویس|چت|say|chat)(?:\\s+|$)").find(lower)
        val sayAfter = Regex("^(.+?)\\s+(?:رو|را)\\s+(?:بگو|بنویس)$").find(step)
        when {
            lower.startsWith("/") -> { if (bot.sendChat(step)) report.appendLine("✓ دستور به سرور ارسال شد: $step") else report.appendLine("✗ دستور ارسال نشد: $step") }
            sayVerb != null || sayAfter != null || plain in greetWords -> {
                val msg = when {
                    sayVerb != null -> step.substring(sayVerb.value.length).trim().trim('"', '«', '»', '“', '”')
                    sayAfter != null -> sayAfter.groupValues[1].trim().trim('"', '«', '»', '“', '”')
                    else -> step.trim()
                }
                if (msg.isEmpty()) report.appendLine("✗ متن پیام مشخص نیست.")
                else { if (bot.sendChat(msg)) report.appendLine("✓ پیام ارسال شد: $msg") else report.appendLine("✗ پیام ارسال نشد: $msg") }
            }
            lower.contains("منتظر") || lower.contains("صبر") || lower.contains("wait") -> {
                val sec = (nums.firstOrNull() ?: 5.0).coerceIn(0.0, 600.0)
                delay((sec * 1000).toLong())
                report.appendLine("✓ ${sec.toInt()} ثانیه صبر کردم.")
            }
            lower.contains("قطع") || lower.contains("disconnect") || lower.contains("خروج") -> {
                bot.stop(); report.appendLine("✓ قطع شد."); break
            }
            lower.contains("وضعیت") || lower.contains("کجا") || lower.contains("status") ->
                report.appendLine("موقعیت: %.1f, %.1f, %.1f".format(bot.x, bot.y, bot.z))
            lower.contains("بایست") || lower.contains("وایسا") || lower.contains("stop") -> {
                bot.moveX = 0.0; bot.moveZ = 0.0
                report.appendLine("✓ ایستادم.")
            }
            lower.contains("برو") || lower.contains("حرکت") || lower.contains("goto") || lower.contains("go ") ||
                lower.contains("walk") || lower.contains("مختصات") || lower.contains("بیا") -> {
                val dir = compassVector(lower)
                when {
                    nums.size >= 3 -> {
                        bot.walkTo(nums[0], nums[1], nums[2])
                        report.appendLine("✓ حرکت: ${nums[0]}, ${nums[1]}, ${nums[2]} (الان %.1f, %.1f, %.1f)".format(bot.x, bot.y, bot.z))
                    }
                    nums.size == 2 && dir == null -> {
                        bot.walkTo(nums[0], bot.y, nums[1])
                        report.appendLine("✓ حرکت به X=${nums[0]} Z=${nums[1]} (الان %.1f, %.1f, %.1f)".format(bot.x, bot.y, bot.z))
                    }
                    dir != null -> {
                        val n = (nums.firstOrNull() ?: 5.0).coerceIn(1.0, 500.0)
                        bot.walkTo(bot.x + dir[0] * n, bot.y, bot.z + dir[1] * n)
                        report.appendLine("✓ ${n.toInt()} بلاک حرکت کردم (الان %.1f, %.1f, %.1f)".format(bot.x, bot.y, bot.z))
                    }
                    else -> report.appendLine("✗ مقصد مشخص نیست: «$original»\n   مثال: برو به مختصات 250 40 120  یا  برو شمال 10")
                }
            }
            else -> report.appendLine("✗ نفهمیدم: $original\n   (می‌فهمم: بگو ... ، سلام ، برو به مختصات X Y Z ، برو شمال/جنوب/شرق/غرب N ، منتظر N ثانیه ، /دستور ، وضعیت ، قطع)")
        }
    }
    return report.toString().trim()
}
