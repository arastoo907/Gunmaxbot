package com.gunmax.bot

import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.zip.Deflater
import java.util.zip.Inflater
import kotlin.math.min
import kotlin.math.sqrt

enum class AuthMode { NONE, LOGIN, REGISTER }

/**
 * شناسه پکت‌ها برای هر نسخه. مقدار -1 یعنی «ناشناخته / استفاده نمی‌شود».
 * همه‌ی شناسه‌ها با داده‌ی مرجع PrismarineJS/minecraft-data (protocol.json) تطبیق داده شده‌اند.
 */
data class McVersion(
    val label: String,
    val protocol: Int,
    val sKeepAlive: Int,
    val sDisconnect: Int,
    val sPosLook: Int,
    val sSystemChat: Int,
    val cTeleportConfirm: Int,
    val cChat: Int,
    val cChatCommand: Int,
    val cKeepAlive: Int,
    val cPosition: Int,
    val cSettings: Int,          // Client Information (مرحله‌ی Play)
    val cPluginMessage: Int,     // Plugin Message (brand) در مرحله‌ی Play
    val sResourcePack: Int,      // درخواست ریسورس‌پک در Play
    val cResourcePack: Int,      // پاسخ ریسورس‌پک در Play
    val cPlayerLoaded: Int = -1  // 1.21.5+: «دنیا لود شد»
) {
    val keepAliveIsVarInt get() = protocol < 340
    val hasConfigState get() = protocol >= 764
    val signedChatFormat get() = protocol >= 762
    val chatChecksum get() = protocol >= 770          // 1.21.5+: بایت checksum آخر پکت چت
    val chatCommandUnsigned get() = protocol >= 766   // از 1.20.5 دستور بدون امضا پکت جدا دارد
    val posNewFormat get() = protocol >= 768          // 1.21.2+: teleportId اول، سرعت و flags از نوع Int
    val nbtText get() = protocol >= 765               // 1.20.3+: متن‌ها NBT هستند نه JSON
    val resourcePackHasUuid get() = protocol >= 765   // 1.20.3+: ریسورس‌پک با UUID
    val maxChat get() = if (protocol < 107) 100 else 256

    // شناسه‌ی پکت‌های مرحله‌ی Configuration (هر دو جهت عدد یکسان دارند)
    val cfgDisconnect get() = if (protocol >= 766) 0x02 else 0x01
    val cfgFinish get() = if (protocol >= 766) 0x03 else 0x02
    val cfgKeepAlive get() = if (protocol >= 766) 0x04 else 0x03
    val cfgPing get() = if (protocol >= 766) 0x05 else 0x04
    val cfgPluginMessageOut get() = if (protocol >= 766) 0x02 else 0x01
    val cfgResourcePackIn get() = if (protocol >= 766) 0x09 else 0x07
    val cfgResourcePackOut get() = if (protocol >= 766) 0x06 else 0x05

    companion object {
        val ALL = listOf(
            McVersion("1.8.9", 47, 0x00, 0x40, 0x08, 0x02, -1, 0x01, -1, 0x00, 0x04, 0x15, 0x17, 0x48, 0x19),
            McVersion("1.12.2", 340, 0x1F, 0x1A, 0x2F, 0x0F, 0x00, 0x02, -1, 0x0B, 0x0D, 0x04, 0x09, 0x34, 0x18),
            McVersion("1.16.5", 754, 0x1F, 0x19, 0x34, 0x0E, 0x00, 0x03, -1, 0x10, 0x12, 0x05, 0x0B, 0x38, 0x21),
            McVersion("1.18.2", 758, 0x21, 0x1A, 0x38, 0x0F, 0x00, 0x03, -1, 0x0F, 0x11, 0x05, 0x0A, 0x3C, 0x21),
            McVersion("1.19.4", 762, 0x23, 0x1A, 0x3C, 0x64, 0x00, 0x05, 0x04, 0x12, 0x14, 0x08, 0x0D, 0x40, 0x24),
            McVersion("1.20.1", 763, 0x23, 0x1A, 0x3C, 0x64, 0x00, 0x05, 0x04, 0x12, 0x14, 0x08, 0x0D, 0x40, 0x24),
            McVersion("1.20.4", 765, 0x24, 0x1B, 0x3E, 0x69, 0x00, 0x05, 0x04, 0x15, 0x17, 0x09, 0x10, 0x44, 0x28),
            McVersion("1.21.11", 774, 0x2B, 0x20, 0x46, 0x77, 0x00, 0x08, 0x06, 0x1B, 0x1D, 0x0D, 0x15, 0x4F, 0x30, 0x2B)
        )

        /** برچسب‌های قدیمی مثل «1.21.11 (آزمایشی)» را به برچسب جدید تبدیل می‌کند. */
        fun normalize(label: String): String {
            val clean = label.substringBefore(" (").trim()
            return ALL.firstOrNull { it.label == clean }?.label ?: "1.20.1"
        }

        /** نسخه را با شناسه‌هایی که کاربر دستی تغییر داده ترکیب می‌کند. */
        fun resolve(label: String, store: AppStore?): McVersion {
            val base = ALL.first { it.label == normalize(label) }
            val o = store?.idOverrides(base.label) ?: return base
            return base.copy(
                sKeepAlive = o["sKeepAlive"] ?: base.sKeepAlive,
                sDisconnect = o["sDisconnect"] ?: base.sDisconnect,
                sPosLook = o["sPosLook"] ?: base.sPosLook,
                sSystemChat = o["sSystemChat"] ?: base.sSystemChat,
                cChat = o["cChat"] ?: base.cChat,
                cChatCommand = o["cChatCommand"] ?: base.cChatCommand,
                cKeepAlive = o["cKeepAlive"] ?: base.cKeepAlive,
                cPosition = o["cPosition"] ?: base.cPosition
            )
        }
    }
}

private enum class State { LOGIN, CONFIG, PLAY }

/**
 * یک اتصال بات به سرور Minecraft Java در حالت آفلاین (crack).
 * فقط برای سرورهای خودت یا سرورهایی که صراحتاً اجازه‌ی بات می‌دهند.
 *
 * authMode: NONE = هیچ دستوری نمی‌زند، LOGIN = فقط /login، REGISTER = فقط /register.
 * brand: اسم کلاینت که به سرور اعلام می‌شود (vanilla / fabric / forge ...).
 */
class McBotSession(
    private val host: String,
    private val port: Int,
    private val version: McVersion,
    private val username: String,
    private val authPassword: String = "",
    private val authMode: AuthMode = AuthMode.NONE,
    private val loginTemplate: String = "/login {pass}",
    private val registerTemplate: String = "/register {pass} {pass}",
    private val brand: String = "vanilla",
    private val log: (String) -> Unit
) {
    /** هر پیام چت/سیستم سرور (متن ساده) را به برنامه می‌دهد؛ تب «فروشگاه» از آن برای شمردن فروش استفاده می‌کند. */
    @Volatile var chatListener: ((String) -> Unit)? = null

    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: DataOutputStream? = null
    private val writeLock = Any()

    @Volatile private var state = State.LOGIN
    @Volatile private var compression = -1
    @Volatile var connected = false
        private set
    @Volatile var spawned = false
        private set
    @Volatile var x = 0.0
        private set
    @Volatile var y = 0.0
        private set
    @Volatile var z = 0.0
        private set
    /** تعداد دفعاتی که سرور بات را به موقعیت قبلی برگردانده (یعنی حرکت را قبول نکرده). */
    @Volatile var rubberBands = 0
        private set

    // ---- دنیا (چانک‌ها) برای نمایش نقشه‌ی واقعی و راه‌رفتن روی زمین ----
    /** چانک‌هایی که سرور فرستاده؛ null یعنی جدول بلاک این نسخه در برنامه نیست. */
    val world: WorldMap? = BlockTables.forVersion(version.label)?.let { WorldMap(version.protocol, it) }
    /** اگر روشن باشد و چانک لود شده باشد، بات روی زمین راه می‌رود (پله، سقوط، برخورد با دیوار). */
    @Volatile var worldPhysics = true

    // ---- کنترل دستی (جوی‌استیک) و ردّ مسیر برای نمایش زنده ----
    /** جهت جوی‌استیک: moveX مثبت = شرق (x+)، moveZ مثبت = جنوب (z+). بین -1 و 1. */
    @Volatile var moveX = 0.0
    @Volatile var moveZ = 0.0
    private val trailList = ArrayList<DoubleArray>()
    fun trailSnapshot(): List<DoubleArray> = synchronized(trailList) { ArrayList(trailList) }
    private fun addTrail() {
        synchronized(trailList) {
            val last = trailList.lastOrNull()
            if (last == null || (x - last[0]) * (x - last[0]) + (z - last[1]) * (z - last[1]) > 0.09) {
                trailList.add(doubleArrayOf(x, z))
                if (trailList.size > 500) trailList.removeAt(0)
            }
        }
    }
    @Volatile private var walking = false
    @Volatile private var blockedTicks = 0
    @Volatile private var keepAliveSeen = false
    @Volatile private var keepAliveHinted = false
    @Volatile private var connectedAt = System.currentTimeMillis()

    // وضعیت لاگین/ریجستر خودکار
    private val authLock = Any()
    @Volatile private var authDone = false
    @Volatile private var authAttempts = 0
    @Volatile private var lastAuthSend = 0L
    @Volatile private var authHintShown = false

    /** اتصال و ورود. روی thread پس‌زمینه صدا بزنید. */
    fun connect() {
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 8000)
        s.soTimeout = 60000
        socket = s
        input = s.getInputStream()
        output = DataOutputStream(s.getOutputStream())

        // Handshake
        sendRaw(0x00) {
            writeVarInt(it, version.protocol)
            writeString(it, host)
            it.writeShort(port)
            writeVarInt(it, 2)
        }
        // Login Start
        val uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$username".toByteArray(StandardCharsets.UTF_8))
        sendRaw(0x00) {
            writeString(it, username)
            if (version.protocol >= 764) {
                writeUuid(it, uuid)
            } else if (version.protocol >= 762) {
                it.writeBoolean(true)
                writeUuid(it, uuid)
            }
        }
        connected = true
        connectedAt = System.currentTimeMillis()
        log("درخواست ورود با نام «$username» روی نسخه ${version.label} ارسال شد...")
        Thread({ readLoop() }, "mc-reader").apply { isDaemon = true }.start()
    }

    /** قطع‌کردنِ دستیِ کاربر؛ اتو ری‌کانکت بعد از این دوباره وصل نمی‌شود. */
    @Volatile var manualStop = false
        private set

    fun stop() {
        manualStop = true
        disconnect()
    }

    fun disconnect() {
        connected = false
        try { socket?.close() } catch (_: Exception) {}
    }

    fun sendChat(text: String): Boolean {
        if (!connected || !spawned) { log("هنوز وارد بازی نشده‌ام یا اتصال قطع است؛ پیام فرستاده نشد."); return false }
        val msg = text.take(version.maxChat)
        var ok: Boolean
        if (msg.startsWith("/") && version.cChatCommand >= 0) {
            if (version.chatCommandUnsigned) {
                // 1.20.5+: دستور بدون آرگومان امضاشونده فقط خود رشته است
                ok = sendRaw(version.cChatCommand) { writeString(it, msg.removePrefix("/")) }
            } else {
                ok = sendRaw(version.cChatCommand) {
                    writeString(it, msg.removePrefix("/"))
                    it.writeLong(System.currentTimeMillis())
                    it.writeLong(0L)
                    writeVarInt(it, 0)       // argument signatures
                    writeVarInt(it, 0)       // message count
                    it.write(ByteArray(3))   // acknowledged bitset (20 bits)
                }
            }
        } else if (version.signedChatFormat) {
            ok = sendRaw(version.cChat) {
                writeString(it, msg)
                it.writeLong(System.currentTimeMillis())
                it.writeLong(0L)
                it.writeBoolean(false)   // no signature
                writeVarInt(it, 0)
                it.write(ByteArray(3))
                if (version.chatChecksum) it.writeByte(0)   // 1.21.5+: بدون checksum
            }
        } else {
            ok = sendRaw(version.cChat) { writeString(it, msg) }
        }
        val shown = if (authPassword.isNotEmpty()) msg.replace(authPassword, "••••") else msg
        if (ok) log("پیام به سرور ارسال شد: $shown") else log("✗ ارسال پیام ناموفق بود: $shown")
        return ok
    }

    /**
     * لاگین / ریجستر خودکار برای سرورهای کرک (AuthMe و مشابه).
     * LOGIN فقط /login می‌زند و REGISTER فقط /register؛ هیچ‌وقت هر دو با هم نیستند.
     * دستور فقط یک بار کورکورانه فرستاده نمی‌شود: بات به پیام‌های خود سرور گوش می‌دهد
     * (watchAuth) و هر وقت سرور دوباره درخواست کرد یا تأیید نکرد، با فاصله تکرار می‌کند؛
     * در ریجستر فرمت دورمزی (/register رمز رمز) و تک‌رمزی (/register رمز) را جابه‌جا امتحان می‌کند.
     */
    private fun autoAuth() {
        if (authMode == AuthMode.NONE) return
        try {
            // مثل آدم واقعی: بعد از ورود چند ثانیه هیچ کاری نمی‌کند و فقط منتظر می‌ماند
            Thread.sleep(4000)
            if (!connected) return
            // اگر تا ۱۰ ثانیه سرور خودش لاگین/ریجستر نخواست (watchAuth)، فقط یک‌بار می‌فرستیم و دیگر تکرار نمی‌کنیم
            Thread.sleep(6000)
            if (!connected || authDone || authAttempts > 0) return
            sendAuth("سرور ساکت بود")
        } catch (_: InterruptedException) {}
    }

    private fun buildAuthCommand(variant: Int): String {
        var t = if (authMode == AuthMode.LOGIN) loginTemplate else registerTemplate
        if (authMode == AuthMode.REGISTER && variant == 1) {
            t = if (t.contains("{pass} {pass}")) t.replace("{pass} {pass}", "{pass}")
                else t.replace("{pass}", "{pass} {pass}")
        }
        return t.replace("{pass}", authPassword)
    }

    /** دستور لاگین/ریجستر را می‌فرستد؛ از چند thread امن است و فاصله‌ی حداقلی بین دو ارسال رعایت می‌شود. */
    private fun sendAuth(reason: String) {
        synchronized(authLock) {
            if (!connected || !spawned || authDone || authMode == AuthMode.NONE) return
            val now = System.currentTimeMillis()
            if (authAttempts > 0 && now - lastAuthSend < 15_000) return
            if (authAttempts >= 2) return
            val cmd = buildAuthCommand(authAttempts % 2)
            authAttempts++
            lastAuthSend = now
            log(if (authMode == AuthMode.LOGIN) "🔐 ارسال دستور لاگین ($reason) — تلاش $authAttempts" else "📝 ارسال دستور ریجستر ($reason) — تلاش $authAttempts")
            sendChat(cmd)
        }
    }

    private val successRegex = Regex("(?<!un)success")

    /** پیام‌های سرور را می‌خواند و بر اساسشان لاگین/ریجستر را ادامه می‌دهد یا متوقف می‌کند. */
    private fun watchAuth(text: String) {
        if (authMode == AuthMode.NONE || authDone || text.isBlank()) return
        val t = text.lowercase()
        val asksRegister = t.contains("/register") || t.contains("/reg ")
        val asksLogin = t.contains("/login") || t.contains("/l ")
        val wrongPass = t.contains("wrong password") || t.contains("incorrect password") ||
            t.contains("رمز اشتباه") || t.contains("رمز عبور اشتباه") || t.contains("رمز نادرست")
        val alreadyRegistered = t.contains("already registered") || t.contains("already exist") ||
            t.contains("قبلا ثبت") || t.contains("قبلاً ثبت")
        val success = !asksRegister && !asksLogin && (successRegex.containsMatchIn(t) ||
            t.contains("already logged") || t.contains("با موفقیت"))
        // سرور می‌گوید چنین دستوری وجود ندارد (مثلاً اکانت خودکار وارد شده یا سیستم لاگین چیز دیگری است)
        val unknownCmd = t.contains("vojood nadarad") || t.contains("vojud nadarad") ||
            t.contains("unknown command") || t.contains("not a valid command") ||
            t.contains("دستور مورد نظر وجود ندارد") || t.contains("دستور وجود ندارد")
        // سرور تا وقتی چند بلاک از اسپاون دور نشوی چت و دستور را قبول نمی‌کند
        val nearSpawn = t.contains("block az spawn") || t.contains("away from spawn") ||
            t.contains("از اسپاون دور")
        when {
            unknownCmd -> {
                authDone = true
                log("ℹ️ سرور می‌گوید دستور /${if (authMode == AuthMode.LOGIN) "login" else "register"} وجود ندارد؛ شاید اکانت از قبل وارد شده. ارسال خودکار متوقف شد (جلوی اسپم گرفته شد).")
            }
            nearSpawn -> {
                authDone = true
                log("⚠️ سرور تا وقتی از اسپاون دور نشوی چت/دستور را قبول نمی‌کند. ارسال خودکار متوقف شد؛ با جوی‌استیک (تب بازی) چند بلاک دور شو و بعد دوباره لاگین/ریجستر را بزن.")
            }
            wrongPass && authMode == AuthMode.LOGIN -> {
                authDone = true
                log("✗ سرور می‌گوید رمز اشتباه است. رمز بات را در تنظیمات درست کن (تکرار متوقف شد تا بات بن/کیک نشود).")
            }
            alreadyRegistered && authMode == AuthMode.REGISTER -> {
                authDone = true
                log("ℹ️ این اکانت قبلاً ثبت شده. از دکمه‌ی «ورود (لاگین)» استفاده کن.")
            }
            success -> {
                authDone = true
                log(if (authMode == AuthMode.LOGIN) "✅ سرور لاگین را تأیید کرد." else "✅ سرور ثبت‌نام را تأیید کرد.")
            }
            authMode == AuthMode.LOGIN && asksLogin -> sendAuth("درخواست سرور")
            authMode == AuthMode.REGISTER && asksRegister -> sendAuth("درخواست سرور")
            authMode == AuthMode.LOGIN && asksRegister -> if (!authHintShown) {
                authHintShown = true
                log("⚠️ سرور /register می‌خواهد؛ یعنی این نام هنوز ثبت نشده. دکمه‌ی «ثبت‌نام (ریجستر)» را بزن.")
            }
            authMode == AuthMode.REGISTER && asksLogin -> {
                authDone = true
                log("⚠️ سرور /login می‌خواهد؛ یعنی اکانت از قبل ثبت شده (یا ثبت‌نام همین الان انجام شد). با «ورود (لاگین)» وارد شو.")
            }
        }
    }

    /** حرکت خط مستقیم با سرعت پیاده‌روی (بدون مسیریابی و بدون برخورد). */
    suspend fun walkTo(tx: Double, ty: Double, tz: Double) {
        if (!spawned) { log("هنوز وارد بازی نشده‌ام."); return }
        log("حرکت به سمت %.1f, %.1f, %.1f".format(tx, ty, tz))
        rubberBands = 0
        walking = true
        try {
            val deadline = System.currentTimeMillis() + 180_000
            while (connected && System.currentTimeMillis() < deadline) {
                val dx = tx - x
                val dy = ty - y
                val dz = tz - z
                val dist = sqrt(dx * dx + dy * dy + dz * dz)
                if (dist < 0.25) break
                if (rubberBands > 8) {
                    log("سرور مدام موقعیت را برگرداند (مانع یا محدودیت). حرکت متوقف شد.")
                    return
                }
                val step = min(0.2, dist)
                x += dx / dist * step
                y += dy / dist * step
                z += dz / dist * step
                sendPosition()
                delay(50)
            }
        } finally {
            walking = false
        }
        log("رسیدم: %.1f, %.1f, %.1f".format(x, y, z))
    }

    private fun sendPosition() {
        addTrail()
        sendRaw(version.cPosition) {
            it.writeDouble(x)
            it.writeDouble(y)
            it.writeDouble(z)
            it.writeBoolean(true)
        }
    }

    /** حرکت دستی: هر ۵۰ میلی‌ثانیه (۲۰ بار در ثانیه) بر اساس جوی‌استیک موقعیت جدید می‌فرستد. */
    private fun manualLoop() {
        try {
            while (connected) {
                Thread.sleep(50)
                if (!spawned || walking) continue
                val mx = moveX
                val mz = moveZ
                val m = sqrt(mx * mx + mz * mz)
                if (m < 0.08) continue
                val k = if (m > 1.0) 1.0 / m else 1.0
                val dx = mx * k * 0.2      // ≈ سرعت پیاده‌روی (۴ بلاک بر ثانیه)
                val dz = mz * k * 0.2
                val w = world
                if (w != null && worldPhysics && w.isLoaded(x, z)) {
                    if (!physicsMove(w, dx, dz)) {
                        blockedTicks++
                        if (blockedTicks == 20 || blockedTicks % 200 == 0) {
                            log("⚠️ بات جلوی بلاک جامد/لبه گیر کرده و حرکت نمی‌کند (فاصله از زمین: y=%.1f). اگر فکر می‌کنی راه آزاد است، در تب «بازی» گزینه‌ی «روی زمین» را خاموش کن.".format(y))
                        }
                    } else blockedTicks = 0
                } else {
                    x += dx
                    z += dz
                }
                sendPosition()
            }
        } catch (_: InterruptedException) {}
        moveX = 0.0; moveZ = 0.0
    }

    private fun canStand(w: WorldMap, px: Double, pz: Double, feetY: Int): Boolean {
        val bx = Math.floor(px).toInt()
        val bz = Math.floor(pz).toInt()
        return !w.solidAt(bx, feetY, bz) && !w.solidAt(bx, feetY + 1, bz)
    }

    /**
     * حرکت روی زمین واقعی: جلوی دیوار می‌ایستد (یا روی آن سر می‌خورد)، یک بلاک پله را بالا می‌رود
     * و اگر زمین پایین‌تر باشد پایین می‌آید. ارتفاع به‌تدریج عوض می‌شود تا سرور «حرکت غیرعادی» نبیند.
     */
    private fun physicsMove(w: WorldMap, dx: Double, dz: Double): Boolean {
        val feet = Math.floor(y + 0.001).toInt()
        val tries = arrayOf(doubleArrayOf(dx, dz), doubleArrayOf(dx, 0.0), doubleArrayOf(0.0, dz))
        for (t in tries) {
            if (t[0] == 0.0 && t[1] == 0.0) continue
            val nx = x + t[0]
            val nz = z + t[1]
            val px = nx + Math.signum(t[0]) * 0.3
            val pz = nz + Math.signum(t[1]) * 0.3
            if (!w.isLoaded(px, pz)) continue
            var fy = Int.MIN_VALUE
            if (canStand(w, px, pz, feet)) fy = feet
            else if (canStand(w, px, pz, feet + 1) &&
                !w.solidAt(Math.floor(x).toInt(), feet + 2, Math.floor(z).toInt())) fy = feet + 1
            if (fy == Int.MIN_VALUE) continue
            val bx = Math.floor(nx).toInt()
            val bz = Math.floor(nz).toInt()
            var gy = fy
            var n = 0
            while (n < 64 && !w.solidAt(bx, gy - 1, bz)) { gy--; n++ }
            if (n >= 64) gy = fy          // زمینی پیدا نشد (خلأ یا چانک ناقص): ارتفاع را نگه دار
            x = nx
            z = nz
            val target = gy.toDouble()
            y = if (y > target) Math.max(target, y - 0.5) else Math.min(target, y + 0.3)
            return true
        }
        return false
    }

    /** مثل کلاینت واقعی هر ثانیه موقعیت می‌فرستد تا سرور بات را «بی‌حرکت/مرده» حساب نکند. */
    private fun heartbeat() {
        try {
            while (connected) {
                Thread.sleep(1000)
                if (spawned && !walking) sendPosition()
            }
        } catch (_: InterruptedException) {}
    }

    /**
     * مثل کلاینت واقعی: نام کلاینت (brand) و تنظیمات کلاینت (Client Information) را می‌فرستد.
     * از 1.20.2 در مرحله‌ی Configuration و قبل از آن بعد از ورود به دنیا (Play).
     * قبلاً برای نسخه‌های ≤1.20.1 هیچ‌کدام فرستاده نمی‌شد و پلاگین‌های ضدبات/احراز هویت بات را مشکوک می‌دیدند.
     */
    private fun sendClientInfo(inConfig: Boolean) {
        val v = version
        val pluginId = if (inConfig) v.cfgPluginMessageOut else v.cPluginMessage
        val settingsId = if (inConfig) 0x00 else v.cSettings
        if (pluginId >= 0) {
            val channel = if (v.protocol < 393) "MC|Brand" else "minecraft:brand"
            sendRaw(pluginId) {
                writeString(it, channel)
                writeString(it, brand)
            }
        }
        if (settingsId >= 0) {
            sendRaw(settingsId) {
                writeString(it, "en_us")
                it.writeByte(8)                                              // view distance
                if (v.protocol < 107) it.writeByte(0) else writeVarInt(it, 0) // chat: همه
                it.writeBoolean(true)                                        // chat colors
                it.writeByte(0x7F)                                           // skin parts
                if (v.protocol >= 107) writeVarInt(it, 1)                    // main hand: راست
                if (v.protocol >= 755) it.writeBoolean(false)                // text filtering
                if (v.protocol >= 757) it.writeBoolean(true)                 // server listing
                if (v.protocol >= 768) writeVarInt(it, 0)                    // particles: همه
            }
        }
        log("نام کلاینت اعلام شد: $brand")
    }

    /** ریسورس‌پک سرور را «قبول و بارگذاری‌شده» جواب می‌دهد تا سرور بات را به خاطر بی‌جوابی بیرون نیندازد. */
    private fun onResourcePack(p: DataInputStream, inConfig: Boolean) {
        val v = version
        val outId = if (inConfig) v.cfgResourcePackOut else v.cResourcePack
        if (outId < 0) return
        if (v.resourcePackHasUuid) {
            val hi = p.readLong(); val lo = p.readLong()
            for (r in intArrayOf(3, 4, 0)) {
                sendRaw(outId) { it.writeLong(hi); it.writeLong(lo); writeVarInt(it, r) }
            }
        } else {
            var hash = ""
            if (v.protocol < 107) { readString(p); hash = readString(p) }   // فقط 1.8 هش را در جواب می‌خواهد
            for (r in intArrayOf(3, 0)) {
                sendRaw(outId) { if (v.protocol < 107) writeString(it, hash); writeVarInt(it, r) }
            }
        }
        log("درخواست ریسورس‌پک سرور پذیرفته شد.")
    }

    // ---------------- خواندن ----------------

    private fun readLoop() {
        try {
            val din = DataInputStream(input)
            while (connected) {
                val length = readVarInt(din)
                if (length <= 0 || length > 4_000_000) throw IllegalStateException("طول پکت نامعتبر")
                val raw = ByteArray(length)
                din.readFully(raw)
                var body = raw
                if (compression >= 0) {
                    val bin = DataInputStream(ByteArrayInputStream(raw))
                    val dataLen = readVarInt(bin)
                    val rest = ByteArray(bin.available())
                    bin.readFully(rest)
                    body = if (dataLen == 0) rest else {
                        val inf = Inflater()
                        inf.setInput(rest)
                        val out = ByteArray(dataLen)
                        var off = 0
                        while (off < dataLen && !inf.finished()) {
                            val n = inf.inflate(out, off, dataLen - off)
                            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                            off += n
                        }
                        inf.end()
                        out
                    }
                }
                val p = DataInputStream(ByteArrayInputStream(body))
                val id = readVarInt(p)
                try {
                    handle(id, p, p.available())
                } catch (e: java.io.EOFException) {
                    // پکتی که فرمتش را نمی‌شناسیم؛ نادیده می‌گیریم تا اتصال نپرد
                }
            }
        } catch (e: Exception) {
            if (connected) log("اتصال قطع شد (${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"})")
        } finally {
            connected = false
            spawned = false
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    private fun handle(id: Int, p: DataInputStream, size: Int) {
        val v = version
        when (state) {
            State.LOGIN -> when (id) {
                0x00 -> { log("سرور رد کرد: ${chatText(readString(p))}"); disconnect() }
                0x01 -> {
                    log("این سرور آنلاین‌مود (اکانت اصلی) است. این نسخه فقط سرورهای آفلاین را پشتیبانی می‌کند.")
                    disconnect()
                }
                0x03 -> compression = readVarInt(p)
                0x04 -> {
                    // Login Plugin Request (مثلاً Fabric API): مثل کلاینت بدون مود جواب «نمی‌شناسم» می‌دهیم
                    val mid = readVarInt(p)
                    val channel = try { readString(p) } catch (_: Exception) { "?" }
                    sendRaw(0x02) { writeVarInt(it, mid); it.writeBoolean(false) }
                    log("پرس‌وجوی لاگینِ سرور ($channel) بدون پشتیبانی پاسخ داده شد.")
                }
                0x05 -> if (v.protocol >= 766) {
                    val ck = readString(p)
                    sendRaw(0x04) { writeString(it, ck); it.writeBoolean(false) }
                }
                0x02 -> {
                    if (v.hasConfigState) {
                        sendRaw(0x03) { }
                        state = State.CONFIG
                        sendClientInfo(true)
                    } else {
                        state = State.PLAY
                    }
                    log("ورود موفق ✓")
                }
            }
            State.CONFIG -> when {
                id == v.cfgDisconnect -> {
                    val reason = try { readComponent(p) } catch (_: Exception) { "" }
                    log("سرور در مرحله پیکربندی قطع کرد. ${if (reason.isNotBlank()) "دلیل: $reason" else ""}")
                    disconnect()
                }
                id == v.cfgFinish -> { sendRaw(v.cfgFinish) { }; state = State.PLAY }
                id == v.cfgKeepAlive -> { val k = p.readLong(); sendRaw(v.cfgKeepAlive) { it.writeLong(k) } }
                id == v.cfgPing -> { val k = p.readInt(); sendRaw(v.cfgPing) { it.writeInt(k) } }
                v.protocol >= 766 && id == 0x00 -> {
                    val ck = readString(p)
                    sendRaw(0x01) { writeString(it, ck); it.writeBoolean(false) }
                }
                v.protocol >= 766 && id == 0x0E -> {
                    // Select Known Packs: به سرور می‌گوییم هیچ پکی نداریم تا رجیستری کامل را بفرستد
                    sendRaw(0x07) { writeVarInt(it, 0) }
                }
                v.protocol >= 765 && id == v.cfgResourcePackIn -> onResourcePack(p, true)
                v.protocol >= 773 && id == 0x13 -> {
                    sendRaw(0x09) { } // Accept Code of Conduct
                    log("قوانین سرور (Code of Conduct) پذیرفته شد.")
                }
            }
            State.PLAY -> when {
                id == v.sKeepAlive -> {
                    keepAliveSeen = true
                    if (v.keepAliveIsVarInt) {
                        val k = readVarInt(p)
                        sendRaw(v.cKeepAlive) { writeVarInt(it, k) }
                    } else {
                        val k = p.readLong()
                        sendRaw(v.cKeepAlive) { it.writeLong(k) }
                    }
                }
                id == v.sDisconnect -> {
                    val reason = try { readComponent(p) } catch (_: Exception) { "" }
                    log("از سرور بیرون انداخته شدم. دلیل: ${if (reason.isNotBlank()) reason else "(سرور دلیلی ارسال نکرد)"}")
                    disconnect()
                }
                id == v.sPosLook -> onPosLook(p)
                v.sResourcePack >= 0 && id == v.sResourcePack -> onResourcePack(p, false)
                v.sSystemChat >= 0 && id == v.sSystemChat -> onChat(p)
                world != null && world.handlePacket(id, p) {
                    val ack = world.batchAckId
                    if (ack >= 0) sendRaw(ack) { it.writeFloat(10f) }   // 1.20.2+: بدون این جواب سرور چانک‌های بعدی را نمی‌فرستد
                } -> { }
                else -> {
                    if (v.protocol >= 762 && size in 30..4000 && tryPlayerChat(p, size)) return
                    if (!keepAliveSeen && !keepAliveHinted && size == 8 && v.protocol >= 764 && System.currentTimeMillis() - connectedAt > 25_000) {
                        keepAliveHinted = true
                        log("ℹ️ پکتی ۸ بایتی با شناسه 0x%02X دیدم (Keep-Alive تنظیم‌شده: 0x%02X). اگر بات بعد از ~۲۰ ثانیه Timed out شد، این عدد را در «ویرایش شناسه‌ها» بگذار.".format(id, v.sKeepAlive))
                    }
                }
            }
        }
    }

    private fun onPosLook(p: DataInputStream) {
        val v = version
        if (v.posNewFormat) {
            val tid = readVarInt(p)
            val nx = p.readDouble(); val ny = p.readDouble(); val nz = p.readDouble()
            p.readDouble(); p.readDouble(); p.readDouble()   // delta movement
            p.readFloat(); p.readFloat()
            val flags = p.readInt()
            x = if (flags and 1 != 0) x + nx else nx
            y = if (flags and 2 != 0) y + ny else ny
            z = if (flags and 4 != 0) z + nz else nz
            sendRaw(v.cTeleportConfirm) { writeVarInt(it, tid) }
        } else {
            val nx = p.readDouble(); val ny = p.readDouble(); val nz = p.readDouble()
            p.readFloat(); p.readFloat()
            val flags = p.readUnsignedByte()
            x = if (flags and 1 != 0) x + nx else nx
            y = if (flags and 2 != 0) y + ny else ny
            z = if (flags and 4 != 0) z + nz else nz
            if (v.cTeleportConfirm >= 0) {
                val tid = readVarInt(p)
                sendRaw(v.cTeleportConfirm) { writeVarInt(it, tid) }
            }
        }
        sendPosition()
        if (!spawned) {
            spawned = true
            log("وارد دنیا شدم. موقعیت: %.1f, %.1f, %.1f".format(x, y, z))
            if (!v.hasConfigState) sendClientInfo(false)          // قبل از 1.20.2: brand و تنظیمات کلاینت در Play
            if (v.cPlayerLoaded >= 0) sendRaw(v.cPlayerLoaded) { } // 1.21.5+: «دنیا برای کلاینت لود شد»
            Thread({ heartbeat() }, "mc-beat").apply { isDaemon = true }.start()
            Thread({ manualLoop() }, "mc-manual").apply { isDaemon = true }.start()
            if (authMode != AuthMode.NONE) {
                Thread({ autoAuth() }, "mc-auth").apply { isDaemon = true }.start()
            }
        } else {
            rubberBands++
            if (rubberBands == 1 || rubberBands == 5 || rubberBands % 25 == 0) {
                log("⚠️ سرور بات را به جای قبلی برگرداند (بار $rubberBands): %.1f, %.1f, %.1f. معمولاً یعنی هنوز لاگین/ریجستر نشده‌ای (AuthMe اجازه‌ی حرکت نمی‌دهد)، یا سرور حرکت را غیرمجاز می‌داند.".format(x, y, z))
            }
        }
    }


    /**
     * چت بازیکنان (Player Chat / Disguised Chat) در 1.19.3+ شناسه‌ی نسخه‌به‌نسخه دارد؛ برای همین پکت‌های ناشناخته را
     * با چند قالب امتحان می‌کنیم و فقط اگر قالب دقیقاً تا آخرین بایت جور شد (و متن چاپ‌شدنی بود) در کنسول نشان می‌دهیم.
     */
    private fun tryPlayerChat(p: DataInputStream, size: Int): Boolean {
        val bytes = try { ByteArray(p.available()).also { p.readFully(it) } } catch (_: Exception) { return false }
        if (bytes.size != size) return false
        fun printable(t: String) = t.isNotBlank() && t.none { it.code < 32 && it != '\n' }
        // قالب ۱: Player Chat (با/بدون globalIndex)
        for (withGlobal in booleanArrayOf(true, false)) {
            try {
                val d = DataInputStream(ByteArrayInputStream(bytes))
                if (withGlobal) readVarInt(d)
                d.skipBytes(16)                      // sender uuid
                readVarInt(d)                        // index
                if (d.readBoolean()) d.skipBytes(256)
                val msg = readString(d)
                d.readLong(); d.readLong()
                val n = readVarInt(d)
                if (n !in 0..30) continue
                repeat(n) { if (readVarInt(d) == 0) d.skipBytes(256) }
                var shown = msg
                if (d.readBoolean()) { val u = readComponent(d); if (u.isNotBlank()) shown = u }
                val ft = readVarInt(d)
                if (ft == 2) { val l = readVarInt(d); d.skipBytes(l * 8) }
                else if (ft !in 0..2) continue
                readVarInt(d)                        // chat type
                val name = readComponent(d)
                if (d.readBoolean()) readComponent(d)
                if (d.available() == 0 && printable(shown) && printable(name)) {
                    log("💬 <$name> $shown"); return true
                }
            } catch (_: Exception) {}
        }
        // قالب ۲: Disguised Chat (پیام سرور با نام فرستنده)
        try {
            val d = DataInputStream(ByteArrayInputStream(bytes))
            val msg = readComponent(d)
            readVarInt(d)
            val name = readComponent(d)
            if (d.readBoolean()) readComponent(d)
            if (d.available() == 0 && printable(msg) && printable(name)) {
                log("💬 <$name> $msg"); chatListener?.invoke(msg); return true
            }
        } catch (_: Exception) {}
        return false
    }

    /** پیام‌های سرور (مثل جواب AuthMe) را در کنسول نشان می‌دهد تا بدانی چرا لاگین نشده. */
    private fun onChat(p: DataInputStream) {
        val v = version
        val text: String
        if (v.protocol >= 762) {
            text = readComponent(p)
            val overlay = try { p.readBoolean() } catch (_: Exception) { false }
            watchAuth(text)
            if (overlay) return
        } else {
            text = chatText(readString(p))
            val pos = try { p.readByte().toInt() } catch (_: Exception) { 0 }
            watchAuth(text)
            if (pos == 2) return
        }
        if (text.isNotBlank()) { log("💬 سرور: $text"); chatListener?.invoke(text) }
    }

    // ---------------- نوشتن ----------------

    private fun sendRaw(id: Int, build: (DataOutputStream) -> Unit): Boolean {
        val buf = ByteArrayOutputStream()
        val d = DataOutputStream(buf)
        writeVarInt(d, id)
        build(d)
        val payload = buf.toByteArray()
        return synchronized(writeLock) {
            val out = output ?: return@synchronized false
            try {
                val frame = ByteArrayOutputStream()
                val f = DataOutputStream(frame)
                if (compression < 0) {
                    writeVarInt(f, payload.size)
                    f.write(payload)
                } else if (payload.size < compression) {
                    writeVarInt(f, payload.size + 1)
                    writeVarInt(f, 0)
                    f.write(payload)
                } else {
                    val def = Deflater()
                    def.setInput(payload)
                    def.finish()
                    val tmp = ByteArray(payload.size + 64)
                    val n = def.deflate(tmp)
                    def.end()
                    val lenBuf = ByteArrayOutputStream()
                    writeVarInt(DataOutputStream(lenBuf), payload.size)
                    writeVarInt(f, lenBuf.size() + n)
                    f.write(lenBuf.toByteArray())
                    f.write(tmp, 0, n)
                }
                out.write(frame.toByteArray())
                out.flush()
                true
            } catch (e: Exception) {
                if (connected) { connected = false; log("ارسال ناموفق: ${e.javaClass.simpleName}: ${e.message ?: "بدون جزئیات"}") }
                false
            }
        }
    }

    // ---------------- متن (JSON / NBT) ----------------

    /** متن چت: از 1.20.3 به بعد NBT است، قبل از آن JSON. */
    private fun readComponent(p: DataInputStream): String =
        if (version.nbtText) cleanText(flattenAny(readNbtPayload(p, p.readUnsignedByte())))
        else chatText(readString(p))

    private fun chatText(json: String): String = try {
        val t = json.trim()
        val any: Any = when {
            t.startsWith("{") -> JSONObject(t)
            t.startsWith("[") -> org.json.JSONArray(t)
            else -> t
        }
        cleanText(flattenAny(jsonToAny(any)))
    } catch (_: Exception) { json }

    private fun jsonToAny(a: Any?): Any? = when (a) {
        is JSONObject -> a.keys().asSequence().associateWith { jsonToAny(a.opt(it)) }
        is org.json.JSONArray -> (0 until a.length()).map { jsonToAny(a.opt(it)) }
        else -> a
    }

    /** یک کامپوننت متنی (String / Map / List) را به متن ساده تبدیل می‌کند. */
    private fun flattenAny(a: Any?): String = when (a) {
        null -> ""
        is String -> a
        is List<*> -> a.joinToString("") { flattenAny(it) }
        is Map<*, *> -> {
            @Suppress("UNCHECKED_CAST")
            val m = a as Map<String, Any?>
            val sb = StringBuilder()
            val text = m["text"]
            val tr = m["translate"]
            if (text is String) sb.append(text) else if (text == null && tr is String) sb.append(tr)
            sb.append(flattenAny(m["extra"]))
            sb.toString()
        }
        else -> a.toString()
    }

    private fun cleanText(s: String) = s.replace(Regex("§."), "").trim()

    /** خواندن NBT شبکه‌ای (بدون نام ریشه) و تبدیل به Map/List/String. */
    private fun readNbtPayload(d: DataInputStream, type: Int, depth: Int = 0): Any? {
        if (depth > 32) throw IllegalStateException("NBT خیلی عمیق")
        return when (type) {
            0 -> null
            1 -> d.readByte()
            2 -> d.readShort()
            3 -> d.readInt()
            4 -> d.readLong()
            5 -> d.readFloat()
            6 -> d.readDouble()
            7 -> { val n = d.readInt(); d.skipBytes(n); null }
            8 -> d.readUTF()
            9 -> {
                val t = d.readUnsignedByte()
                val n = d.readInt()
                val list = ArrayList<Any?>()
                for (i in 0 until n) list.add(readNbtPayload(d, t, depth + 1))
                list
            }
            10 -> {
                val map = LinkedHashMap<String, Any?>()
                while (true) {
                    val t = d.readUnsignedByte()
                    if (t == 0) break
                    val name = d.readUTF()
                    map[name] = readNbtPayload(d, t, depth + 1)
                }
                map
            }
            11 -> { val n = d.readInt(); d.skipBytes(n * 4); null }
            12 -> { val n = d.readInt(); d.skipBytes(n * 8); null }
            else -> throw IllegalStateException("نوع NBT نامعتبر $type")
        }
    }

    // ---------------- ابزار باینری ----------------

    private fun writeVarInt(out: DataOutputStream, value: Int) {
        var v = value
        while ((v and -128) != 0) {
            out.writeByte((v and 127) or 128)
            v = v ushr 7
        }
        out.writeByte(v)
    }

    private fun readVarInt(input: DataInputStream): Int {
        var result = 0
        var pos = 0
        while (true) {
            val cur = input.readUnsignedByte()
            result = result or ((cur and 127) shl pos)
            if ((cur and 128) == 0) return result
            pos += 7
            if (pos >= 35) throw IllegalStateException("VarInt نامعتبر")
        }
    }

    private fun writeString(out: DataOutputStream, s: String) {
        val b = s.toByteArray(StandardCharsets.UTF_8)
        writeVarInt(out, b.size)
        out.write(b)
    }

    private fun readString(input: DataInputStream): String {
        val len = readVarInt(input)
        if (len < 0 || len > 262144) throw IllegalStateException("رشته نامعتبر")
        val b = ByteArray(len)
        input.readFully(b)
        return String(b, StandardCharsets.UTF_8)
    }

    private fun writeUuid(out: DataOutputStream, u: UUID) {
        out.writeLong(u.mostSignificantBits)
        out.writeLong(u.leastSignificantBits)
    }
}
