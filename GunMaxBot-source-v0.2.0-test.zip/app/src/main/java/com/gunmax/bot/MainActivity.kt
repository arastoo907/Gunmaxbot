package com.gunmax.bot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

private val Bg = Color(0xFF07110F)
private val Panel = Color(0xFF101D19)
private val Panel2 = Color(0xFF172923)
private val Mint = Color(0xFF39D6A0)
private val Muted = Color(0xFF9AB0A8)
private val White = Color(0xFFEAF5F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GunMaxApp() }
    }
}

@Composable
fun GunMaxApp() {
    var command by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("داشبورد") }
    var running by remember { mutableStateOf(false) }
    var serverHost by remember { mutableStateOf("play.gunmax.org") }
    var serverPort by remember { mutableStateOf("25565") }
    var pingState by remember { mutableStateOf("هنوز بررسی نشده") }
    var checking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bots = listOf("بات شماره ۱", "بات شماره ۲", "بات شماره ۳")

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Mint,
        onBackground = White, onSurface = White
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Mint) {
                        listOf("داشبورد" to Icons.Default.Dashboard,
                            "بات‌ها" to Icons.Default.SmartToy,
                            "تنظیمات" to Icons.Default.Settings).forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = selected == label,
                                onClick = { selected = label },
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Mint, selectedTextColor = Mint,
                                    indicatorColor = Panel2, unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()) {
                            Column {
                                Text("گانمکس بات", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
                                Text("مدیریت هوشمند بات‌های Minecraft", color = Muted, fontSize = 12.sp)
                            }
                            Surface(shape = RoundedCornerShape(16.dp), color = Mint.copy(alpha = .16f)) {
                                Icon(Icons.Default.Diamond, null, tint = Mint, modifier = Modifier.padding(14.dp).size(28.dp))
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("بات‌های فعال", "۰ / ۵", Icons.Default.SmartToy, Modifier.weight(1f))
                            StatCard("وظایف امروز", "۰", Icons.Default.TaskAlt, Modifier.weight(1f))
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Hub, null, tint = Mint)
                                    Spacer(Modifier.width(8.dp))
                                    Text("کنترل مرکزی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Spacer(Modifier.weight(1f))
                                    Surface(color = if (running) Mint.copy(alpha=.18f) else Panel2, shape = RoundedCornerShape(30.dp)) {
                                        Text(if (running) "روشن" else "متوقف", color = if (running) Mint else Muted,
                                            modifier = Modifier.padding(horizontal=12.dp, vertical=6.dp), fontSize=12.sp)
                                    }
                                }
                                Button(
                                    onClick = { running = !running },
                                    modifier = Modifier.fillMaxWidth().height(52.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFFB83D62) else Mint),
                                    shape = RoundedCornerShape(15.dp)
                                ) {
                                    Icon(if (running) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (running) "توقف پنل آزمایشی" else "شروع پنل آزمایشی", color = Color(0xFF06110D), fontWeight = FontWeight.Bold)
                                }
                                Text("این نسخه بررسی دسترسی TCP سرور را دارد؛ ورود واقعی بازیکن هنوز پیاده‌سازی نشده است.", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("آزمایش اتصال سرور", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                OutlinedTextField(value = serverHost, onValueChange = { serverHost = it }, label = { Text("آدرس سرور") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = serverPort, onValueChange = { serverPort = it.filter(Char::isDigit).take(5) }, label = { Text("پورت") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Button(onClick = {
                                    val port = serverPort.toIntOrNull()
                                    if (serverHost.isBlank() || port == null || port !in 1..65535) {
                                        pingState = "آدرس یا پورت نامعتبر است"
                                    } else {
                                        checking = true
                                        pingState = "در حال بررسی پورت..."
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) {
                                                try {
                                                    Socket().use { it.connect(InetSocketAddress(serverHost.trim(), port), 5000) }
                                                    "پورت TCP در دسترس است؛ ورود Minecraft هنوز انجام نشده."
                                                } catch (e: Exception) {
                                                    "اتصال برقرار نشد: ${e.javaClass.simpleName}"
                                                }
                                            }
                                            pingState = result
                                            checking = false
                                        }
                                    }
                                }, enabled = !checking, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                    Text(if (checking) "در حال بررسی..." else "بررسی اتصال", color = Bg)
                                }
                                Text(pingState, color = Muted, fontSize = 12.sp)
                                Text("این تست فقط دسترسی شبکه به پورت را می‌سنجد؛ ورود بازیکن یا اجرای دستور را تأیید نمی‌کند.", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("دستور هوشمند", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("دستورت را فارسی بنویس؛ مثل: برو به مختصات 250، 40، 120 و منتظر بمان.", color = Muted, fontSize = 12.sp)
                                Surface(color = Bg, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                    BasicTextField(
                                        value = command, onValueChange = { command = it },
                                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                                        textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
                                        decorationBox = { inner ->
                                            if (command.isEmpty()) Text("مثلاً: برو به فروشگاه و موجودی را بررسی کن...", color = Muted)
                                            inner()
                                        }
                                    )
                                }
                                Button(onClick = { }, enabled = command.isNotBlank(),
                                    modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                                    Icon(Icons.Default.Send, null, tint = Bg)
                                    Spacer(Modifier.width(8.dp))
                                    Text("ثبت دستور (در نسخه بعدی فعال می‌شود)", color = Bg, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    item {
                        Text("اکانت‌های بات", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    items(3) { index ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                                    Icon(Icons.Default.SmartToy, null, tint = Mint, modifier = Modifier.padding(11.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(bots[index], fontWeight = FontWeight.SemiBold)
                                    Text("هنوز پیکربندی نشده", color = Muted, fontSize = 11.sp)
                                }
                                Surface(color = Color(0xFF39453F), shape = RoundedCornerShape(30.dp)) {
                                    Text("آفلاین", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal=10.dp, vertical=6.dp))
                                }
                            }
                        }
                    }
                    item {
                        Text("گزارش فعالیت", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                LogLine("سیستم", "پنل GunMax Bot آماده نمایش است.", Mint)
                                LogLine("اتصال", "سرور Minecraft هنوز تنظیم نشده است.", Muted)
                                LogLine("امنیت", "اطلاعات ورود را فعلاً وارد نکنید.", Color(0xFFFFC66D))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = Mint)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun LogLine(tag: String, message: String, color: Color) {
    Row(verticalAlignment = Alignment.Top) {
        Text(tag, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(58.dp))
        Text(message, color = Muted, fontSize = 12.sp)
    }
}
