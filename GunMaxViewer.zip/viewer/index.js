// GunMax Viewer: دید اول‌شخص زنده‌ی بات + کنترل دستی از گوشی
const http = require('http')
const fs = require('fs')
const path = require('path')
const { WebSocketServer } = require('ws')
const mineflayer = require('mineflayer')
const { mineflayerViewer } = require('prismarine-viewer')

const cfg = Object.assign({
  host: 'localhost', port: 25565, username: 'GunMax_1', password: '', version: '',
  webPort: 8080, viewerPort: 3007, viewDistance: 6, token: '', autoReconnect: true
}, JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8')))

let bot = null
let mode = 'manual'          // manual | auto
let autoTimer = null
let lastAuth = 0
const clients = new Set()

function broadcast (obj) {
  const s = JSON.stringify(obj)
  for (const c of clients) if (c.readyState === 1) c.send(s)
}

// ---------------- وب‌سرور و وب‌سوکت ----------------
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x')
  if (cfg.token && url.searchParams.get('token') !== cfg.token) {
    res.writeHead(403); return res.end('forbidden')
  }
  if (url.pathname === '/config.json') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ viewerPort: cfg.viewerPort }))
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
  res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')))
})
const wss = new WebSocketServer({ server })
wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://x')
  if (cfg.token && url.searchParams.get('token') !== cfg.token) return ws.close()
  clients.add(ws)
  ws.on('close', () => clients.delete(ws))
  ws.on('message', (raw) => { try { onCommand(JSON.parse(raw)) } catch (e) {} })
})
server.listen(cfg.webPort, '0.0.0.0', () => {
  console.log(`\nکنترل‌پنل: http://localhost:${cfg.webPort}${cfg.token ? '/?token=' + cfg.token : ''}`)
  console.log('(از گوشی: به‌جای localhost آی‌پی دستگاه را بزن)\n')
})

// ---------------- فرمان‌های گوشی ----------------
const clamp = (v, a, b) => Math.max(a, Math.min(b, v))

function stopAll () { if (bot) bot.clearControlStates() }

function setMove (x, y) {
  if (!bot || !bot.entity) return
  const dead = 0.2
  bot.setControlState('forward', y < -dead)
  bot.setControlState('back', y > dead)
  bot.setControlState('left', x < -dead)
  bot.setControlState('right', x > dead)
  bot.setControlState('sprint', Math.hypot(x, y) > 0.92 && y < -dead)
}

function setMode (m) {
  mode = m
  stopAll()
  clearInterval(autoTimer)
  if (m === 'auto') autoTimer = setInterval(autoStep, 3500)
  broadcast({ t: 'mode', mode })
}

function onCommand (m) {
  if (!bot || !bot.entity) return
  switch (m.t) {
    case 'move':
      if (mode !== 'manual') setMode('manual')
      setMove(+m.x || 0, +m.y || 0); break
    case 'look':
      if (mode !== 'manual') setMode('manual')
      bot.look(bot.entity.yaw - (+m.dx || 0) * 0.006, clamp(bot.entity.pitch - (+m.dy || 0) * 0.006, -1.5, 1.5), true); break
    case 'jump':
      bot.setControlState('jump', !!m.down); break
    case 'chat':
      if (typeof m.text === 'string' && m.text.trim()) bot.chat(m.text.slice(0, 256)); break
    case 'mode':
      setMode(m.mode === 'auto' ? 'auto' : 'manual'); break
  }
}

// حالت هوشمند ساده: پرسه‌زدن تصادفی + پرش + نگاه‌کردن به اطراف (ضد AFK)
function autoStep () {
  if (!bot || !bot.entity) return
  bot.clearControlStates()
  const r = Math.random()
  bot.look(bot.entity.yaw + (Math.random() - 0.5) * 2.2, clamp((Math.random() - 0.5) * 0.6, -1.5, 1.5), false)
  if (r < 0.65) {
    bot.setControlState('forward', true)
    if (Math.random() < 0.5) bot.setControlState('jump', true)
    setTimeout(() => { if (mode === 'auto' && bot) bot.clearControlStates() }, 1500 + Math.random() * 1500)
  }
}

// ---------------- بات ----------------
function startBot () {
  console.log(`اتصال به ${cfg.host}:${cfg.port} با نام ${cfg.username} ...`)
  const b = mineflayer.createBot({
    host: cfg.host, port: +cfg.port, username: cfg.username,
    version: cfg.version || false, auth: 'offline', viewDistance: 'tiny'
  })
  bot = b

  b.once('spawn', () => {
    console.log('وارد دنیا شد؛ نمای زنده روی پورت', cfg.viewerPort)
    try { mineflayerViewer(b, { port: cfg.viewerPort, firstPerson: true, viewDistance: cfg.viewDistance }) } catch (e) { console.log('viewer:', e.message) }
    broadcast({ t: 'status', text: 'داخل بازی' })
  })

  b.on('message', (jm) => {
    const text = jm.toString()
    broadcast({ t: 'chat', text })
    if (!cfg.password) return
    const l = text.toLowerCase()
    if (Date.now() - lastAuth < 4000) return
    if (l.includes('/register') || l.includes('/reg ')) { lastAuth = Date.now(); b.chat(`/register ${cfg.password} ${cfg.password}`) }
    else if (l.includes('/login') || l.includes('/l ')) { lastAuth = Date.now(); b.chat(`/login ${cfg.password}`) }
  })

  b.on('kicked', (r) => { console.log('کیک شد:', r); broadcast({ t: 'status', text: 'کیک شد' }) })
  b.on('error', (e) => console.log('خطا:', e.message))
  b.on('end', (reason) => {
    console.log('اتصال بسته شد:', reason)
    try { b.viewer && b.viewer.close() } catch (e) {}
    clearInterval(autoTimer)
    broadcast({ t: 'status', text: 'قطع شد' })
    if (cfg.autoReconnect) { setTimeout(startBot, 8000); broadcast({ t: 'status', text: 'اتصال دوباره تا ۸ ثانیه...' }) }
  })
}
startBot()

setInterval(() => {
  if (!bot || !bot.entity) return
  const p = bot.entity.position
  broadcast({
    t: 'state', x: +p.x.toFixed(1), y: +p.y.toFixed(1), z: +p.z.toFixed(1),
    health: bot.health, food: bot.food, mode
  })
}, 500)
